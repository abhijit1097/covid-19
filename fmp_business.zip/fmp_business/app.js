var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var hbs = require('hbs');
var session = require('express-session');
var validator = require('express-validator');
var auth = require('./middleware/auth');
var cors = require('cors');
var indexRouter = require('./routes/indexRoute');
var dashboardRouter = require('./routes/dashboardRoute');
var userRouter = require('./routes/userRoute');
var projectRouter = require('./routes/projectRoute');
var walletRouter = require('./routes/walletRoute');
var creditRouter = require('./routes/creditRoute');
var dashboardNewRouter = require('./routes/dashboardNewRoute');
var projectPostRouter = require('./routes/projectPostRoute');
var timesheetRouter = require('./routes/timesheetRoute');
var invoiceRouter = require('./routes/invoiceRoute');
var coronaRouter = require('./routes/coronaRoute');
var isNumber = require('is-number');
var moment = require('moment');
var Handlebars = require('handlebars');
var helpers = require('handlebars-helpers');
var math = helpers.math();

var DateFormats = {
  short: "DD MMMM - YYYY",
  long: "dddd DD.MM.YYYY",
  new: "DD-MM-YYYY",
  datetimenew: "DD-MM-YYYY HH:mm:ss",
  calendar: "DD MMM"
};

hbs.registerHelper('add', function(a, b){
  if (isNumber(a) && isNumber(b)) {
    return Number(a) + Number(b);
  }
  if (typeof a === 'string' && typeof b === 'string') {
    return a + b;
  }
  return '';

})

hbs.registerHelper('currentDate', function() {
  return moment().format('MMMM Do YYYY')
})

hbs.registerHelper('diff', function(a, b) {
   a = moment()
   b = moment()
  return a.diff(b, 'days')
//  return  moment().diff(date_time, date,  'days')
});


hbs.registerHelper('ifEquals', function(arg1, arg2, options) {
  return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
});

hbs.registerHelper('ifNotEquals', function(arg1, arg2, options) {
  return (arg1 !== arg2) ? options.fn(this) : options.inverse(this);
});
hbs.registerHelper('select', function(selected, options) {
  return options.fn(this).replace(
      new RegExp(' value=\"' + selected + '\"'),
      '$& selected="selected"');
});

hbs.registerHelper('strip-scripts', function(context) {
  var html = context;
  return new Handlebars.SafeString(html);
})

hbs.registerHelper("formatDate", function(datetime, format) {
  if (moment) {
    // can use other formats like 'lll' too
    format = DateFormats[format] || format;
    return moment(datetime).format(format);
  }
  else {
    return datetime;
  }
});

helpers.add = function(a, b) {
  if (isNumber(a) && isNumber(b)) {
    return Number(a) + Number(b);
  }
  if (typeof a === 'string' && typeof b === 'string') {
    return a + b;
  }
  return '';
};



var app = express();

app.use(cors());


app.get("/manifest.json", function(req, res){
  res.header("Content-Type", "text/cache-manifest");
  res.sendFile(path.join(__dirname,"manifest.json"));
})

app.get("/sw.js", function(req, res){
  res.header("Content-Type", "text/javascript");
  res.sendFile(path.join(__dirname,"sw.js"));
});

app.get("/loader.js", function(req, res){
  res.header("Content-Type", "text/javascript");
  res.sendFile(path.join(__dirname,"loader.js"));
});

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');

hbs.registerPartials(__dirname+'/views/partials');



// hbs.registerHelper("math", function(lvalue, operator, rvalue, options) {
//   lvalue = parseFloat(lvalue);
//   rvalue = parseFloat(rvalue);
      
//   return {
//       "+": lvalue + rvalue,
//       "-": lvalue - rvalue,
//       "*": lvalue * rvalue,
//       "/": lvalue / rvalue,
//       "%": lvalue % rvalue
//   }[operator];
// });




app.use(session({
  secret: 'top secret',
  saveUninitialized: false,
  resave: false,
  cookie: { maxAge: 30 * 24 * 60 * 1000}
}));

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(validator());
app.use(auth.authenticated);
app.use('/', indexRouter);
app.use('/beta/dashboard',auth.authenticate, dashboardRouter);
app.use('/beta/dashboard1', dashboardNewRouter);
app.use('/beta/users', userRouter);
app.use('/beta/projects', projectRouter);
app.use('/beta/projectsnew', projectPostRouter);
app.use('/beta/wallet', walletRouter);
//app.use('/beta/wallet', creditRouter);
app.use('/timesheet', timesheetRouter);
app.use('/beta/invoices', invoiceRouter);
app.use('/corona', coronaRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

app.listen(4200, function(req, res, next) {
  console.log("App is running");
})



module.exports = app;
