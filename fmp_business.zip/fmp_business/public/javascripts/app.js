
/*
Author       : Dreamguys
Template Name: SmartHR - Bootstrap Admin Template
Version      : 3.2
*/

$(document).ready(function() {
	
	// Variables declarations
	
	var $wrapper = $('.main-wrapper');
	var $pageWrapper = $('.page-wrapper');
	var $slimScrolls = $('.slimscroll');
	var $sidebarOverlay = $('.sidebar-overlay');
	
	// Sidebar
	
	var Sidemenu = function() {
		this.$menuItem = $('#sidebar-menu a');
	};
	
	function init() {
		var $this = Sidemenu;
		$('#sidebar-menu a').on('click', function(e) {
			if($(this).parent().hasClass('submenu')) {
				e.preventDefault();
			}
			if(!$(this).hasClass('subdrop')) {
				$('ul', $(this).parents('ul:first')).slideUp(350);
				$('a', $(this).parents('ul:first')).removeClass('subdrop');
				$(this).next('ul').slideDown(350);
				$(this).addClass('subdrop');
				$(".submenu .active").parent().parent().css('display','block');
			} else if($(this).hasClass('subdrop')) {
				$(this).removeClass('subdrop');
				$(this).next('ul').slideUp(350);
			}
		});
		$('#sidebar-menu ul li.submenu a.active').parents('li:last').children('a:first').addClass('active').trigger('click');
	}
	
	// Sidebar Initiate
	init();
	
	// Sidebar overlay
	
	function sidebar_overlay($target) {
		if($target.length) {
			$target.toggleClass('opened');
			$sidebarOverlay.toggleClass('opened');
			$('html').toggleClass('menu-opened');
			$sidebarOverlay.attr('data-reff', '#' + $target[0].id);
		}
	}
	
	// Mobile menu sidebar overlay
	
	$(document).on('click', '#mobile_btn', function() {
		var $target = $($(this).attr('href'));
		sidebar_overlay($target);
		$wrapper.toggleClass('slide-nav');
		$('#task_window').removeClass('opened');
		return false;
	});
	
	// Chat sidebar overlay
	
	$(document).on('click', '#task_chat', function() {
		var $target = $($(this).attr('href'));
		sidebar_overlay($target);
		return false;
	});
	
	// Sidebar overlay reset
	
	$sidebarOverlay.on('click', function() {
		var $target = $($(this).attr('data-reff'));
		if($target.length) {
			$target.removeClass('opened');
			$('html').removeClass('menu-opened');
			$(this).removeClass('opened');
			$wrapper.removeClass('slide-nav');
		}
		return false;
	});
	
	// Select 2
	
	// if($('.select').length > 0) {
	// 	$('.select').select2({
	// 		minimumResultsForSearch: -1,
	// 		width: '100%'
	// 	});
	// }
	
	// Modal Popup hide show

	if($('.modal').length > 0 ){
		var modalUniqueClass = ".modal";
		$('.modal').on('show.bs.modal', function(e) {
		  var $element = $(this);
		  var $uniques = $(modalUniqueClass + ':visible').not($(this));
		  if ($uniques.length) {
			$uniques.modal('hide');
			$uniques.one('hidden.bs.modal', function(e) {
			  $element.modal('show');
			});
			return false;
		  }
		});
	}
	
	// Floating Label

	if($('.floating').length > 0 ){
		$('.floating').on('focus blur', function (e) {
		$(this).parents('.form-focus').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
		}).trigger('blur');
	}
	
	// Sidebar Slimscroll

	if($slimScrolls.length > 0) {
		$slimScrolls.slimScroll({
			height: 'auto',
			width: '100%',
			position: 'right',
			size: '7px',
			color: '#ccc',
			wheelStep: 10,
			touchScrollStep: 100
		});
		var wHeight = $(window).height() - 60;
		$slimScrolls.height(wHeight);
		$('.sidebar .slimScrollDiv').height(wHeight);
		$(window).resize(function() {
			var rHeight = $(window).height() - 60;
			$slimScrolls.height(rHeight);
			$('.sidebar .slimScrollDiv').height(rHeight);
		});
	}
	
	// Page Content Height

	var pHeight = $(window).height();
	$pageWrapper.css('min-height', pHeight);
	$(window).resize(function() {
		var prHeight = $(window).height();
		$pageWrapper.css('min-height', prHeight);
	});
	
	// Date Time Picker
	
	// if($('.datetimepicker').length > 0) {
	// 	$('.datetimepicker').datetimepicker({
	// 		format: 'DD/MM/YYYY',
	// 		icons: {
	// 			up: "fa fa-angle-up",
	// 			down: "fa fa-angle-down",
	// 			next: 'fa fa-angle-right',
	// 			previous: 'fa fa-angle-left'
	// 		}
	// 	});
	// }
	
	// Datatable

	if($('.datatable').length > 0) {
		$('.datatable').DataTable({
			"bFilter": false,
		});
	}
	
	// Tooltip

	if($('[data-toggle="tooltip"]').length > 0) {
		$('[data-toggle="tooltip"]').tooltip();
	}
	
	// Email Inbox

	if($('.clickable-row').length > 0 ){
		$(".clickable-row").click(function() {
			window.location = $(this).data("href");
		});
	}

	// Check all email
	
	$(document).on('click', '#check_all', function() {
		$('.checkmail').click();
		return false;
	});
	if($('.checkmail').length > 0) {
		$('.checkmail').each(function() {
			$(this).on('click', function() {
				if($(this).closest('tr').hasClass('checked')) {
					$(this).closest('tr').removeClass('checked');
				} else {
					$(this).closest('tr').addClass('checked');
				}
			});
		});
	}
	
	// Mail important
	
	$(document).on('click', '.mail-important', function() {
		$(this).find('i.fa').toggleClass('fa-star').toggleClass('fa-star-o');
	});
	
	// Summernote
	
	// if($('.summernote').length > 0) {
	// 	$('.summernote').summernote({
	// 		height: 200,                 // set editor height
	// 		minHeight: null,             // set minimum height of editor
	// 		maxHeight: null,             // set maximum height of editor
	// 		focus: false                 // set focus to editable area after initializing summernote
	// 	});
	// }
	
	// Task Complete
	
	$(document).on('click', '#task_complete', function() {
		$(this).toggleClass('task-completed');
		return false;
	});
	
	// Multiselect

	if($('#customleave_select').length > 0) {
		$('#customleave_select').multiselect();
	}
	if($('#edit_customleave_select').length > 0) {
		$('#edit_customleave_select').multiselect();
	}

	// Leave Settings button show
	
	$(document).on('click', '.leave-edit-btn', function() {
		$(this).removeClass('leave-edit-btn').addClass('btn btn-white leave-cancel-btn').text('Cancel');
		$(this).closest("div.leave-right").append('<button class="btn btn-primary leave-save-btn" type="submit">Save</button>');
		$(this).parent().parent().find("input").prop('disabled', false);
		return false;
	});
	$(document).on('click', '.leave-cancel-btn', function() {
		$(this).removeClass('btn btn-white leave-cancel-btn').addClass('leave-edit-btn').text('Edit');
		$(this).closest("div.leave-right").find(".leave-save-btn").remove();
		$(this).parent().parent().find("input").prop('disabled', true);
		return false;
	});
	
	$(document).on('change', '.leave-box .onoffswitch-checkbox', function() {
		var id = $(this).attr('id').split('_')[1];
		if ($(this).prop("checked") == true) {
			$("#leave_"+id+" .leave-edit-btn").prop('disabled', false);
			$("#leave_"+id+" .leave-action .btn").prop('disabled', false);
		}
	    else {
			$("#leave_"+id+" .leave-action .btn").prop('disabled', true);	
			$("#leave_"+id+" .leave-cancel-btn").parent().parent().find("input").prop('disabled', true);
			$("#leave_"+id+" .leave-cancel-btn").closest("div.leave-right").find(".leave-save-btn").remove();
			$("#leave_"+id+" .leave-cancel-btn").removeClass('btn btn-white leave-cancel-btn').addClass('leave-edit-btn').text('Edit');
			$("#leave_"+id+" .leave-edit-btn").prop('disabled', true);
		}
	});
	
	$('.leave-box .onoffswitch-checkbox').each(function() {
		var id = $(this).attr('id').split('_')[1];
		if ($(this).prop("checked") == true) {
			$("#leave_"+id+" .leave-edit-btn").prop('disabled', false);
			$("#leave_"+id+" .leave-action .btn").prop('disabled', false);
		}
	    else {
			$("#leave_"+id+" .leave-action .btn").prop('disabled', true);	
			$("#leave_"+id+" .leave-cancel-btn").parent().parent().find("input").prop('disabled', true);
			$("#leave_"+id+" .leave-cancel-btn").closest("div.leave-right").find(".leave-save-btn").remove();
			$("#leave_"+id+" .leave-cancel-btn").removeClass('btn btn-white leave-cancel-btn').addClass('leave-edit-btn').text('Edit');
			$("#leave_"+id+" .leave-edit-btn").prop('disabled', true);
		}
	});
	
	// Placeholder Hide

	if ($('.otp-input, .zipcode-input input, .noborder-input input').length > 0) {
		$('.otp-input, .zipcode-input input, .noborder-input input').focus(function () {
			$(this).data('placeholder', $(this).attr('placeholder'))
				   .attr('placeholder', '');
		}).blur(function () {
			$(this).attr('placeholder', $(this).data('placeholder'));
		});
	}
	
	// OTP Input
	
	if ($('.otp-input').length > 0) {
		$(".otp-input").keyup(function(e) {
			if ((e.which >= 48 && e.which <= 57) || (e.which >= 96 && e.which <= 105)) {
				$(e.target).next('.otp-input').focus();
			} else if (e.which == 8) {
				$(e.target).prev('.otp-input').focus();
			}
		});
	}
	
	// Small Sidebar

	$(document).on('click', '#toggle_btn', function() {
		if($('body').hasClass('mini-sidebar')) {
			$('body').removeClass('mini-sidebar');
			$('.subdrop + ul').slideDown();
		} else {
			$('body').addClass('mini-sidebar');
			$('.subdrop + ul').slideUp();
		}
		return false;
	});
	$(document).on('mouseover', function(e) {
		e.stopPropagation();
		if($('body').hasClass('mini-sidebar') && $('#toggle_btn').is(':visible')) {
			var targ = $(e.target).closest('.sidebar').length;
			if(targ) {
				$('body').addClass('expand-menu');
				$('.subdrop + ul').slideDown();
			} else {
				$('body').removeClass('expand-menu');
				$('.subdrop + ul').slideUp();
			}
			return false;
		}
	});

});





// Loader

// $(window).on ('load', function (){
// 	$('#loader').delay(100).fadeOut('slow');
// 	$('#loader-wrapper').delay(500).fadeOut('slow');
// });


function valueChanged() {

	if ($('#no_gst').is(":checked"))
		$("#gst").hide();
	else
		$("#gst").show();
}


$('#select_all').click(function(event) {
	if(this.checked) {
		// Iterate each checkbox
		$(':checkbox').each(function() {
			this.checked = true;
		});
	}
	else {
	  $(':checkbox').each(function() {
			this.checked = false;
		});
	}
  });


$('#select_all1').click(function(event) {
	if(this.checked) {
		// Iterate each checkbox
		$(':checkbox').each(function() {
			this.checked = true;
		});
	}
	else {
	  $(':checkbox').each(function() {
			this.checked = false;
		});
	}
  });

  $(document).ready(function(){

	var current_fs, next_fs, previous_fs; //fieldsets
	var opacity;
	
	$(".next").click(function(){
	
	current_fs = $(this).parent();
	next_fs = $(this).parent().next();
	
	//Add Class Active
	$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
	
	
	next_fs.show();
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
	step: function(now) {
	// for making fielset appear animation
	opacity = 1 - now;
	
	current_fs.css({
	'display': 'none',
	'position': 'relative'
	});
	next_fs.css({'opacity': opacity});
	},
	duration: 600
	});
	});
	
	$(".previous").click(function(){
	
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();
	
	//Remove class active
	$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
	
	//show the previous fieldset
	previous_fs.show();
	
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
	step: function(now) {
	// for making fielset appear animation
	opacity = 1 - now;
	
	current_fs.css({
	'display': 'none',
	'position': 'relative'
	});
	previous_fs.css({'opacity': opacity});
	},
	duration: 600
	});
	});
	
	$('.radio-group .radio').click(function(){
	$(this).parent().find('.radio').removeClass('selected');
	$(this).addClass('selected');
	});

	
	
	$(".submit").click(function(){
	return false;
	})
	
	});

	// $(function() {
	// 	$('input[name="datetimes"]').daterangepicker({
	// 	  timePicker: true,
	// 	  startDate: moment().startOf('hour'),
	// 	  endDate: moment().startOf('hour').add(32, 'hour'),
	// 	  locale: {
	// 		format: 'M/DD hh:mm A'
	// 	  }
	// 	});
	//   });
	
	// $(document).ready(function() {
		// $('#datepicker').datepicker({
		// 	startDate: new Date(),
		// 	multidate: true,
		// 	format: "dd/mm/yyyy",
		// 	daysOfWeekHighlighted: "5,6",
		// 	datesDisabled: ['31/08/2017'],
		// 	language: 'en'
		// }).on('changeDate', function(e) {
			
		// 	$(this).find('.input-group-addon .count').text(' ' + e.dates.length);

		// });
	// });
	
	// $('.date').datetimepicker({
	// 	multidate: true,
	// 	format: 'hh:mm A'
	// });


	// $(function() {
	// 	$('input[name="datetimes"]').daterangepicker({
	// 	  timePicker: true,
	// 	  startDate: moment().startOf('hour'),
	// 	  endDate: moment().startOf('hour').add(32, 'hour'),
	// 	  locale: {
	// 		format: 'M/DD hh:mm A'
	// 	  }
	// 	});
	//   });	
	
	$('#timepicker').timepicker({
		uiLibrary: 'bootstrap4',
		format: 'HH:MM A'
	});

	$('#timepickerOne').timepicker({
		uiLibrary: 'bootstrap4',
		format: 'HH:MM A'
	});

	$('#Date').daterangepicker({});



		
		// categorySelected()
		// console.log('test',categoryOne)


		function categorySelected() {
			$("#categoryCard").show();
			var categoryOne = document.getElementById("category").value;
			var input = document.getElementById('categoryOne');
			
			input.value = categoryOne
			console.log(categoryOne)

			var nwInput = input.value

			console.log(nwInput)
		}

		$(document).ready(function() {
			$(".search").keyup(function () {
				if ($(this).val().length == 0) {
					$('#tbody').hide();
				} else {
					$('#tbody').show();
				}
			  var searchTerm = $(".search").val();
			  var listItem = $('.results tbody').children('tr');
			  var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
			  
			$.extend($.expr[':'], {'containsi': function(elem, i, match, array){
				  return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
			  }
			});
			  
			$(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
			  $(this).attr('visible','false');
			});
		  
			$(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
			  $(this).attr('visible','true');
			});
		  
			var jobCount = $('.results tbody tr[visible="true"]').length;
			  $('.counter').text(jobCount + ' item');
		  
			if(jobCount == '0') {$('.no-result').show();}
			  else {$('.no-result').hide();}
					});
		  });

		  $(document).ready(function() {
			$('.minus').click(function () {
				var $input = $(this).parent().find('input');
				var count = parseInt($input.val()) - 1;
				count = count < 1 ? 1 : count;
				$input.val(count);
				$input.change();
				return false;
			});
			$('.plus').click(function () {
				var $input = $(this).parent().find('input');
				$input.val(parseInt($input.val()) + 1);
				$input.change();
				return false;
			});
		});

		$(document).ready(function() {
			$(".search").keydown(function () {
				$("#tbody").hide();

			})
			})

		// $(document).ready(function(){
		// 	var table = document.getElementById("calculate"), 
		// });

		$(".answer").hide();
		$(".male_check").click(function () {
			if ($(this).is(":checked")) {
				$(".answer").show();
			} else {
				$(".answer").hide();
			}
		});
	
		$(".answer1").hide();
		$(".female_check").click(function () {
			if ($(this).is(":checked")) {
				$(".answer1").show();
			} else {
				$(".answer1").hide();
			}
		});
	
		$(".answer2").hide();
		$(".any_check").click(function () {
			if ($(this).is(":checked")) {
				$(".answer2").show();
			} else {
				$(".answer2").hide();
			}
		});
	
	
		$(".both_check").click(function () {
	
			if ($(this).is(":checked")) {
				// $('.changeme ').addClass('red');
				//$('.changeme:checkbox:checked')
				//$('input:checkbox').not(this).prop('checked', this.checked);
				$(".changeme").prop('checked', $(this).is(":checked"));
				$(".answer").show();
				$(".answer1").show();
	
			} else {
	
				// $(".changeme option:checked").removeAttr("checked");
				$('.changeme').prop('checked', false).removeAttr('checked');
	
				$(".answer").hide();
				$(".answer1").hide();
	
			}
		});

		// $(document).ready(function () {
        //     $('select').selectize({
        //         sortField: 'text'
        //     });
		// 	});
		window.onload=function(){
			$('.selectpicker').selectpicker();
			$('.rm-mustard').click(function() {
			  $('.remove-example').find('[value=Mustard]').remove();
			  $('.remove-example').selectpicker('refresh');
			});
			$('.rm-ketchup').click(function() {
			  $('.remove-example').find('[value=Ketchup]').remove();
			  $('.remove-example').selectpicker('refresh');
			});
			$('.rm-relish').click(function() {
			  $('.remove-example').find('[value=Relish]').remove();
			  $('.remove-example').selectpicker('refresh');
			});
			$('.ex-disable').click(function() {
				$('.disable-example').prop('disabled',true);
				$('.disable-example').selectpicker('refresh');
			});
			$('.ex-enable').click(function() {
				$('.disable-example').prop('disabled',false);
				$('.disable-example').selectpicker('refresh');
			});
	  
			// scrollYou
			$('.scrollMe .dropdown-menu').scrollyou();
	  
			prettyPrint();
			};
		


		
			function input(){
				var input_taker = document.getElementById('all_location').value;
				document.getElementById('fname').innerHTML = input_taker;
			}
		  
			$(document).ready(function () {
				$('#POITable').on('change', 'select.search_type', function (e) {
					var selectedval = $(this).val();
					$(this).closest('td').next().html(selectedval);
				});
			});
		
		
			function deleteRow(id,row) {
				document.getElementById(id).deleteRow(row);
			}
				
			   function insRow(id) {
					var filas = document.getElementById("myTable").rows.length;
					var x = document.getElementById(id).insertRow(filas);
					var y = x.insertCell(0);
					var z = x.insertCell(1);
					y.innerHTML = '<input class="form-control" id="fname" type="text" size="8"/>';
					z.innerHTML ='<i class="fa fa-trash" style="font-size:30px;color:red;" id="btn" name="btn"></i>';
				}
		  
		  
		  function audience_types(audience_type){
			   
				var rowsids = audience_type; 
				
				$("#audience_yes").hide();
									 
				if(rowsids=="No"){
										 
					$("#audience_yes").hide();
					$("#Business_type").hide();
					$("#Consumer_type").hide();
									 
					
				}else {
										  
					$("#audience_yes").show();
										  
				}
								   
			}
			
			function travel_types(travel_type){
			   
				var rowsids = travel_type; 
				
				$("#travel_yes").hide();
									 
				if(rowsids=="No"){
										 
					$("#travel_yes").hide();
									 
					
				}else {
										  
					$("#travel_yes").show();
										  
				}
								   
			}
			
			  function taskers_types(taskers_type){
			   
				var rowsids = taskers_type; 
				
				$("#taskers_yes").hide();
									 
				if(rowsids=="No"){
										 
					$("#taskers_yes").hide();
									 
					
				}else {
										  
					$("#taskers_yes").show();
										  
				}
								   
			}
		
			   
		  function sub_types(all_type){
			   
				var rowsids = all_type; 
				
				$("#Business_type").hide();
				$("#Consumer_type").hide();
									 
				if(rowsids=="Business"){
										 
					
					  $("#Business_type").show();
					  $("#Consumer_type").hide();               
					
				}else {
										  
					$("#Business_type").hide();
					$("#Consumer_type").show();
										  
				}
								   
			}
		  
		   function collateral_types(collateral_type){
			   
				var rowsids = collateral_type; 
				
				$("#collateral_yes").hide();
									 
				if(rowsids=="No"){
										 
					$("#collateral_yes").hide();
									 
					
				}else {
										  
					$("#collateral_yes").show();
										  
				}
								   
			}
		  
		  
			 $("#savebutton").click(function(){
				   $("#one").hide();
				   $("#two").show();
				   $("#clone").show();
				   $("#circle").show();
				   
			   })
			   
				$("#savebutton1").click(function(){
				   $("#two").hide();
				   $("#three").show();
				   $("#clone1").show();
				   $("#circle1").show();
				   
			   })
			   
				
			   
			   $("#savebutton_continue").click(function(){
				   $("#three").hide();
				   $("#three1").show();
				   
				   
			   })
			   
				$("#savebutton2").click(function(){
				   $("#three").hide();
				   $("#three1").hide();
				   
				   $("#four").show();
				   $("#clone2").show();
				   $("#circle2").show();
				   
			   })
			   
			   $("#savebutton3").click(function(){
				   $("#four").hide();
				  $("#five").show();
				   $("#clone3").show();
				   $("#circle3").show();
				   
			   })
			   
				$("#savebutton4").click(function(){
				   $("#four").hide();
				  $("#five").hide();
				   $("#clone4").show();
				   $("#circle4").show();
				   
			   })
			   
			   
				$("#pencil").click(function(){
				  
				  
				   $("#one").show();
				  $("#pencil").hide();
				  $("#circle").hide();
				   
			   })
			   
			   $("#circle").click(function(){
				  
				  
				   $("#one").hide();
				  $("#pencil").show();
				  $("#circle").hide();
				   
			   })
			   
			 
		  
	  
	  var input2 = document.getElementById('all_location');
				 var options = {
				types: ['(cities)'],
				componentRestrictions: {country: "in"}
				};
				var autocomplete1 = new google.maps.places.Autocomplete(input2, options);
				google.maps.event.addListener(autocomplete1, 'place_changed', function() {
					var place1 = autocomplete1.getPlace();
					if (place1.address_components) {
						address = [
							(place1.address_components[0] && place1.address_components[0].short_name || ''), (place1.address_components[1] && place1.address_components[1].short_name || ''), (place1.address_components[2] && place1.address_components[2].short_name || '')
						].join(' ');
					}
				  console.log(place1.address_components);
	
				});
		
		$(document).ready(function () {
			$('.check').click(function () {
				$('.check').not(this).prop('checked', false);
			});
		});
	
		function allowNumbersOnly(e) {
			var code = (e.which) ? e.which : e.keyCode;
			if (code > 31 && (code < 48 || code > 57)) {
				e.preventDefault();
			}
		}
		$(document).ready(function() {
			var len = 0;
			var maxchar =50;
		  
			$( '#jobdetails' ).keyup(function(){
			  len = this.value.length
			  if(len > maxchar){
				  return false;
			  }
			  else if (len > 0) {
				  $( "#remainingC" ).html( "Remaining characters: " +( maxchar - len ) );
			  }
			  else {
				  $( "#remainingC" ).html( "Remaining characters: " +( maxchar ) );
			  }
			})
		  });




		(function() {
			"use strict";
		
			$("#calculate").on("change", "input", function() {
				var row = $(this).closest("tr");
				console.log('row', row)
				var start_time = moment(row.find(".start_time").val(), "HH:mm:ss a");
				console.log('st', start_time)
				var end_time = moment(row.find(".end_time").val(), "HH:mm:ss a");
				var duration = moment.duration(end_time.diff(start_time));
				var hours = parseInt(duration.asHours());
				var male = parseFloat(row.find(".male").val());
				var female = parseFloat(row.find(".female").val());
				if(hours > 4) {
					var eachdiff = hours - 4;
					var eachMalePay = (male) * ((50 * eachdiff) + 425);
					var eachFemalePay = (female) * ((75 * eachdiff) + 625);
					var total = eachMalePay + eachFemalePay
				} else {
					var eachMalePay = (male) * (425);
					var eachFemalePay = (female) * (625);
					var total = eachMalePay + eachFemalePay
				}

				
				row.find(".cost").val(isNaN(total) ? "" : total);
				var table = document.getElementById("calculate")
				var totalMaleCount = 0;
				var maleCount = 0;
				var femaleCount = 0;
				var totalFemaleCount = 0;
				var totalCost = 0;
				var total = 0;
				var totalHours = 0;
				var totalMalePay = 0;
				var totalFemalePay = 0;
				var x = document.getElementById('totalCost');
				for(var i = 0; i < table.rows.length-1; i++)
				{
					totalMaleCount = totalMaleCount + parseInt(document.getElementById(i+'male_count').value);
					maleCount = parseInt(document.getElementById(i+'male_count').value);
					console.log('val',document.getElementById(i+'male_count').value);
					femaleCount = parseInt(document.getElementById(i+'female_count').value);
					totalFemaleCount = totalFemaleCount + parseInt(document.getElementById(i+'female_count').value);
					var startTime = moment(document.getElementById(i+'start_time').value, "HH:mm:ss a");
					var endTime = moment(document.getElementById(i+'end_time').value, "HH:mm:ss a");
					var totalDuration = moment.duration(endTime.diff(startTime));
					var totalHours = totalHours + parseInt(totalDuration.asHours());

					if(totalDuration.asHours() > 4) {
						var diff = totalDuration.asHours() - 4
						console.log('diff', diff)
						totalMalePay = totalMalePay + (maleCount) * ((50 * diff) + 425)
						totalFemalePay = totalFemalePay + (femaleCount) * ((75 * diff) + 625)
						console.log('totalMalepay', totalMalePay)
						console.log('totalFemalepay', totalFemalePay)
					} else {
						
						totalMalePay = totalMalePay + (maleCount) * (425)
						totalFemalePay = totalFemalePay + (femaleCount) * (625)
						console.log('totalMalepay', totalMalePay)
						console.log('totalFemalepay', totalFemalePay)
					}
				}
					total = totalMalePay + totalFemalePay
					console.log('total', total)
					x.innerHTML = total;
				});
			  
			})();
		
		
		$(document).on("click",".applyBtn",function() {
			// $("#time").hide();
			// $("#timeOne").hide();
			// $("#timeTwo").hide();
			// $("#timepickerOne").hide();
			// $("#Date").hide();
			$("#jobDate").show();
			var x =$('#Date').data('daterangepicker')
			var start_Date = $('#Date').data('daterangepicker').startDate.format("YYYY-MM-DD");
			var end_Date = $('#Date').data('daterangepicker').endDate.format("YYYY-MM-DD");
			console.log(start_Date);
			console.log(end_Date);
			var start_time = document.getElementById('timepicker');
			var time = document.getElementById('timepicker').value;
			var end_time = document.getElementById('timepickerOne').value;
			console.log('time', start_time)
			start_date.innerHTML = start_Date
			var end_date = document.getElementById("enddate");
			end_date.innerHTML = end_Date
			var getDaysArray = function(start, end) {
				for(var arr=[],dt=start; dt<=end; dt.setDate(dt.getDate()+1)){
					arr.push(new Date(dt));
				}
				return arr;
			};
			
			var daylist = getDaysArray(new Date(start_Date),new Date(end_Date));
			
			console.log(daylist.length);

			var quantity = document.getElementById("quantity").value;
			
			// var number = document.getElementById("member").value;
			
			// var container = document.getElementById("container");
			// var containerOne = document.getElementById("containerOne");
			// var containerTwo = document.getElementById("containerTwo");
			// var containerThree = document.getElementById("containerThree");
			
			// while (container.hasChildNodes()) {
			// container.removeChild(container.lastChild);
			// }

			// while (containerOne.hasChildNodes()) {
			// containerOne.removeChild(containerOne.lastChild);
			// }

			for (i=0;i<daylist.length;i++){

				var table = document.getElementById("jobDate");
                var row=table.insertRow(-1);
                var cell1=row.insertCell(0);
				var cell2=row.insertCell(1);
				var cell3=row.insertCell(2);
				var cell4=row.insertCell(3);
				var cell5=row.insertCell(4);

				var input = document.createElement("input");
                input.type = "text";
				input.name = "start_date"
				input.value = moment(daylist[i]).format("YYYY-MM-DD");
				input.readOnly = true
				input.className = "text-muted"
				input.style = "border-top: 0px; border-right: 0px; border-bottom: 1px solid #0000A0;width: 100px"
				cell1.appendChild(input);

				// var inputOne = document.createElement("input");
				// inputOne.type = "text";
				// inputOne.name = "start_time"
				// inputOne.value = time
				// inputOne.readOnly = true
				// inputOne.className = "text-muted ml-3"
				// inputOne.style = "border-top: 0px; border-right: 0px; border-bottom: 1px solid #0000A0; width: 100px"
				// cell2.appendChild(inputOne);

				// var inputTwo = document.createElement("input");
				// inputTwo.type = "text";
				// inputTwo.name = "end_time"
				// inputTwo.value = end_time
				// inputTwo.className = "text-muted ml-2"
				// inputTwo.readOnly = true
				// inputTwo.style = "border-top: 0px; border-right: 0px; border-bottom: 1px solid #0000A0;width: 100px"
				// cell3.appendChild(inputTwo);


				// var inputThree = document.createElement("input");
				// inputThree.type = "text";
				// inputThree.name = "quantity"
				// inputThree.value = quantity
				// inputThree.className = "text-muted ml-2"
				// inputThree.readOnly = true
				// inputThree.style = "border-top: 0px; border-right: 0px; border-bottom: 1px solid #0000A0;width: 100px"
				// cell4.appendChild(inputThree);

				// var inputThree = document.createElement("input");
				// inputThree.type = "text";
				// inputThree.name = "start_time"
				// inputThree.value = time
				// cell4.appendChild(inputThree);

				var button = document.createElement("button");
				button.className = "btn btn-danger fas fa-trash-alt ml-3"
				button.type = "button"
				button.onclick = function(){
					alert(this.value)
				};
				button.value = moment(daylist[i]).format("YYYY-MM-DD")
				cell5.appendChild(button);
			}

			
			// for (i=0;i<daylist.length;i++){
			// 	var input = document.createElement("input");
            //     input.type = "text";
			// 	input.name = "start_time"
			// 	input.value = time
			// 	containerOne.appendChild(input);
			// 	containerOne.appendChild(document.createElement("br"));
			// }

			// for (i=0;i<daylist.length;i++){
			// 	var input = document.createElement("input");
            //     input.type = "text";
			// 	input.name = "end_time"
			// 	input.value = end_time
			// 	containerTwo.appendChild(input);
			// 	containerTwo.appendChild(document.createElement("br"));
			// }
			
			// for (i=0;i<daylist.length;i++){
			// 	var btn = document.createElement("button");
			// 	btn.className = "btn btn-danger"
  			// 	containerThree.appendChild(btn);
			// }
			
	
		});

		// function removeRow(oButton) {
		// 	var empTab = document.getElementById('deleteRow');
		// 	empTab.deleteRow(oButton.parentNode.parentNode.rowIndex);
		// }
		function search(term, text) {
			if (text.toUpperCase().indexOf(term.toUpperCase()) == 0) {
			  return true;
			}
		   
			return false;
		  }
		   
		  $.fn.select2.amd.require(['select2/compat/matcher'], function (f) {
			$("select").select2({
			  matcher: f(search)
			})
		  });
jQuery(document).delegate('a.delete-record', 'click', function(e) {
	e.preventDefault();    
	var didConfirm = confirm("Are you sure You want to delete");
	if (didConfirm == true) {
	 var id = jQuery(this).attr('data-id');
	 var targetDiv = jQuery(this).attr('targetDiv');
	 jQuery('#rec-' + id).remove();
	 
   //regnerate index number on table
   $('#tbl_posts_body tr').each(function(index) {
	 //alert(index);
	 $(this).find('span.sn').html(index+1);
   });
   return true;
 } else {
   return false;
 }
});
	$(function () {
		$("#kyc_type").change(function () {
			if ($(this).val() == "0") {
				$("#ifYes1").show();
			} else {
				$("#ifYes1").hide();
			}
			if ($(this).val() == "1") {
				$("#ifYes2").show();
			} else {
				$("#ifYes2").hide();
			}
			if ($(this).val() == "2") {
				$("#ifYes3").show();
			} else {
				$("#ifYes3").hide();
			}
		});
	});


	function checkBoxSelected() {
   
	//    alert("test")
		var question_type = "Report"
		var questionJobID = "285"

	   
		
	   
		var jobReportType = document.getElementById("report_id").value;
		alert('id'+jobReportType)		


	   
		var exportUrl = "https://feedmypockets.com/HR-Admin/report_list_export.php?questionType="+question_type+"&job_id="+questionJobID+"&jobReportType="+jobReportType;

		$("#export_url").attr('href', exportUrl);
	   
   
	}


	




$(function () {
	$("#track").change(function () {
		if ($(this).val() == "1") {
			$("#showuser").show();
			$("#showfrom").show();
			$("#showto").show();
			$("#showfilter").show();
		} else {
		    $("#showuser").hide();
		    $("#showfrom").hide();
			$("#showto").hide();
			$("#showfilter").hide();
		}
	});
});

$(function () {
	$("#attendancebox").change(function () {
		if ($(this).val() == "1") {
			$("#attendanceemp").show();
			$("#attendancefrom").show();
			$("#attendanceto").show();
			$("#attendancebtn").show();
			
		} else {
		    $("#attendanceemp").hide();
		    $("#attendancefrom").hide();
			$("#attendanceto").hide();
			$("#attendancebtn").hide();
			
		}
	});
});

$('#walletbtn').click(function(){
	$('#gifbtn').show();
	$('#walletbtn').hide();
})

// setTimeout(function() {
// 	document.getElementById('gifimage').style.display='none'
//   }, 5000);


$(document).ready(function(){
	$("#walletmodal").modal('show');
});

$(document).ready(function(){

	var current_fs, next_fs, previous_fs; //fieldsets
	var opacity;
	var current = 1;
	var steps = $("fieldset").length;
	
	setProgressBar(current);
	
	$(".next").click(function(){
	
	current_fs = $(this).parent();
	next_fs = $(this).parent().next();
	
	//Add Class Active
	$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
	
	//show the next fieldset
	next_fs.show();
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
	step: function(now) {
	// for making fielset appear animation
	opacity = 1 - now;
	
	current_fs.css({
	'display': 'none',
	'position': 'relative'
	});
	next_fs.css({'opacity': opacity});
	},
	duration: 500
	});
	setProgressBar(++current);
	});
	
	$(".previous").click(function(){
	
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();
	
	//Remove class active
	$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
	
	//show the previous fieldset
	previous_fs.show();
	
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
	step: function(now) {
	// for making fielset appear animation
	opacity = 1 - now;
	
	current_fs.css({
	'display': 'none',
	'position': 'relative'
	});
	previous_fs.css({'opacity': opacity});
	},
	duration: 500
	});
	setProgressBar(--current);
	});
	
	function setProgressBar(curStep){
	var percent = parseFloat(100 / steps) * curStep;
	percent = percent.toFixed();
	$(".progress-bar")
	.css("width",percent+"%")
	}
	
	$(".submit").click(function(){
	return false;
	})
	
	});

	


	// $(function() { $('.datetimepicker12').datetimepicker({format:'YYYY-MM-DD'}); });
$(function () {
	$("#reportbox").change(function () {
		if ($(this).val() == "1") {
			
			$("#reportfrom").show();
			$("#reportto").show();
			$("#reportbtn").show();
		} else {
		    
		    $("#reportfrom").hide();
			$("#reportto").hide();
			$("#reportbtn").hide();
		}
	});
});

$(function () {
	$("#reportType").change(function () {
		if ($(this).val() == "2") {
			
			$("#reportchoose").show();
			
		} else {
		    
		    $("#reportchoose").hide();
			
		}
	});
});
var panVal = $('#id_number0').val();
var voterId = $('#id_number1').val();
var drivingLicense = $('#id_number2').val();

$(document).ready(function() {
    $('#report_table').DataTable( {
        dom: 'Bfrtip',
         "buttons": [
        {
            extend: 'print',
            title: 'report',
            exportOptions: {
                
                stripHtml: false,
            },
            text: '<i class="fa fa-print"></i> Print',
            className: "btn btn-primary float-right mb-2 mr-2"
            
        },
    ]
    } );
} );




$(document).ready(function() {
    $('#attendance_table').DataTable( {
        dom: 'Bfrtip',
        searching: false,
        buttons: [
            {
                extend: 'excelHtml5',
                text: '<i class="fa fa-file-excel-o"> </i> Export',
                titleAttr: 'Excel',
                className: "btn btn-primary float-right mb-2 mr-2"
            }, 
            
        ]
    } );
} );

$(document).ready(function() {
    $('#track_table').DataTable( {
        dom: 'Bfrtip',
        searching: false,
        buttons: [
            {
                extend: 'excelHtml5',
                text: '<i class="fa fa-file-excel-o"> </i> Export',
                titleAttr: 'Excel',
                className: "btn btn-primary float-right mb-2 mr-2"
            }
        ]
    } );
} );


// if (kyc_type == "2") {

// 	if (!validateVoter(voterid)) {
// 		resetErrorMsg();
// 		$("#id_number3").css({ "border-color": "#FF3349" });
// 	$('#id_number3').focus();
// 		document.getElementById('voterid_errormsg3').innerHTML = "<span style='color:red'><b>Enter Voter ID Number</b></span>";
// 		document.getElementById('voterid_errormsg3').style.display = "block";
// 	} else {
// 		document.getElementById('voterid_errormsg3').style.display = "none";
// 		$("#id_number3").css({ "border-color": "#ddd" });
// 	}
// }

// if (kyc_type == "1") {
// 	if (!validateDriving(drivingVal)) {
// 		resetErrorMsg();
// 		$("#id_number2").css({ "border-color": "#FF3349" });
// 		$('#id_number2').focus();
// 		document.getElementById('id_number_errormsg2').innerHTML = "<span style='color:red'><b>Enter Driving ID Number</b></span>";
// 		document.getElementById('id_number_errormsg2').style.display = "block";
// 	} else {
// 		document.getElementById('id_number_errormsg2').style.display = "none";
// 		$("#id_number2").css({ "border-color": "#ddd" });
// 	}
// }

// if (kyc_type == "0") {
// 	if (!validatePAN(panVal)) {
// 		resetErrorMsg();
// 		$("#id_number1").css({ "border-color": "#FF3349" });
//     	$('#id_number1').focus();
// 		document.getElementById('id_number_errormsg1').innerHTML = "<span style='color:red'><b>Enter PAN ID Number</b></span>";
// 		document.getElementById('id_number_errormsg1').style.display = "block";
// 	} else {
// 		document.getElementById('id_number_errormsg1').style.display = "none";
// 		$("#id_number1").css({ "border-color": "#ddd" });
// 	}


// }



// function validatePAN(panVal){ 
//         var regex = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/; 
//         if(panVal.length > 1 && panVal.length < 11) { 
               
//                     return regex.test(panVal); 
//                 }

            
//         };
        
//           function validateDriving(drivingVal){ 
              
              
//         var reg1 =/^([a-zA-Z]){2}([0-9]){13}?$/; 
//         if(drivingVal.length > 1 && drivingVal.length < 16) { 
               
//                     return reg1.test(drivingVal); 
//                 }

            
//         };
        
//             function validateVoter(voterid){ 
//         var reg2 = /^([a-zA-Z]){3}([0-9]){7}?$/; 
//         if(voterid.length > 1 && voterid.length < 11) { 
               
//                     return reg2.test(voterid); 
//                 }

            
//         };
        
        
        

    function getSelected() {
        //Reference the Table.
        var grid = document.getElementById("select_table");
 
        //Reference the CheckBoxes in Table.
        var checkBoxes = grid.getElementsByTagName("INPUT");
        var message = "Id Name\n";
 
        //Loop through the CheckBoxes.
        for (var i = 0; i < checkBoxes.length; i++) {
            if (checkBoxes[i].checked) {
                var row = checkBoxes[i].parentNode.parentNode;
                message += row.cells[1].innerHTML;
                message += "   " + row.cells[2].innerHTML;
                message += "   " + row.cells[3].innerHTML;
                message += "\n";
            }
        }
 
        //Display selected Row data in Alert Box.
        alert(message);
    }
