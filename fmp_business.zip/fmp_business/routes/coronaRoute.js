var express = require('express');
var router = express.Router();
var coronaService = require('../services/coronaService');

router.get('/alllist', function(req, res, next) {
    function getList(error, data) {
        if(error) {
            console.log(error);
            res.json(404, {
                error: true,
                message: 'Not Found'
            })
        } else {
            console.log(data);
            var todayCount = data.key_values
            console.log('today', todayCount);
            var totalCount = data.statewise;
            var totalRecovered = parseInt((totalCount[0].confirmed) - (totalCount[0].active))
            console.log('rec', totalRecovered)
            console.log('total', totalCount[0].confirmed);
            var state = [];
            for(var i = 1; i<totalCount.length; i++) {
                var stateData = totalCount[i]
                console.log('st', stateData);
                state.push(stateData);
            }
            for(var j=0; j<state.length; j++) {
                var todayState = state[j].delta.active
                console.log('tost', todayState);
                state[j].todayState = todayState;
            }
            console.log('s', state);
            res.render('admin/corona', {
               layout: 'layout-c',
               title: "COVID-2019 INDIA",
               list: data,
               todayCount: todayCount,
               totalCount: totalCount,
               totalRecovered: totalRecovered,
               state: state
           })
        }
    }
    coronaService.getList(getList);
})



module.exports = router;