var express = require('express');
var router = express.Router();
var creditService = require('../services/creditService');

router.get('/:id/balance', function (req, res, next) {
    // var id = (res.locals.user[0]).user_id;
    var id = req.params.id;
    function getWalletBalance(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/mainWallet', {
                layout: 'layout',
                title: 'Wallet',
                wallet: JSON.parse(data).wallet,
                transactions: JSON.parse(data).transactions
            })
        }
    }
    creditService.getWalletBalance(id, getWalletBalance)
})

router.post('/recharge', function (req, res, next) {
    var inputData = req.body;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/beta/wallet/balance');
        }
    }
    creditService.rechargeWallet(inputData, callback);
});

router.get('/:id/remaining', function (req, res, next) {
    var id = req.params.id;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
        }
    }
    callback();
})


router.get('/:id/todaycount', function (req, res, next) {
    var id = req.params.id;
    var async = require('async');
    var man = 0;
    var todayVerify = 0;
    var todayApplication = 0;
    var todayTraining = 0;
    var todayAchieved = 0;
    var todayApplied = 0;
    var todaySelected = 0;
    var todayReference = 0;
    var todayReference_stat = 0;
    var todayAmazon = 0;
    var todayAmazon_stat = 0;


    function todayCount(error, data) {
        if (error) {
            console.log(error);
            res.json(404, {
                error: true,
                message: 'Not Found'
            })
        } else {
            console.log(data);
            connection.query('SELECT * FROM login WHERE id=?', [id], function (error, admin) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(admin);
                    connection.query('SELECT * FROM fmp_codes WHERE updated_by=? AND type="amazon_pay" AND status = "notActive" AND DATE(updated_at) = DATE(CURRENT_DATE) ', [id], function (amazon) {
                        if (error) {
                            console.log(error);
                        } else {
                            if (amazon.length < 1) {
                                todayAmazon = 0;
                                todayAmazon_stat = 0;

                            } else {

                            }
                            console.log(amazon);
                            todayAmazon = (amazon.length) * 2
                            todayAmazon_stat = amazon.length;
                            connection.query('SELECT * FROM job_applications WHERE reference_from=? AND (status="Applied" OR status="ShortList" OR status="Rejected" OR status="Blocked") AND DATE(applied_at) = DATE(CURRENT_DATE())', [admin[0].number], function (error, applied) {
                                if (error) {
                                    console.log(error);
                                } else {
                                    console.log(applied);
                                    todayApplied = applied.length + todayApplied;
                                    todayApplied_stat = applied.length;
                                    console.log('applied', todayApplied);
                                    connection.query('SELECT * FROM job_applications WHERE reference_from=? AND status!="Applied" AND status!="Rejected" AND status!="Blocked" AND DATE(applied_at) = DATE(CURRENT_DATE())', [admin[0].number], function (error, selected) {
                                        if (error) {
                                            console.log(error);
                                        } else {
                                            console.log(selected);
                                            todaySelected = (selected.length + todaySelected) * 2;
                                            console.log('selected', todaySelected);
                                            todayReference = todayApplied + todaySelected
                                            todayReference_stat = applied.length + selected.length;
                                            connection.query('SELECT COUNT(*) as verification_count FROM fmp_codes WHERE updated_by=? AND DATE(updated_at) = DATE(CURRENT_DATE) AND type="verification" ', [id], function (error, verification) {
                                                if (error) {
                                                    console.log(error);
                                                } else {
                                                    console.log(verification);
                                                    todayVerify = verification[0].verification_count
                                                    connection.query('SELECT COUNT(*) as application_count FROM fmp_codes WHERE updated_by=? AND DATE(updated_at) = DATE(CURRENT_DATE) AND type="application" ', [id], function (error, application) {
                                                        if (error) {
                                                            console.log(error);
                                                        } else {
                                                            console.log(application);
                                                            todayApplication = application[0].application_count * 2;
                                                            connection.query('SELECT COUNT(*) as training_count FROM fmp_codes WHERE updated_by=? AND DATE(updated_at) = DATE(CURRENT_DATE) AND type="training" ', [id], function (error, training) {
                                                                if (error) {
                                                                    console.log(error);
                                                                } else {
                                                                    console.log(training);
                                                                    todayTraining = training[0].training_count * 3;
                                                                    connection.query('SELECT * FROM login WHERE id=?', [id], function (error, number) {
                                                                        if (error) {
                                                                            console.log(error);
                                                                        } else {
                                                                            connection.query('SELECT * FROM job WHERE coordinator_phone=?', [number[0].number], function (error, job) {
                                                                                if (error) {
                                                                                    console.log(error);
                                                                                } else {
                                                                                    console.log(job);
                                                                                    async.eachSeries(job, function (data, callback) {
                                                                                        console.log(data.job_id);
                                                                                        connection.query('SELECT COUNT(*) as mandays FROM tracking WHERE job_id=? AND jobdate=CURRENT_DATE() AND clientapproval != "Absent" ', [data.job_id], function (error, mandays) {
                                                                                            if (error) {
                                                                                                console.log(error);
                                                                                            } else {
                                                                                                console.log(mandays);
                                                                                                man = mandays[0].mandays + man;
                                                                                            }
                                                                                            callback()
                                                                                        })
                                                                                    }, function (error, results) {
                                                                                        if (error) {
                                                                                            console.log(error);
                                                                                        } else {
                                                                                            todayAchieved = todayVerify + todayApplication + todayTraining + (man * 3) + todayReference + todayAmazon
                                                                                            res.json(200, {
                                                                                                error: false,
                                                                                                message: 'Found',
                                                                                                todayVerify: todayVerify,
                                                                                                todayApplication: todayApplication,
                                                                                                todayTraining: todayTraining,
                                                                                                todayVerify_stat: verification[0].verification_count,
                                                                                                todayApplication_stat: application[0].application_count,
                                                                                                todayTraining_stat: training[0].training_count,
                                                                                                todaymandays_stat: man,
                                                                                                todayManDays: man * 3,
                                                                                                todayAchieved: todayAchieved,
                                                                                                todayApplied: todayApplied,
                                                                                                todaySelected: todaySelected,
                                                                                                todayReference_stat: todayReference_stat,
                                                                                                todayReference: todayReference,
                                                                                                todayAmazon: todayAmazon,
                                                                                                todayAmazon_stat: todayAmazon_stat

                                                                                            })
                                                                                        }

                                                                                    })
                                                                                }
                                                                            })
                                                                        }
                                                                    })


                                                                }
                                                            })
                                                        }

                                                    })
                                                }
                                            })
                                        }
                                    })
                                }
                            })
                        }
                    })

                }
            })

        }
    }
    todayCount();
})

router.get('/:id/totaltarget', function (req, res, next) {
    var id = req.params.id;
    var async = require('async');
    var totalVerify = 0;
    var totalApplication = 0;
    var totalTraining = 0;
    var totalAchieved = 0;
    var totalApplied = 0;
    var totalSelected = 0;
    var totalReference = 0;
    var totalReference_stat = 0;
    var man = 0;
    var man_stat = 0;
    var points = 0;
    var totalAmazon = 0;
    var totalAmazon_stat = 0;

    function totalTarget(error, data) {
        if (error) {
            console.log(error);
            res.json(404, {
                error: true,
                message: 'Not Found'
            })
        } else {
            connection.query('SELECT * FROM employee_target WHERE user_id=? AND MONTH(target_date) = MONTH(CURRENT_DATE())', [id], function (error, total) {
                if (error) {

                } else {
                    console.log(total);
                    connection.query('SELECT * FROM fmp_codes WHERE updated_by=? AND MONTH(updated_at) = MONTH(CURRENT_DATE())', [id], function (error, amazon) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(amazon);
                            totalAmazon = (amazon.length) * 2
                            totalAmazon_stat = amazon.length;
                            connection.query('SELECT * FROM login WHERE id=?', [id], function (error, admin) {
                                if (error) {
                                    console.log(error);
                                } else {
                                    console.log(admin);
                                    connection.query('SELECT * FROM job_applications WHERE reference_from=? AND (status="Applied" OR status="ShortList" OR status="Rejected" OR status="Blocked") AND MONTH(applied_at) = MONTH(CURRENT_DATE()) ', [admin[0].number], function (error, applied) {
                                        if (error) {
                                            console.log(error);
                                        } else {
                                            console.log(applied);
                                            totalApplied = applied.length + totalApplied;
                                            totalApplied_stat = applied.length;
                                            console.log('applied', totalApplied);
                                            connection.query('SELECT * FROM job_applications WHERE reference_from=? AND status!="Applied" AND status!="Rejected" AND status!="ShortList" AND status!="Blocked"  AND MONTH(applied_at) = MONTH(CURRENT_DATE()) ', [admin[0].number], function (error, selected) {
                                                if (error) {
                                                    console.log(error);
                                                } else {
                                                    console.log(selected);
                                                    totalSelected = (selected.length + totalSelected) * 2;
                                                    console.log('selected', totalSelected);
                                                    totalReference = totalApplied + totalSelected
                                                    totalReference_stat = applied.length + selected.length;
                                                    connection.query('SELECT COUNT(*) as verification_count FROM fmp_codes WHERE updated_by=? AND MONTH(updated_at) = MONTH(CURRENT_DATE()) AND type="verification" ', [id], function (error, verification) {
                                                        if (error) {
                                                            console.log(error);
                                                        } else {
                                                            console.log(verification);
                                                            totalVerify = verification[0].verification_count
                                                            console.log('verify', totalVerify);
                                                            connection.query('SELECT COUNT(*) as application_count FROM fmp_codes WHERE updated_by=? AND MONTH(updated_at) = MONTH(CURRENT_DATE()) AND type="application" ', [id], function (error, application) {
                                                                if (error) {
                                                                    console.log(error);
                                                                } else {
                                                                    console.log(application);
                                                                    totalApplication = (application[0].application_count) * 2
                                                                    console.log('application', totalApplication);
                                                                    connection.query('SELECT COUNT(*) as training_count FROM fmp_codes WHERE updated_by=? AND MONTH(updated_at) = MONTH(CURRENT_DATE()) AND type="training" ', [id], function (error, training) {
                                                                        if (error) {
                                                                            console.log(error);
                                                                        } else {
                                                                            console.log(training);
                                                                            totalTraining = (training[0].training_count) * 3;
                                                                            connection.query('SELECT * FROM login WHERE id=?', [id], function (error, number) {
                                                                                if (error) {

                                                                                } else {
                                                                                    connection.query('SELECT * FROM job WHERE coordinator_phone=?', [number[0].number], function (error, job) {
                                                                                        if (error) {

                                                                                        } else {
                                                                                            console.log(job);
                                                                                            async.eachSeries(job, function (data, callback) {
                                                                                                console.log(data.job_id)
                                                                                                connection.query('SELECT COUNT(*) as mandays FROM tracking WHERE job_id=? AND MONTH(jobdate) = MONTH(CURRENT_DATE()) AND clientapproval != "Absent" ', [data.job_id], function (error, mandays) {
                                                                                                    if (error) {
                                                                                                        console.log(error);
                                                                                                    } else {
                                                                                                        console.log(mandays);
                                                                                                        man_stat = mandays[0].mandays + man_stat;

                                                                                                        console.log(man)
                                                                                                    }
                                                                                                    callback()
                                                                                                })
                                                                                            }, function (error, results) {
                                                                                                if (error) {
                                                                                                    console.log(error);
                                                                                                } else {
                                                                                                    console.log(results);
                                                                                                    totalAchieved = totalVerify + totalApplication + totalTraining + (man_stat * 3) + totalReference + totalAmazon

                                                                                                    res.json(200, {
                                                                                                        error: false,
                                                                                                        message: 'Found',
                                                                                                        totalVerify: totalVerify,
                                                                                                        totalApplication: totalApplication,
                                                                                                        totalTraining: totalTraining,
                                                                                                        totalVerify_stat: verification[0].verification_count,
                                                                                                        totalApplication_stat: application[0].application_count,
                                                                                                        totalTraining_stat: training[0].training_count,
                                                                                                        totalMandays_stat: man_stat,
                                                                                                        totalManDays: man_stat * 3,
                                                                                                        totalAchieved: totalAchieved,
                                                                                                        totalApplied: totalApplied,
                                                                                                        totalSelected: totalSelected,
                                                                                                        totalReference_stat: totalReference_stat,
                                                                                                        totalReference: totalReference,
                                                                                                        totalAmazon_stat: totalAmazon_stat

                                                                                                    })

                                                                                                }
                                                                                            })
                                                                                        }
                                                                                    })
                                                                                }
                                                                            })
                                                                        }
                                                                    })
                                                                }
                                                            })
                                                        }
                                                    })
                                                }
                                            })
                                        }
                                    })
                                }
                            })
                        }
                    })

                }
            })
        }
    }
    totalTarget();
})

module.exports = router;