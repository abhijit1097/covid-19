var express = require('express');
var router = express.Router();
var dashboardService = require('../services/dashboardService');

router.get('/', function (req, res, next) {
    var id = (res.locals.user[0]).user_id
    function getCategories(error, data) {
        if (error) {
             console.log(error);
            // res.redirect('/users/signin');
        } else {
            console.log(data);
            var category = JSON.parse(data).jobCategory;
            var all = JSON.parse(data).category;
            var reward = JSON.parse(data).reward;
            var finalAmount = JSON.parse(data).finalAmount;
            var finalCredited = JSON.parse(data).finalCredited;
            console.log('cat', category)
            var catArray = JSON.stringify(category);
            console.log('array', catArray)
            console.log(category.length);
            
            
            for(var k=0; k<= 9; k++) {
                if(category.length == 0) {
                    all[k].count = 0
                }
            }
            
            for (var i = 0; i < category.length; i++) {

                for (var j = 0; j <= 9; j++) {
                    if (all[j].id == category[i].category) {

                        all[j].count = category[i].count;
                        

                    } else {
                        //do nothing
                    }

                    if(all[j].count > 0) {
                        
                    } else {
                        all[j].count = 0;
                    }

                }
            }
            
            res.render('admin/dashboard', {
                layout: 'layout-admin',
                title: 'Dashboard',
                category: all,
		        jobCategory: category,
		        reward: reward,
		        finalAmount: finalAmount,
		        finalCredited: finalCredited

            })
        }
    }
    dashboardService.categories(id, getCategories);
})

module.exports = router;
