var express = require('express');
var router = express.Router();
var invoiceService = require('../services/invoiceService');

router.get('/', function(req, res, next) {
    res.render('admin/performa_invoice', {
        layout: 'layout-new',
        title: 'Invoices'
    })
})

router.get('/:id', function(req, res, next) {
    var id = req.params.id;
    function getInvoiceById(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.rednder('admin/invoice-detail', {
                layout: 'layout-admin',
                title: 'Invoice Details',
                invoice: data
            })
        }
    }
    invoiceService.getInvoiceById(id, getInvoiceById);
})

router.get('/:alias', function(req, res, next) {
    var alias = req.params.alias;
    function getInvoiceByAlias(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/invoice-detail', {
                layout: 'layout-admin',
                title: 'Invoice Detail',
                invoice: data
            })
        }
    }
    invoiceService.getInvoiceByAlias(alias, getInvoiceByAlias);
})

router.get('/create', function(req, res, next) {
    res.render('admin/invoice-create', {
        layout: 'layout-admin',
        title: 'Create Invoice'
    })
})

router.post('/create', function(req, res, next) {
    var inputData = req.body;
    var callback = function(error, data) {
       if(error) {
           console.log(error)
       } else {
           console.log(data);
           res.redirect('/invoices');
       }
    }
    invoiceService.create(inputData, callback);
});

router.get('/:alias/update', function(req, res, next) {
    var alias = req.params.alias;
    res.render('admin/invoice-update', {
        layout: 'layout-admin',
        title: 'Update Invoice'
    })
})

router.post('/:alias/update', function(req, res, next) {
    var alias = req.params.alias;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/invoices');
        }
    }
    var inputData = req.body;
    invoiceService.update(alias, inputData, callback);
});

router.get('/:id/update', function(req, res, next) {
    var id = req.params.id;
    res.render('admin/invoice-update', {
        layout: 'layout-admin',
        title: 'Update Invoice'
    })
})

router.post('/:id/update', function(req, res, next) {
    var id = req.params.id;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/invoices');
        }
    }
    var inputData = req.body;
    inputData.id = id;
    invoiceService.update(id, inputData, callback);
})

router.get('/:id/delete', function(req, res, next) {
    var id = req.params.id;
    function deleteInvoice(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/invoices');
        }
    }
    invoiceService.delete(id, deleteInvoice);
})

router.get('/:alias/delete', function(req, res, next) {
    var alias = req.params.alias;
    function deleteInvoice(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/invoices');
        }
    }
    invoiceService.delete(alias, deleteInvoice);
})

module.exports = router;