var express = require('express');
var router = express.Router();
var path = require('path');
var download = require('download-file');
const excel = require('exceljs');
var json2csvParser = require('json2csv').Parser;
var projectService = require('../services/projectService');
var employeeService = require('../services/employeeService');
var mediaService = require('../services/mediaService');
var nodemailer = require('nodemailer');
var fs = require('fs');
var handlebars = require('handlebars');
var openGeocoder = require('node-open-geocoder');
var mysql = require('mysql');
var moment = require('moment');
var MomentRange = require('moment-range');
const momentNew = MomentRange.extendMoment(moment);
var GeoPoint = require('geopoint');
var toCsv = require('to-csv');

var connection = mysql.createConnection({
    host: '103.212.121.23',
    user: 'fmp',
    password: 'FMP@#123123',
    database: 'feedmypockets',
    port: 3306
})

var NodeGeocoder = require('node-geocoder');

var geocoder = NodeGeocoder({
    provider: 'opencage',
    apiKey: '223d13acf3d041f4b6362a9ece4a7b8eYOUR-API-KEY'
});


router.post('/post/date', function (req, res, next) {
    var inputData = [];
    var temp = {};

    var len = req.body.start_date.length;
    console.log('len', len);
    for (var i = 0; i < len; i++) {
        temp[i] = req.body.start_time[i]
        inputData.push(temp[i]);
    }
    console.log('in', inputData);
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('INSERT INTO project_date (start_time, end_time) VALUES ?', [inputData.map(inputData => [inputData, inputData])], function (error, instered) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(instered);
                    res.redirect('/beta/projectsnew/post');
                }
            })
        }
    }
    callback();
})

router.get('/search', function (req, res, next) {
    res.render('admin/ex', {
        layout: 'layout-new',

    })
})

router.get('/postproject', function (req, res, next) {
    // var id = res.locals.user[0].user_id;
    res.render('admin/post1.hbs', {
        layout: 'layout-post',
        title: 'post project'
    })
})

router.get('/postproject/step2?:id', function (req, res, next) {
    var id = req.query.id;
    function getCategory(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('SELECT * FROM job_category', function (error, category) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(category);
                    for (var i = 0; i < category.length; i++) {
                        if (category[i].id == 1) {
                            category[i].alphabet = "A"
                        } else if (category[i].id == 2) {
                            category[i].alphabet = "B"
                        } else if (category[i].id == 3) {
                            category[i].alphabet = "C"
                        } else if (category[i].id == 4) {
                            category[i].alphabet = "D"
                        } else if (category[i].id == 5) {
                            category[i].alphabet = "E"
                        } else if (category[i].id == 6) {
                            category[i].alphabet = "F"
                        } else if (category[i].id == 7) {
                            category[i].alphabet = "G"
                        } else if (category[i].id == 8) {
                            category[i].alphabet = "H"
                        } else if (category[i].id == 9) {
                            category[i].alphabet = "I"
                        } else if (category[i].id == 10) {
                            category[i].alphabet = "J"
                        }
                    }
                    res.render('admin/post2.hbs', {
                        layout: 'layout-post',
                        title: 'Choose Category',
                        category: category,
                        id: id
                    })
                }
            })
        }
    }
    getCategory();
})

router.get('/postproject/step/3?:id', function (req, res, next) {
    var id = req.query.id;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            connection.query('SELECT * FROM client_requirements JOIN job_roles ON client_requirements.project_category = job_roles.category_id WHERE client_requirements.id=?', [id], function (error, roles) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(roles);
                    for(var i=0; i< roles.length; i++) {
                        roles[i].name_id = roles[i].role_title.charAt(0)
                        console.log('rol', roles[i].name_id)
                    }
                    res.render('admin/post3', {
                        layout: 'layout-post',
                        title: "Choose Job Role",
                        roles: roles,
                        id: id
                    })
                }
            })

        }
    }
    callback();
})


router.get('/step/4?:id', function (req, res, next) {
    var id = req.query.id;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            res.render('admin/post4', {
                layout: 'layout-post',
                title: 'Choose Role Type',
                id: id
            })
        }
    }
    callback();
})

router.post('/post/4/create?:id', function(req, res, next) {
    var id = req.query.id;
    var role_type = req.body.role_type;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET role_type=? WHERE id=?', [role_type, id], function(error, roleType) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(roleType);
                    res.redirect('/beta/projectsnew/step5?id='+id);
                }
            })
        }
    }
    callback();
})

router.get('/step5?:id', function(req, res, next) {
    var id = req.query.id;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/post5', {
                layout: 'layout-post',
                title: 'Choose Project Date',
                id: id
            })
        }
    }
    callback();
})

router.post('/post/5/create?:id', function(req, res, next) {
    var id = req.query.id;
    var start_date = req.body.start_date
    var end_date = req.body.end_date
    console.log('st', start_date)
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            console.log('sat', start_date)
            console.log('end', end_date)
            connection.query('UPDATE client_requirements SET start_date=?, end_date=? WHERE id=?', [start_date, end_date, id], function(error, updated) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(updated);
                    res.redirect('/beta/projectsnew/post/step/6?id='+id);
                }
            })
        }
    }
    callback();
})

router.get('/post/step/6?:id', function(req, res, next) {
    var id = req.query.id;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/post6', {
                layout: 'layout-post',
                title: 'Choose Time',
                id: id
            })

        }
    }
    callback();
})

router.get('/7?:id', function(req, res, next) {
    var id = req.query.id;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/post7', {
                layout: 'layout-post',
                title: 'Choose Time',
                id: id
            })

        }
    }
    callback();
})


router.get('/choose/city?:id', function(req, res, next) {
    var id = req.query.id;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/post8', {
                layout: 'layout-post',
                title: 'Choose Time',
                id: id
            })

        }
    }
    callback();
})


router.post('/post/7/create?:id', function(req, res, next) {
    var id = req.query.id;
    var male_count = req.body.male_count;
    var female_count = req.body.female_count;
    var any_count = req.body.any_count;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET male_count=?, female_count=?, any_count=? WHERE id=?', [male_count, female_count, any_count, id], function(error, updated) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(updated);
                    res.redirect('/beta/projectsnew/choose/city?id='+id);
                }
            })
        }
    }
    callback();
})

router.post('/post/6/create?:id', function(req, res, next) {
    var id = req.query.id;
    var hour = req.body.jobdetails1;
    var minute = req.body.jobdetails2;
    var dayFormat = req.body.jobdetails3;
    var diff = req.body.jobdetails4;
    var newTime = hour+":"+minute+""+dayFormat
    console.log('end', newTime)
    const number = moment(newTime, ["h:mm A"]).format("HH:mm");
    console.log(number);
    var end_time = moment(number, 'HH:mm:ss').add(diff, 'hours').format('HH:mm');
    console.log('end', end_time)
    
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET start_time=?, end_time=? WHERE id=?', [number, end_time, id], function(error, time) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(time);
                    res.redirect('/beta/projectsnew/7?id='+id)
                }
            })
        }
    }
    callback();
})

router.post('/post/8/create?:id', function(req, res, next) {
    var id = req.query.id;
    var city = req.body.city;
    console.log('city', city)
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET city=? WHERE id=?', [city, id], function(error, updated) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(updated);
                    connection.query('SELECT * FROM client_requirements WHERE id=?', [id], function(error, project) {
                        if(error) {
                            console.log(error);
                        } else {
                            console.log(project);
                            console.log(project);
                            var start_date = moment(project[0].start_date).format("YYYY-MM-DD");
                            var end_date = moment(project[0].end_date).format("YYYY-MM-DD");
                            var newDaylist = [];
                            var getDaysArray = function (start, end) {
                                for (var arr = [], dt = start; dt <= end; dt.setDate(dt.getDate() + 1)) {
                                    arr.push(new Date(dt));
                                }
                                return arr;
        
                            };
                            var daylist = []
                            daylist = getDaysArray(new Date(start_date), new Date(end_date));
                            console.log(daylist.length)
        
                            var optionVal = new Array();
                            for (var i = 0; i < daylist.length; i++) {
                               // optionVal.push({dates: moment(daylist[i]).format("YYYY-MM-DD"), start_time: moment(project[0].start_time, "HH:mm:ss").format("hh:mm A"), end_time: moment(project[0].end_time, "HH:mm:ss").format("hh:mm A"), male_count: project[0].male_count, female_count: project[0].female_count })
                                optionVal.push({dates: moment(daylist[i]).format("YYYY-MM-DD"), start_time: project[0].start_time, end_time: project[0].end_time, male_count: project[0].male_count, female_count: project[0].female_count })

                            }
                            let values=optionVal.reduce((o,a)=>{
                                let ini=[];
                                ini.push(a.dates);
                                ini.push(a.start_time);
                                ini.push(a.end_time);
                                ini.push(a.male_count);
                                ini.push(a.female_count);
                                o.push(ini);
                                return o
                          },[])
                          console.log(values);
                            console.log('op', optionVal)
                            connection.query('INSERT INTO project_date (date, start_time, end_time, male_count, female_count) VALUES ?', [values], function(error, inserted) {
                                if(error) {
                                    console.log(error);
                                } else {
                                    console.log(inserted);
                                    res.redirect('/')
                                }
                            })
                        }
                    })
                    
                }
            })
        }
    }
    callback();
})


router.post('/post/3/create?:id', function (req, res, next) {
    var id = req.query.id;
    var job_role = req.body.job_role;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET job_role=? WHERE id=?', [job_role, id], function (error, updated) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(updated);
                    res.redirect('/beta/projectsnew/step/4?id=' + id)
                }
            })
        }
    }
    callback();
})

router.post('/post1/create', function (req, res, next) {
    var title = req.body.project_title;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('INSERT INTO client_requirements SET project_title=?', [title], function (error, inserted) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(inserted.insertId);
                    connection.query('SELECT * FROM client_requirements WHERE id=?', [inserted.insertId], function (error, project) {
                        if (error) {
                            console.log(error);
                        } else {
                            res.redirect('/beta/projectsnew/postproject/step2?id=' + project[0].id);
                        }
                    })

                }
            })
        }
    }
    callback();
})

router.post('/post2/create?:id', function (req, res, next) {
    var id = req.query.id;
    var category = req.body.project_category;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET project_category=? WHERE id=?', [category, id], function (error, category) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(category);
                    res.redirect('/beta/projectsnew/postproject/step/3?id=' + id)
                }
            })
        }
    }
    callback();
})


router.get('/:id/projectdetails', function (req, res, next) {
    var id = req.params.id;

    // const start = new Date(2012, 0, 15);
    // const end   = new Date(2012, 4, 23);
    // var range = new Array()
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('SELECT client_requirements.id, client_requirements.project_title, client_requirements.project_category, client_requirements.city, client_requirements.job_role, client_requirements.role_type, client_requirements.start_time, client_requirements.end_time, client_requirements.start_date, client_requirements.end_date, client_requirements.male_count, client_requirements.female_count, client_requirements.any_count, client_requirements.posted_on, job_category.category_name, job_category.category_image, job_roles.role_id, job_roles.role_title, job_roles.role_description, job_roles.role_image FROM client_requirements JOIN job_category ON client_requirements.project_category=job_category.id JOIN job_roles ON client_requirements.job_role=job_roles.role_id WHERE client_requirements.id=?', [id], function (error, project) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(project);
                    var start_date = moment(project[0].start_date).format("YYYY-MM-DD");
                    var end_date = moment(project[0].end_date).format("YYYY-MM-DD");
                    project[0].start_time = moment(project[0].start_time, "HH:mm").format('hh:mm A');
                    project[0].end_time = moment(project[0].end_time, "HH:mm").format('hh:mm A');
                    project[0].totalCount = project[0].male_count+project[0].female_count+project[0].any_count;
                    var newDaylist = [];
                    var getDaysArray = function (start, end) {
                        for (var arr = [], dt = start; dt <= end; dt.setDate(dt.getDate() + 1)) {
                            arr.push(new Date(dt));


                        }
                        return arr;

                    };
                    var daylist = []
                    daylist = getDaysArray(new Date(start_date), new Date(end_date));
                    console.log(daylist.length)

                    var optionVal = new Array();
                    for (var i = 0; i < daylist.length; i++) {
                        optionVal.push({ id: i, dates: moment(daylist[i]).format("YYYY-MM-DD"), start_time: moment(project[0].start_time, "HH:mm:ss").format("hh:mm A"), end_time: moment(project[0].end_time, "HH:mm:ss").format("hh:mm A"), male_count: project[0].male_count, female_count: project[0].female_count })
                    }

                    connection.query('SELECT * FROM job_goals WHERE job_id=?', [id], function(error, goals) {
                        if(error) {
                            console.log(error);
                        } else {
                            console.log(goals);
                            if(goals.length < 1) {
                                project[0].goal = 0;
                            } else {
                                project[0].goal = 1;
                                
                                
                            }
                        }
                        connection.query('SELECT * FROM job_target WHERE job_id=?', [id], function(error, target) {
                            if(error) {
                                console.log(error);
                            } else {
                                console.log(target);
                                if(target.length < 1) {
                                    project[0].target = 0;
                                } else {
                                    project[0].target = 1;
                                }
                            }
                            res.render('admin/postnew', {
                                layout: 'layout-new',
                                project: optionVal,
                                details: project
                            })
                        })
                        
                    })
                }
            })
        }
    }
    callback();
})

router.post('/goals/create', function(req, res, next) {
    var job_id = req.body.job_id;
    var primaryGoal = req.body.primaryGoal;
    var target = req.body.target;
    var usp = req.body.usp;
    var conversion = req.body.conversion;
    var downloads = req.body.downloads;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('INSERT INTO job_goals SET job_id=?, primaryGoal=?, target=?, usp=?, conversion=?, downloads=?', [job_id, primaryGoal, target, usp, conversion, downloads], function(error, inserted) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(inserted);
                    res.redirect('/beta/projectsnew/'+job_id+'/projectdetails');
                }
            })
        }
    }
    callback();
})

router.post('/editproject', function(req, res, next) {
    var project_title = req.body.project_title;
    var id = req.body.job_id;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET project_title=? WHERE id=?', [project_title, id], function(error, updated) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(updated);
                    res.redirect('/beta/projectsnew/'+id+'/projectdetails')
                }
            })
        }
    }
    callback();
})

router.post('/targetaudience', function(req, res, next) {
    var job_id = req.body.job_id;
    var target_audience = req.body.audience_type;
    var audience_type = req.body.all_type;
    var age_group = req.body.age_group;
    var gender = req.body.gender;
    var occupation = req.body.occupation;
    var income = req.body.income;
    var industry = req.body.industry;
    var employee_size = req.body.employee_size;
    var company_age = req.body.company_age;
    var designation = req.body.designation;
    var company_type = req.body.company_type;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(target_audience);
            if(target_audience == "No") {
                console.log('target_audience', target_audience);

                connection.query('INSERT INTO job_target SET job_id=?, target_audience=?', [job_id, target_audience], function(error, insertOne) {
                    if(error) {
                        console.log(error);
                    } else {
                        console.log(insertOne);
                    }
                })
            } else if(target_audience == "Yes"){    
                if(audience_type == "Business") {
                    connection.query('INSERT INTO job_target SET job_id=?, target_audience=?, audience_type=?, industry=?, employee_size=?, company_age=?, designation=?, company_type=?', [job_id, target_audience, audience_type, industry, employee_size, company_age, designation, company_type], function(error, insertTwo) {
                        if(error) {
                            console.log(error);
                        } else {
                            console.log(insertTwo);
                        }
                    })
                } else if(audience_type == "Consumer") {
                    connection.query('INSERT INTO job_target SET job_id=?, target_audience=?, audience_type=?, age_group=?, gender=?, occupation=?, income=?', [job_id, target_audience, audience_type, age_group, gender, occupation, income], function(error, insertThree) {
                        if(error) {
                            console.log(error);
                        } else {
                            console.log(insertThree);
                        }
                    })
                }
            }
            res.redirect('/beta/projectsnew/'+job_id+'/projectdetails')

        }
    }
    callback()

})


router.post('/travelexpenses', function(req, res, next) {
    var job_id = req.body.job_id;
    var travel_types = req.body.travel_type;
    var bike_required = req.body.travel_yes;
    var travel_range = req.body.travel_range;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(travel_types);
            if(travel_types == "No") {
                console.log('travel_types', travel_types);

                connection.query('INSERT INTO job_travelling SET job_id=?, travel_types=?', [job_id, travel_types], function(error, insertOne) {
                    if(error) {
                        console.log(error);
                    } else {
                        console.log(insertOne);
                    }
                })
            } else if(travel_types == "Yes"){    
                if(bike_required == "Yes") {
                    connection.query('INSERT INTO job_travelling SET job_id=?, travel_types=?, bike_required=?, travel_range=?', [job_id, travel_types, bike_required, travel_range], function(error, insertTwo) {
                        if(error) {
                            console.log(error);
                        } else {
                            console.log(insertTwo);
                        }
                    })
                } else if(bike_required == "No") {
                    connection.query('INSERT INTO job_travelling SET job_id=?, travel_types=?, bike_required=?', [job_id, travel_types, bike_required], function(error, insertThree) {
                        if(error) {
                            console.log(error);
                        } else {
                            console.log(insertThree);
                        }
                    })
                }
            }
            res.redirect('/beta/projectsnew/'+job_id+'/projectdetails')

        }
    }
    callback();
})

module.exports = router;