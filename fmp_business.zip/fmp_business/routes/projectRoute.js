var express = require('express');
var router = express.Router();
var path = require('path');
var download = require('download-file');
const excel = require('exceljs');
var json2csvParser = require('json2csv').Parser;
var projectService = require('../services/projectService');
var employeeService = require('../services/employeeService');
var mediaService = require('../services/mediaService');
var nodemailer = require('nodemailer');
var fs = require('fs');
var handlebars = require('handlebars');
var openGeocoder = require('node-open-geocoder');
var mysql = require('mysql');
var moment = require('moment');
var MomentRange = require('moment-range');
const momentNew = MomentRange.extendMoment(moment);
var GeoPoint = require('geopoint');
var toCsv = require('to-csv');

var connection = mysql.createConnection({
    host: '103.212.121.23',
    user: 'fmp',
    password: 'FMP@#123123',
    database: 'feedmypockets',
    port: 3306
})

var NodeGeocoder = require('node-geocoder');

var geocoder = NodeGeocoder({
    provider: 'opencage',
    apiKey: '223d13acf3d041f4b6362a9ece4a7b8eYOUR-API-KEY'
});


// router.get('/list?:id', function (req, res, next) {
//     var id = req.query.id;
//     function listProjects(error, data) {
//         if (error) {
//             console.log(error);
//         } else {
//             console.log(data);
//             res.render('admin/project', {
//                 layout: 'layout-admin',
//                 title: 'My Projects',
//                 projects: data,
//                 id: id
//             })
//         }
//     }
//     projectService.listProjects(id, listProjects);
// });


router.get('/list/:id', function (req, res, next) {
    var id = req.params.id;
    function listProjects(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            var projectLength = JSON.parse(data).projectLength;
            var listLength = JSON.parse(data).listLength;
            if (projectLength == 0 && listLength == 0) {
                var length = 0
            }
            res.render('admin/project', {
                layout: 'layout-admin',
                projects: JSON.parse(data).projects,
                pending: JSON.parse(data).list,
                length: length

            })
        }
    }
    projectService.listClientProjects(id, listProjects);
})


// router.get('/pending/list?:id', function (req, res, next) {
//     var id = req.query.id;
//     function listPendingProjects(error, data) {
//         if (error) {
//             console.log(error);
//         } else {
//             console.log(data);
//             res.render('admin/pending', {
//                 layout: 'layout-admin',
//                 title: 'Pending List',
//                 pending: JSON.parse(data).list

//             })

//         }
//     }

//     projectService.listPendingProjects(id, listPendingProjects);
// })

router.get('/details', function (req, res, next) {
    res.render('admin/project-detail', {
        layout: 'layout-detail',
        title: 'Project details'
    });
});

router.get('/create?:id', function (req, res, next) {
    var id = req.query.id;
    res.render('admin/project', {
        layout: 'layout-admin',
        title: 'Post Project',
        id: id
    })
})



router.post('/create?:id', function (req, res, next) {
    var id = req.query.id;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            // console.log(data.affectedRows);
            var json = JSON.parse(data).project;
            console.log(json);
            var contact = json[0].contact;
            var message = 'Thanks for posting your requirement.\n We promise to make your hiring experience smoother and quicker.\n Our business analyst will get in touch with you shortly.\n Happy hiring with FeedMyPockets'

            var readHTMLFile = function (path, callback) {
                fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                    if (err) {
                        throw err;
                        callback(err);
                    }
                    else {
                        callback(null, html);
                    }
                });
            }
            var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
            readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                var template = handlebars.compile(html);
                var replacements = {

                    email: json[0].emailid,
                    name: json[0].name,
                    contact: json[0].contact,
                    requirement: json[0].requirement,
                    category: json[0].category,
                    city: json[0].city,
                    description: json[0].jobdetails,
                    start_date: json[0].startdate,
                    appointment_date: json[0].appointment_date,
                    appointment_time: json[0].appointment_time,
                    posted_date: json[0].date_time,
                    time: json[0].time


                };

                var htmlToSend = template(replacements);
                var mailOptions = {
                    from: 'FeedMyPockets <business@feedmypockets.com>',
                    to: json[0].emailid,
                    subject: 'Job Request Received on ' + json[0].date_time + ' , ' + json[0].time,
                    text: 'Hello',
                    html: htmlToSend



                }

                console.log(mailOptions)

                transporter.sendMail(mailOptions, function (err, dt) {
                    console.log('mail error', err)
                    console.log('mail success', dt)
                    if (err) {
                        res.json(500, {
                            error: true,
                            error: err
                        })
                    } else {

                        res.redirect('/beta/projects/list?id=' + id);
                    }


                })



            });

        }

    }

    var inputData = req.body;
    projectService.create(inputData, callback);
});




router.post('/create/post', function (req, res, next) {
    var id = res.locals.user[0].user_id;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            // console.log(data.affectedRows);
            var json = JSON.parse(data).project;
            console.log(json);
            var contact = json[0].contact;
            var message = 'Thanks for posting your requirement.\n We promise to make your hiring experience smoother and quicker.\n Our business analyst will get in touch with you shortly.\n Happy hiring with FeedMyPockets'

            var readHTMLFile = function (path, callback) {
                fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                    if (err) {
                        throw err;
                        callback(err);
                    }
                    else {
                        callback(null, html);
                    }
                });
            }
            var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
            readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                var template = handlebars.compile(html);
                var replacements = {

                    email: json[0].emailid,
                    name: json[0].name,
                    contact: json[0].contact,
                    requirement: json[0].requirement,
                    category: json[0].category,
                    city: json[0].city,
                    description: json[0].jobdetails,
                    start_date: json[0].startdate,
                    appointment_date: json[0].appointment_date,
                    appointment_time: json[0].appointment_time,
                    posted_date: json[0].date_time,
                    time: json[0].time


                };

                var htmlToSend = template(replacements);
                var mailOptions = {
                    from: 'FeedMyPockets <business@feedmypockets.com>',
                    to: json[0].emailid,
                    subject: 'Job Request Received on ' + json[0].date_time + ' , ' + json[0].time,
                    text: 'Hello',
                    html: htmlToSend



                }

                console.log(mailOptions)

                transporter.sendMail(mailOptions, function (err, dt) {
                    console.log('mail error', err)
                    console.log('mail success', dt)
                    if (err) {
                        res.json(500, {
                            error: true,
                            error: err
                        })
                    } else {

                        res.redirect('/beta/dashboard');
                    }


                })



            });

        }

    }

    var inputData = req.body;
    projectService.create(inputData, callback);
});





// router.get('/:alias/details', function (req, res, next) {
//     var alias = req.params.alias;
//     function getProjectByAlias(error, data) {
//         if (error) {
//             console.log(error);
//         } else {
//             console.log(data);
//             res.render('admin/project-detail', {
//                 layout: 'layout-admin',
//                 title: 'Project Details'
//             })
//         }
//     }
//     projectService.getProjectByAlias(alias, getProjectByAlias)
// });

// router.get('/details/:id', function (req, res, next) {
//     var id = req.params.id;

//     function trackProject(error, data) {
//         if (error) {
//             console.log(error);
//         } else {
//             console.log('track', data);
//             res.render('admin/project-detail', {
//                 title: 'Track Project',
//                 layout: 'layout',
//                 project: JSON.parse(data).track,
//                 id: id
//             })
//         }
//     }

//     projectService.trackProject(id, trackProject)


// })
router.get('/details/:id', function (req, res, next) {
    var id = req.params.id;
    var user_id = "1015"
    function getProjectDetails(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            var users = JSON.parse(data).users
            var attendance = JSON.parse(data).attendance;
            var clientApproval = "";
            for (var i = 0; i < users.length; i++) {
                if (attendance.length < 1) {
                    users[i].attendance = "Absent"

                }
                var found = false;
                for (var j = 0; j < attendance.length; j++) {

                    if (attendance[j].user_id == users[i].user_id) {
                        found = true;
                        break;

                    }

                }
                if (found == true) {
                    users[i].attendance = "present"
                    users[i].achievedHours = attendance[j].achievedHours
                    users[i].checkin = attendance[j].editedcheckin;
                    users[i].checkout = attendance[j].editedcheckout;
                } else {
                    users[i].attendance = "Absent"
                    users[i].achievedHours = "N/A"
                    users[i].checkin = "N/A"
                    users[i].checkout = "N/A"
                }

            }

            for (var k = 0; k < attendance.length; k++) {

                if (attendance[k].clientapproval == "No") {
                    console.log("No client Approval");
                    clientApproval = "No";

                } else {
                    clientApproval = "Yes"
                }
            }

            res.render('admin/project-detail', {
                layout: 'layout-detail',
                title: 'Project details',
                project: JSON.parse(data).project,
                track: JSON.parse(data).track,
                upload: JSON.parse(data).uploads,
                applicants: JSON.parse(data).applicants,
                spoc: JSON.parse(data).spoc,
                // report: JSON.parse(data).report,
                staff: JSON.parse(data).staff,
                employees: JSON.parse(data).employees,
                applied_stat: JSON.parse(data).applied,
                rejected_stat: JSON.parse(data).rejected,
                selected_stat: JSON.parse(data).selected,
                track_stat: JSON.parse(data).track_stat,
                area: JSON.parse(data).area,
                report_stat: JSON.parse(data).report_stat,
                users: users,
                attendance: attendance,
                clientApproval: clientApproval,
                id: id,
                // finalAmount: JSON.parse(data).finalAmount,
                // finalCredited: JSON.parse(data).finalCredited,
                // finalDebited: JSON.parse(data).finalDebited,
                transaction: JSON.parse(data).transaction,
                reports: JSON.parse(data).reports
            })
        }
    }
    projectService.getAllDetails(id, user_id, getProjectDetails);
})

router.post('/:id/reports/mail', function (req, res, next) {
    var id = req.params.id;
    var report_id = req.body.report_id;
    var from = req.body.from;
    var to = req.body.to;
    var email_to = req.body.emailId;
    var date = moment().format('YYYY-MM-DD');
    var user_id = req.body.user_id;

    function sendMail(error, data) {
        if (error) {
            console.log(error);
        } else {
            if (req.body.type == 1) {
                if (req.body.track == 0 && req.body.user_id == 'all') {
                    connection.query('SELECT tracking.jobdate as JobDate, fmp_user.user_id as UserId, fmp_user.full_name as Name, tracking.editedcheckin as CheckInTime, tracking.editedcheckout as CheckOutTime, tracking.check_in_latitude as CheckInLatitude , tracking.check_in_longitude as checkInLongitude, tracking.check_out_latitude as CheckOutLatitude, tracking.check_out_longitude as CheckOutLongitude, tracking.check_in_image as CheckInImage, tracking.check_out_image as CheckOutImage from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE  job.src_id=? AND tracking.jobdate=CURRENT_DATE ', [id], function (error, today) {
                        if (error) {
                            console.log(error);
                        } else {

                            var result = JSON.parse(JSON.stringify(today));

                            for (var k = 0; k < result.length; k++) {

                                var startTime = moment(result[k].editedcheckin, "HH:mm:ss");
                                var endTime = moment(result[k].editedcheckout, "HH:mm:ss");


                                if (endTime.isBefore(startTime)) {
                                    endTime.add(1, 'day');
                                }

                                var duration = moment.duration(endTime.diff(startTime));
                                var hours = parseInt(duration.asHours());
                                var minutes = parseInt(duration.asMinutes()) % 60;
                                console.log(hours + ' hour and ' + minutes + ' minutes.');
                                if (result[k].editedcheckout == null) {
                                    result[k].achievedHours = "0 hours and 0 minutes"
                                } else {
                                    result[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                                }
                            }

                            for (var j = 0; j < result.length; j++) {
                                result[j].check_in_lat_long = result[j].check_in_latitude + ' , ' + result[j].check_in_longitude
                                result[j].check_out_lat_long = result[j].check_out_latitude + ' , ' + result[j].check_out_longitude

                            }


                            for (var i = 0; i < result.length; i++) {
                                result[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_in_image
                                result[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_out_image
                                result[i].jobdate = moment(result[i].jobdate).format("DD MMMM - YYYY")
                            }

                            for (var l = 0; l < result.length; l++) {
                                // var resultOne;
                                result[l].JobDate = moment(result[l].JobDate).format("DD MMMM - YYYY");
                                result[l].UserId = result[l].UserId;
                                result[l].Name = result[l].Name;
                                result[l].CheckInTime = moment(result[l].CheckInTime, "HH:mm:ss").format("hh:mm A");
                                result[l].CheckOutTime = moment(result[l].CheckOutTime, "HH:mm:ss").format("hh:mm A");
                                result[l].CheckInLatitude = result[l].CheckInLatitude;
                                result[l].CheckInLongitude = result[l].CheckInLongitude;
                                result[l].CheckOutLatitude = result[l].CheckOutLatitude;
                                result[l].CheckOutLongitude = result[l].CheckOutLongitude;
                                result[l].CheckInImage = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[l].CheckInImage
                                result[l].CheckOutImage = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[l].CheckOutImage

                                var startTime = moment(result[l].CheckInTime, "HH:mm:ss");
                                var endTime = moment(result[l].CheckOutTime, "HH:mm:ss");

                                if (endTime.isBefore(startTime)) {
                                    endTime.add(1, 'day');
                                }

                                var duration = moment.duration(endTime.diff(startTime));
                                var hours = parseInt(duration.asHours());
                                var minutes = parseInt(duration.asMinutes()) % 60;
                                console.log(hours + ' hour and ' + minutes + ' minutes.');
                                if (result[l].CheckOutTime == null) {
                                    result[l].AchievedHours = "0 hours and 0 minutes"
                                } else {
                                    result[l].AchievedHours = hours + ' hour and ' + minutes + ' minutes.'
                                }

                            }
                            var readHTMLFile = function (path, callback) {
                                fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                                    if (err) {
                                        throw err;
                                        callback(err);
                                    }
                                    else {
                                        callback(null, html);
                                    }
                                });
                            }
                            var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
                            readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                                var template = handlebars.compile(html);
                                var replacements = {
                                    name: "abhijit"


                                };

                                var htmlToSend = template(replacements);
                                var mailOptions = {
                                    from: 'FeedMyPockets <business@feedmypockets.com>',
                                    to: email_to,
                                    subject: 'Job Request Received on',
                                    text: 'Hello',
                                    html: htmlToSend,
                                    attachments: [{ filename: 'report.csv', content: toCsv(result) }]

                                }

                                console.log(mailOptions)

                                transporter.sendMail(mailOptions, function (err, dt) {
                                    console.log('mail error', err)
                                    console.log('mail success', dt)
                                    if (err) {
                                        res.json(500, {
                                            error: true,
                                            error: err
                                        })
                                    } else {
                                        res.redirect('/beta/projects/details/' + id)
                                    }

                                })
                            });
                        }
                    })
                } else if (req.body.track == 0 && req.body.user_id !== 'all') {
                    connection.query('SELECT tracking.jobdate as JobDate, fmp_user.user_id as UserId, fmp_user.full_name as Name, tracking.editedcheckin as CheckInTime, tracking.editedcheckout as CheckOutTime, tracking.check_in_latitude as CheckInLatitude , tracking.check_in_longitude as checkInLongitude, tracking.check_out_latitude as CheckOutLatitude, tracking.check_out_longitude as CheckOutLongitude, tracking.check_in_image as CheckInImage, tracking.check_out_image as CheckOutImage from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE  job.src_id=? AND tracking.user_id=? AND tracking.jobdate= CURRENT_DATE ', [id, user_id], function (error, customize) {
                        if (error) {
                            console.log(error);
                        } else {
                            var result = JSON.parse(JSON.stringify(customize));

                            for (var k = 0; k < result.length; k++) {

                                var startTime = moment(result[k].editedcheckin, "HH:mm:ss");
                                var endTime = moment(result[k].editedcheckout, "HH:mm:ss");


                                if (endTime.isBefore(startTime)) {
                                    endTime.add(1, 'day');
                                }

                                var duration = moment.duration(endTime.diff(startTime));
                                var hours = parseInt(duration.asHours());
                                var minutes = parseInt(duration.asMinutes()) % 60;
                                console.log(hours + ' hour and ' + minutes + ' minutes.');
                                if (result[k].editedcheckout == null) {
                                    result[k].achievedHours = "0 hours and 0 minutes"
                                } else {
                                    result[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                                }
                            }

                            for (var j = 0; j < result.length; j++) {
                                result[j].check_in_lat_long = result[j].check_in_latitude + ' , ' + result[j].check_in_longitude
                                result[j].check_out_lat_long = result[j].check_out_latitude + ' , ' + result[j].check_out_longitude

                            }


                            for (var i = 0; i < result.length; i++) {
                                result[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_in_image
                                result[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_out_image
                                result[i].jobdate = moment(result[i].jobdate).format("DD MMMM - YYYY")
                            }

                            for (var l = 0; l < result.length; l++) {

                                result[l].JobDate = moment(result[l].JobDate).format("DD MMMM - YYYY");
                                result[l].UserId = result[l].UserId;
                                result[l].Name = result[l].Name;
                                result[l].CheckInTime = moment(result[l].CheckInTime, "HH:mm:ss").format("hh:mm A");
                                result[l].CheckOutTime = moment(result[l].CheckOutTime, "HH:mm:ss").format("hh:mm A");
                                result[l].CheckInLatitude = result[l].CheckInLatitude;
                                result[l].CheckInLongitude = result[l].CheckInLongitude;
                                result[l].CheckOutLatitude = result[l].CheckOutLatitude;
                                result[l].CheckOutLongitude = result[l].CheckOutLongitude;
                                result[l].CheckInImage = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[l].CheckInImage
                                result[l].CheckOutImage = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[l].CheckOutImage

                                var startTime = moment(result[l].CheckInTime, "HH:mm:ss");
                                var endTime = moment(result[l].CheckOutTime, "HH:mm:ss");

                                if (endTime.isBefore(startTime)) {
                                    endTime.add(1, 'day');
                                }

                                var duration = moment.duration(endTime.diff(startTime));
                                var hours = parseInt(duration.asHours());
                                var minutes = parseInt(duration.asMinutes()) % 60;
                                console.log(hours + ' hour and ' + minutes + ' minutes.');
                                if (result[l].CheckOutTime == null) {
                                    result[l].AchievedHours = "0 hours and 0 minutes"
                                } else {
                                    result[l].AchievedHours = hours + ' hour and ' + minutes + ' minutes.'
                                }

                            }
                            var readHTMLFile = function (path, callback) {
                                fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                                    if (err) {
                                        throw err;
                                        callback(err);
                                    }
                                    else {
                                        callback(null, html);
                                    }
                                });
                            }
                            var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
                            readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                                var template = handlebars.compile(html);
                                var replacements = {
                                    name: "abhijit"


                                };

                                var htmlToSend = template(replacements);
                                var mailOptions = {
                                    from: 'FeedMyPockets <business@feedmypockets.com>',
                                    to: email_to,
                                    subject: 'Job Request Received on',
                                    text: 'Hello',
                                    html: htmlToSend,
                                    attachments: [{ filename: 'report.csv', content: toCsv(resultOne) }]

                                }

                                console.log(mailOptions)

                                transporter.sendMail(mailOptions, function (err, dt) {
                                    console.log('mail error', err)
                                    console.log('mail success', dt)
                                    if (err) {
                                        res.json(500, {
                                            error: true,
                                            error: err
                                        })
                                    } else {
                                        res.redirect('/beta/projects/details/' + id)
                                    }
                                })
                            });
                        }
                    })
                }
                if (req.body.track == 1 && req.body.user_id == "all") {
                    connection.query('SELECT tracking.jobdate as JobDate, fmp_user.user_id as UserId, fmp_user.full_name as Name, tracking.editedcheckin as CheckInTime, tracking.editedcheckout as CheckOutTime, tracking.check_in_latitude as CheckInLatitude, tracking.check_in_longitude as CheckInLongitude, tracking.check_out_latitude as CheckOutLatitude, tracking.check_out_longitude as CheckOutLongitude, tracking.check_in_image as CheckInImage, tracking.check_out_image as CheckOutImage from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE  job.src_id=? AND tracking.jobdate BETWEEN ? AND ? ', [id, from, to], function (error, all) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(all);
                            var result = JSON.parse(JSON.stringify(all));

                            for (var l = 0; l < result.length; l++) {
                                // var resultOne;
                                result[l].JobDate = moment(result[l].JobDate).format("DD MMMM - YYYY");
                                result[l].UserId = result[l].UserId;
                                result[l].Name = result[l].Name;
                                result[l].CheckInTime = moment(result[l].CheckInTime, "HH:mm:ss").format("hh:mm A");
                                result[l].CheckOutTime = moment(result[l].CheckOutTime, "HH:mm:ss").format("hh:mm A");
                                result[l].CheckInLatitude = result[l].CheckInLatitude;
                                result[l].CheckInLongitude = result[l].CheckInLongitude;
                                result[l].CheckOutLatitude = result[l].CheckOutLatitude;
                                result[l].CheckOutLongitude = result[l].CheckOutLongitude;
                                result[l].CheckInImage = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[l].CheckInImage
                                result[l].CheckOutImage = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[l].CheckOutImage

                                var startTime = moment(result[l].CheckInTime, "HH:mm:ss");
                                var endTime = moment(result[l].CheckOutTime, "HH:mm:ss");

                                if (endTime.isBefore(startTime)) {
                                    endTime.add(1, 'day');
                                }

                                var duration = moment.duration(endTime.diff(startTime));
                                var hours = parseInt(duration.asHours());
                                var minutes = parseInt(duration.asMinutes()) % 60;
                                console.log(hours + ' hour and ' + minutes + ' minutes.');
                                if (result[l].CheckOutTime == null) {
                                    result[l].AchievedHours = "0 hours and 0 minutes"
                                } else {
                                    result[l].AchievedHours = hours + ' hour and ' + minutes + ' minutes.'
                                }

                            }

                            var readHTMLFile = function (path, callback) {
                                fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                                    if (err) {
                                        throw err;
                                        callback(err);
                                    }
                                    else {
                                        callback(null, html);
                                    }
                                });
                            }
                            var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
                            readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                                var template = handlebars.compile(html);
                                var replacements = {
                                    name: "abhijit"


                                };

                                var htmlToSend = template(replacements);
                                var mailOptions = {
                                    from: 'FeedMyPockets <business@feedmypockets.com>',
                                    to: email_to,
                                    subject: 'Job Request Received on',
                                    text: 'Hello',
                                    html: htmlToSend,
                                    attachments: [{ filename: 'report.csv', content: toCsv(result) }]

                                }

                                console.log(mailOptions)

                                transporter.sendMail(mailOptions, function (err, dt) {
                                    console.log('mail error', err)
                                    console.log('mail success', dt)
                                    if (err) {
                                        res.json(500, {
                                            error: true,
                                            error: err
                                        })
                                    } else {
                                        res.redirect('/beta/projects/details/' + id)
                                    }
                                })
                            });
                        }
                    })
                } else if (req.body.track == 1 && req.body.user_id !== 'all') {
                    connection.query('SELECT tracking.jobdate, fmp_user.user_id, fmp_user.full_name, tracking.editedcheckin, tracking.editedcheckout, tracking.check_in_latitude, tracking.check_in_longitude, tracking.check_out_latitude, tracking.check_out_longitude, tracking.check_in_image, tracking.check_out_image from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE tracking.user_id=? AND job.src_id=? AND tracking.jobdate BETWEEN ? AND ?', [user_id, id, from, to], function (error, user) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(user);
                            var result = JSON.parse(JSON.stringify(user));


                            for (var k = 0; k < result.length; k++) {

                                var startTime = moment(result[k].editedcheckin, "HH:mm:ss");
                                var endTime = moment(result[k].editedcheckout, "HH:mm:ss");


                                if (endTime.isBefore(startTime)) {
                                    endTime.add(1, 'day');
                                }

                                var duration = moment.duration(endTime.diff(startTime));
                                var hours = parseInt(duration.asHours());
                                var minutes = parseInt(duration.asMinutes()) % 60;
                                console.log(hours + ' hour and ' + minutes + ' minutes.');
                                if (result[k].editedcheckout == null) {
                                    result[k].achievedHours = "0 hours and 0 minutes"
                                } else {
                                    result[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                                }
                            }

                            for (var j = 0; j < result.length; j++) {
                                result[j].check_in_lat_long = result[j].check_in_latitude + ' , ' + result[j].check_in_longitude
                                result[j].check_out_lat_long = result[j].check_out_latitude + ' , ' + result[j].check_out_longitude
                            }


                            for (var i = 0; i < result.length; i++) {
                                result[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_in_image
                                result[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_out_image
                                result[i].jobdate = moment(result[i].jobdate).format("DD MMMM - YYYY")
                            }

                            for (var l = 0; l < result.length; l++) {

                                result[l].JobDate = moment(result[l].JobDate).format("DD MMMM - YYYY");
                                result[l].UserId = result[l].UserId;
                                result[l].Name = result[l].Name;
                                result[l].CheckInTime = moment(result[l].CheckInTime, "HH:mm:ss").format("hh:mm A");
                                result[l].CheckOutTime = moment(result[l].CheckOutTime, "HH:mm:ss").format("hh:mm A");
                                result[l].CheckInLatitude = result[l].CheckInLatitude;
                                result[l].CheckInLongitude = result[l].CheckInLongitude;
                                result[l].CheckOutLatitude = result[l].CheckOutLatitude;
                                result[l].CheckOutLongitude = result[l].CheckOutLongitude;
                                result[l].CheckInImage = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[l].CheckInImage
                                result[l].CheckOutImage = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[l].CheckOutImage

                                var startTime = moment(result[l].CheckInTime, "HH:mm:ss");
                                var endTime = moment(result[l].CheckOutTime, "HH:mm:ss");

                                if (endTime.isBefore(startTime)) {
                                    endTime.add(1, 'day');
                                }

                                var duration = moment.duration(endTime.diff(startTime));
                                var hours = parseInt(duration.asHours());
                                var minutes = parseInt(duration.asMinutes()) % 60;
                                console.log(hours + ' hour and ' + minutes + ' minutes.');
                                if (result[l].CheckOutTime == null) {
                                    result[l].AchievedHours = "0 hours and 0 minutes"
                                } else {
                                    result[l].AchievedHours = hours + ' hour and ' + minutes + ' minutes.'
                                }



                            }
                            var toCsv = require('to-csv');
                            var readHTMLFile = function (path, callback) {
                                fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                                    if (err) {
                                        throw err;
                                        callback(err);
                                    }
                                    else {
                                        callback(null, html);
                                    }
                                });
                            }
                            var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
                            readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                                var template = handlebars.compile(html);
                                var replacements = {
                                    name: "abhijit"


                                };

                                var htmlToSend = template(replacements);
                                var mailOptions = {
                                    from: 'FeedMyPockets <business@feedmypockets.com>',
                                    to: email_to,
                                    subject: 'Job Request Received on',
                                    text: 'Hello',
                                    html: htmlToSend,
                                    attachments: [{ filename: 'report.csv', content: toCsv(result) }]

                                }

                                console.log(mailOptions)

                                transporter.sendMail(mailOptions, function (err, dt) {
                                    console.log('mail error', err)
                                    console.log('mail success', dt)
                                    if (err) {
                                        res.json(500, {
                                            error: true,
                                            error: err
                                        })
                                    } else {
                                        res.redirect('/beta/projects/details/' + id);
                                    }
                                })

                            });
                        }
                    })
                }

            } else if (req.body.type == 2) {
                if (req.body.track == 0 && req.body.user_id == 'all') {
                    connection.query('SELECT fmp_user.user_id as UserId, fmp_user.full_name as Name, job_answers.answered_at as jobdate, job_questions.question as Question, job_answers.answer as Answer FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND job_answers.report_id=? AND DATE(job_answers.answered_at)=?', [id, report_id, date], function (error, today) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(today);
                            var result = JSON.parse(JSON.stringify(today));
                            for (var i = 0; i < today.length; i++) {
                                result[i].jobdate = moment(result[i].jobdate).format('DD MMMM -YYYY')
                            }


                            var readHTMLFile = function (path, callback) {
                                fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                                    if (err) {
                                        throw err;
                                        callback(err);
                                    }
                                    else {
                                        callback(null, html);
                                    }
                                });
                            }
                            var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
                            readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                                var template = handlebars.compile(html);
                                var replacements = {
                                    name: "abhijit"
                                };

                                var htmlToSend = template(replacements);
                                var mailOptions = {
                                    from: 'FeedMyPockets <business@feedmypockets.com>',
                                    to: email_to,
                                    subject: 'Job Request Received on',
                                    text: 'Hello',
                                    html: htmlToSend,
                                    attachments: [{ filename: 'report.csv', content: toCsv(result) }]

                                }

                                console.log(mailOptions)

                                transporter.sendMail(mailOptions, function (err, dt) {
                                    console.log('mail error', err)
                                    console.log('mail success', dt)
                                    if (err) {
                                        res.json(500, {
                                            error: true,
                                            error: err
                                        })
                                    } else {
                                        res.redirect('/beta/projects/details' + id);
                                    }

                                })
                            });

                        }

                    })
                } else if (req.body.track == 0 && req.body.user_id !== 'all') {
                    connection.query('SELECT fmp_user.user_id as UserId, fmp_user.full_name as Name, job_answers.answered_at as jobdate, job_questions.question as Question, job_answers.answer as Answer as Answer, job_answers.answered_at as jobdate, fmp_user.user_id as UserId FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND DATE(job_answers.answered_at)=?', [id, date], function (error, today) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(today);
                            var result = JSON.parse(JSON.stringify(today));
                            for (var i = 0; i < today.length; i++) {
                                result[i].jobdate = moment(result[i].jobdate).format('DD MMMM -YYYY')
                            }
                            var readHTMLFile = function (path, callback) {
                                fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                                    if (err) {
                                        throw err;
                                        callback(err);
                                    }
                                    else {
                                        callback(null, html);
                                    }
                                });
                            }
                            var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
                            readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                                var template = handlebars.compile(html);
                                var replacements = {
                                    name: "abhijit"


                                };

                                var htmlToSend = template(replacements);
                                var mailOptions = {
                                    from: 'FeedMyPockets <business@feedmypockets.com>',
                                    to: email_to,
                                    subject: 'Job Request Received on',
                                    text: 'Hello',
                                    html: htmlToSend,
                                    attachments: [{ filename: 'report.csv', content: toCsv(result) }]

                                }

                                console.log(mailOptions)

                                transporter.sendMail(mailOptions, function (err, dt) {
                                    console.log('mail error', err)
                                    console.log('mail success', dt)
                                    if (err) {
                                        res.json(500, {
                                            error: true,
                                            error: err
                                        })
                                    } else {
                                        res.redirect('/beta/projects/details' + id);
                                    }

                                })
                            });

                        }

                    })
                } else if (req.body.track == 1 && req.body.user_id == 'all') {
                    connection.query('SELECT fmp_user.user_id as UserId, fmp_user.full_name as Name, job_answers.answered_at as jobdate, job_questions.question as Question, job_answers.answer as Answer FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND DATE(job_answers.answered_at) BETWEEN  DATE(?) AND DATE(?) ', [id, from, to], function (error, today) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(today);
                            var result = JSON.parse(JSON.stringify(today));
                            for (var i = 0; i < today.length; i++) {
                                result[i].jobdate = moment(result[i].jobdate).format('DD MMMM -YYYY')
                            }
                            var readHTMLFile = function (path, callback) {
                                fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                                    if (err) {
                                        throw err;
                                        callback(err);
                                    }
                                    else {
                                        callback(null, html);
                                    }
                                });
                            }
                            var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
                            readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                                var template = handlebars.compile(html);
                                var replacements = {
                                    name: "abhijit"
                                };

                                var htmlToSend = template(replacements);
                                var mailOptions = {
                                    from: 'FeedMyPockets <business@feedmypockets.com>',
                                    to: email_to,
                                    subject: 'Job Request Received on',
                                    text: 'Hello',
                                    html: htmlToSend,
                                    attachments: [{ filename: 'report.csv', content: toCsv(result) }]

                                }

                                console.log(mailOptions)

                                transporter.sendMail(mailOptions, function (err, dt) {
                                    console.log('mail error', err)
                                    console.log('mail success', dt)
                                    if (err) {
                                        res.json(500, {
                                            error: true,
                                            error: err
                                        })
                                    } else {
                                        res.redirect('/beta/projects/details' + id);
                                    }

                                })
                            });

                        }

                    })

                } else if (req.body.track == 1 && req.body.user_id !== 'all') {
                    connection.query('SELECT fmp_user.user_id as UserId, fmp_user.full_name as Name, job_answers.answered_at as jobdate, job_questions.question as Question, job_answers.answer as Answer FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND job_answers.user_id=? AND  DATE(job_answers.answered_at) BETWEEN  DATE(?) AND DATE(?)', [id, user_id, from, to], function (error, today) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(today);
                            var result = JSON.parse(JSON.stringify(today));
                            for (var i = 0; i < today.length; i++) {
                                result[i].jobdate = moment(result[i].jobdate).format('DD MMMM -YYYY')
                            }
                            var readHTMLFile = function (path, callback) {
                                fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                                    if (err) {
                                        throw err;
                                        callback(err);
                                    }
                                    else {
                                        callback(null, html);
                                    }
                                });
                            }
                            var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
                            readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                                var template = handlebars.compile(html);
                                var replacements = {
                                    name: "abhijit"


                                };

                                var htmlToSend = template(replacements);
                                var mailOptions = {
                                    from: 'FeedMyPockets <business@feedmypockets.com>',
                                    to: email_to,
                                    subject: 'Job Request Received on',
                                    text: 'Hello',
                                    html: htmlToSend,
                                    attachments: [{ filename: 'report.csv', content: toCsv(result) }]

                                }

                                console.log(mailOptions)

                                transporter.sendMail(mailOptions, function (err, dt) {
                                    console.log('mail error', err)
                                    console.log('mail success', dt)
                                    if (err) {
                                        res.json(500, {
                                            error: true,
                                            error: err
                                        })
                                    } else {
                                        res.redirect('/beta/projects/details/' + id)
                                    }

                                })
                            });
                        }
                    })
                }
            }
        }
    }
    sendMail();
})

router.post('/:id/reports/download', function (req, res, next) {
    var id = req.params.id;
    var report_id = req.body.report_id;
    var from = req.body.from;
    var to = req.body.to;
    // var email_to = req.body.emailId;
    var date = moment().format('YYYY-MM-DD');
    var user_id = req.body.user_id;

    function sendMail(error, data) {
        if (error) {
            console.log(error);
        } else {
            if (req.body.type == 1) {
                if (req.body.track == 0 && req.body.user_id == 'all') {
                    connection.query('SELECT * from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE  job.src_id=? AND tracking.jobdate=CURRENT_DATE ', [id], function (error, today) {
                        if (error) {
                            console.log(error);
                        } else {

                            var result = JSON.parse(JSON.stringify(today));

                            for (var k = 0; k < result.length; k++) {

                                var startTime = moment(result[k].editedcheckin, "HH:mm:ss");
                                var endTime = moment(result[k].editedcheckout, "HH:mm:ss");


                                if (endTime.isBefore(startTime)) {
                                    endTime.add(1, 'day');
                                }

                                var duration = moment.duration(endTime.diff(startTime));
                                var hours = parseInt(duration.asHours());
                                var minutes = parseInt(duration.asMinutes()) % 60;
                                console.log(hours + ' hour and ' + minutes + ' minutes.');
                                if (result[k].editedcheckout == null) {
                                    result[k].achievedHours = "0 hours and 0 minutes"
                                } else {
                                    result[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                                }
                            }

                            for (var j = 0; j < result.length; j++) {
                                result[j].check_in_lat_long = result[j].check_in_latitude + ' , ' + result[j].check_in_longitude
                                result[j].check_out_lat_long = result[j].check_out_latitude + ' , ' + result[j].check_out_longitude
                            }


                            for (var i = 0; i < result.length; i++) {
                                result[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_in_image
                                result[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_out_image
                                result[i].jobdate = moment(result[i].jobdate).format("DD MMMM - YYYY")
                            }

                            let workbook = new excel.Workbook();
                            let worksheet = workbook.addWorksheet('Report');
                            worksheet.columns = [
                                { header: 'Date', key: 'jobdate', width: 20 },
                                { header: 'Name', key: 'full_name', width: 30 },
                                { header: 'check In', key: 'editedcheckin', width: 20 },
                                { header: 'check In lat,long', key: 'check_in_lat_long', width: 60 },
                                { header: 'check In Image', key: 'check_in_image', width: 100 },
                                { header: 'check Out', key: 'editedcheckout', width: 20 },
                                { header: 'check Out lat,long', key: 'check_out_lat_long', width: 60 },
                                { header: 'check out Image', key: 'check_out_image', width: 100 },
                                { header: 'Achieved Hours', key: 'achievedHours', width: 60 }
                            ];
                            worksheet.addRows(result);
                            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                            res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                            return workbook.xlsx.write(res)
                                .then(function () {
                                    res.status(200).end();
                                })


                        }
                    })
                } else if (req.body.track == 0 && req.body.user_id !== 'all') {
                    connection.query('SELECT * from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE  job.src_id=? AND tracking.user_id=? AND tracking.jobdate= CURRENT_DATE ', [id, user_id], function (error, customize) {
                        if (error) {
                            console.log(error);
                        } else {
                            var result = JSON.parse(JSON.stringify(customize));

                            for (var k = 0; k < result.length; k++) {

                                var startTime = moment(result[k].editedcheckin, "HH:mm:ss");
                                var endTime = moment(result[k].editedcheckout, "HH:mm:ss");


                                if (endTime.isBefore(startTime)) {
                                    endTime.add(1, 'day');
                                }

                                var duration = moment.duration(endTime.diff(startTime));
                                var hours = parseInt(duration.asHours());
                                var minutes = parseInt(duration.asMinutes()) % 60;
                                console.log(hours + ' hour and ' + minutes + ' minutes.');
                                if (result[k].editedcheckout == null) {
                                    result[k].achievedHours = "0 hours and 0 minutes"
                                } else {
                                    result[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                                }
                            }

                            for (var j = 0; j < result.length; j++) {
                                result[j].check_in_lat_long = result[j].check_in_latitude + ' , ' + result[j].check_in_longitude
                                result[j].check_out_lat_long = result[j].check_out_latitude + ' , ' + result[j].check_out_longitude
                            }


                            for (var i = 0; i < result.length; i++) {
                                result[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_in_image
                                result[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_out_image
                                result[i].jobdate = moment(result[i].jobdate).format("DD MMMM - YYYY")
                            }

                            let workbook = new excel.Workbook();
                            let worksheet = workbook.addWorksheet('Report');
                            worksheet.columns = [
                                { header: 'Date', key: 'jobdate', width: 20 },
                                { header: 'Name', key: 'full_name', width: 30 },
                                { header: 'check In', key: 'editedcheckin', width: 20 },
                                { header: 'check In lat,long', key: 'check_in_lat_long', width: 60 },
                                { header: 'check In Image', key: 'check_in_image', width: 100 },
                                { header: 'check Out', key: 'editedcheckout', width: 20 },
                                { header: 'check Out lat,long', key: 'check_out_lat_long', width: 60 },
                                { header: 'check out Image', key: 'check_out_image', width: 100 },
                                { header: 'Achieved Hours', key: 'achievedHours', width: 60 }
                            ];
                            worksheet.addRows(result);
                            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                            res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                            return workbook.xlsx.write(res)
                                .then(function () {
                                    res.status(200).end();
                                })
                        }
                    })
                }
                if (req.body.track == 1 && req.body.user_id == "all") {
                    connection.query('SELECT tracking.jobdate as JobDate, fmp_user.user_id as UserId, fmp_user.full_name as Name, tracking.editedcheckin as CheckInTime, tracking.editedcheckout as CheckOutTime, tracking.check_in_latitude as CheckInLatitude, tracking.check_in_longitude as CheckInLongitude, tracking.check_out_latitude as CheckOutLatitude, tracking.check_out_longitude as CheckOutLongitude, tracking.check_in_image as CheckInImage, tracking.check_out_image as CheckOutImage from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE  job.src_id=? AND tracking.jobdate BETWEEN ? AND ? ', [id, from, to], function (error, all) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(all);
                            var result = JSON.parse(JSON.stringify(all));

                            let workbook = new excel.Workbook();
                            let worksheet = workbook.addWorksheet('Report');
                            worksheet.columns = [
                                { header: 'Date', key: 'jobdate', width: 20 },
                                { header: 'Name', key: 'full_name', width: 30 },
                                { header: 'check In', key: 'editedcheckin', width: 20 },
                                { header: 'check In lat,long', key: 'check_in_lat_long', width: 60 },
                                { header: 'check In Image', key: 'check_in_image', width: 100 },
                                { header: 'check Out', key: 'editedcheckout', width: 20 },
                                { header: 'check Out lat,long', key: 'check_out_lat_long', width: 60 },
                                { header: 'check out Image', key: 'check_out_image', width: 100 },
                                { header: 'Achieved Hours', key: 'achievedHours', width: 60 }
                            ];
                            worksheet.addRows(result);
                            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                            res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                            return workbook.xlsx.write(res)
                                .then(function () {
                                    res.status(200).end();
                                })
                        }
                    })
                } else if (req.body.track == 1 && req.body.user_id !== 'all') {
                    connection.query('SELECT * from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE tracking.user_id=? AND job.src_id=? AND tracking.jobdate BETWEEN ? AND ?', [user_id, id, from, to], function (error, user) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(user);
                            var result = JSON.parse(JSON.stringify(user));


                            for (var k = 0; k < result.length; k++) {

                                var startTime = moment(result[k].editedcheckin, "HH:mm:ss");
                                var endTime = moment(result[k].editedcheckout, "HH:mm:ss");


                                if (endTime.isBefore(startTime)) {
                                    endTime.add(1, 'day');
                                }

                                var duration = moment.duration(endTime.diff(startTime));
                                var hours = parseInt(duration.asHours());
                                var minutes = parseInt(duration.asMinutes()) % 60;
                                console.log(hours + ' hour and ' + minutes + ' minutes.');
                                if (result[k].editedcheckout == null) {
                                    result[k].achievedHours = "0 hours and 0 minutes"
                                } else {
                                    result[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                                }
                            }

                            for (var j = 0; j < result.length; j++) {
                                result[j].check_in_lat_long = result[j].check_in_latitude + ' , ' + result[j].check_in_longitude
                                result[j].check_out_lat_long = result[j].check_out_latitude + ' , ' + result[j].check_out_longitude
                            }


                            for (var i = 0; i < result.length; i++) {
                                result[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_in_image
                                result[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_out_image
                                result[i].jobdate = moment(result[i].jobdate).format("DD MMMM - YYYY")
                            }

                            let workbook = new excel.Workbook();
                            let worksheet = workbook.addWorksheet('Report');
                            worksheet.columns = [
                                { header: 'Date', key: 'jobdate', width: 20 },
                                { header: 'Name', key: 'full_name', width: 30 },
                                { header: 'check In', key: 'editedcheckin', width: 20 },
                                { header: 'check In lat,long', key: 'check_in_lat_long', width: 60 },
                                { header: 'check In Image', key: 'check_in_image', width: 100 },
                                { header: 'check Out', key: 'editedcheckout', width: 20 },
                                { header: 'check Out lat,long', key: 'check_out_lat_long', width: 60 },
                                { header: 'check out Image', key: 'check_out_image', width: 100 },
                                { header: 'Achieved Hours', key: 'achievedHours', width: 60 }
                            ];
                            worksheet.addRows(result);
                            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                            res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                            return workbook.xlsx.write(res)
                                .then(function () {
                                    res.status(200).end();
                                })
                        }
                    })
                }

            } else if (req.body.type == 2) {
                if (req.body.track == 0 && req.body.user_id == 'all') {
                    connection.query('SELECT * FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND job_answers.report_id=? AND DATE(job_answers.answered_at)=?', [id, report_id, date], function (error, today) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(today);
                            var result = JSON.parse(JSON.stringify(today));
                            for (var i = 0; i < today.length; i++) {
                                result[i].jobdate = moment(result[i].jobdate).format('DD MMMM -YYYY')
                            }


                            let workbook = new excel.Workbook();
                            let worksheet = workbook.addWorksheet('Report');
                            worksheet.columns = [
                                { header: 'Date', key: 'answered_at', width: 20 },
                                { header: 'Name', key: 'full_name', width: 30 },
                                { header: 'Question', key: 'question', width: 100 },
                                { header: 'Answer', key: 'answer', width: 60 },
                            ];
                            worksheet.addRows(result);
                            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                            res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                            return workbook.xlsx.write(res)
                                .then(function () {
                                    res.status(200).end();
                                })

                        }

                    })
                } else if (req.body.track == 0 && req.body.user_id !== 'all') {
                    connection.query('SELECT * FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND DATE(job_answers.answered_at)=?', [id, date], function (error, today) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(today);
                            var result = JSON.parse(JSON.stringify(today));
                            for (var i = 0; i < today.length; i++) {
                                result[i].jobdate = moment(result[i].jobdate).format('DD MMMM -YYYY')
                            }
                            let workbook = new excel.Workbook();
                            let worksheet = workbook.addWorksheet('Report');
                            worksheet.columns = [
                                { header: 'Date', key: 'answered_at', width: 20 },
                                { header: 'Name', key: 'full_name', width: 30 },
                                { header: 'Question', key: 'question', width: 100 },
                                { header: 'Answer', key: 'answer', width: 60 },
                            ];
                            worksheet.addRows(result);
                            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                            res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                            return workbook.xlsx.write(res)
                                .then(function () {
                                    res.status(200).end();
                                })


                        }

                    })
                } else if (req.body.track == 1 && req.body.user_id == 'all') {
                    connection.query('SELECT * FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND DATE(job_answers.answered_at) BETWEEN  DATE(?) AND DATE(?) ', [id, from, to], function (error, today) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(today);
                            var result = JSON.parse(JSON.stringify(today));
                            for (var i = 0; i < today.length; i++) {
                                result[i].jobdate = moment(result[i].jobdate).format('DD MMMM -YYYY')
                            }
                            let workbook = new excel.Workbook();
                            let worksheet = workbook.addWorksheet('Report');
                            worksheet.columns = [
                                { header: 'Date', key: 'answered_at', width: 20 },
                                { header: 'Name', key: 'full_name', width: 30 },
                                { header: 'Question', key: 'question', width: 100 },
                                { header: 'Answer', key: 'answer', width: 60 },
                            ];
                            worksheet.addRows(result);
                            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                            res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                            return workbook.xlsx.write(res)
                                .then(function () {
                                    res.status(200).end();
                                })

                        }

                    })

                } else if (req.body.track == 1 && req.body.user_id !== 'all') {
                    connection.query('SELECT * FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND job_answers.user_id=? AND  DATE(job_answers.answered_at) BETWEEN  DATE(?) AND DATE(?)', [id, user_id, from, to], function (error, today) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log(today);
                            var result = JSON.parse(JSON.stringify(today));
                            for (var i = 0; i < today.length; i++) {
                                result[i].jobdate = moment(result[i].jobdate).format('DD MMMM -YYYY')
                            }
                            let workbook = new excel.Workbook();
                            let worksheet = workbook.addWorksheet('Report');
                            worksheet.columns = [
                                { header: 'Date', key: 'answered_at', width: 20 },
                                { header: 'Name', key: 'full_name', width: 30 },
                                { header: 'Question', key: 'question', width: 100 },
                                { header: 'Answer', key: 'answer', width: 60 },
                            ];
                            worksheet.addRows(result);
                            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                            res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                            return workbook.xlsx.write(res)
                                .then(function () {
                                    res.status(200).end();
                                })
                        }
                    })
                }
            }
        }
    }
    sendMail();

})


router.post('/:id/attendance/download', function (req, res, next) {
    var id = req.params.id;
    var from = req.body.from;
    var to = req.body.to;
    var user_id = req.body.user_id;
    function downloadAttendance(error, data) {
        if (error) {
            console.log(error);
        } else {

            if (req.body.track == 0 && req.body.user_id == "all") {
                connection.query('SELECT *, fmp_user.full_name from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE  job.src_id=? AND tracking.jobdate=CURRENT_DATE ', [id], function (error, today) {
                    if (error) {
                        console.log(error);
                    } else {
                        var result = JSON.parse(JSON.stringify(today));

                        for (var k = 0; k < result.length; k++) {

                            var startTime = moment(result[k].editedcheckin, "HH:mm:ss");
                            var endTime = moment(result[k].editedcheckout, "HH:mm:ss");


                            if (endTime.isBefore(startTime)) {
                                endTime.add(1, 'day');
                            }

                            var duration = moment.duration(endTime.diff(startTime));
                            var hours = parseInt(duration.asHours());
                            var minutes = parseInt(duration.asMinutes()) % 60;
                            console.log(hours + ' hour and ' + minutes + ' minutes.');
                            if (result[k].editedcheckout == null) {
                                result[k].achievedHours = "0 hours and 0 minutes"
                            } else {
                                result[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                            }
                        }

                        for (var j = 0; j < result.length; j++) {
                            result[j].check_in_lat_long = result[j].check_in_latitude + ' , ' + result[j].check_in_longitude
                            result[j].check_out_lat_long = result[j].check_out_latitude + ' , ' + result[j].check_out_longitude
                        }


                        for (var i = 0; i < result.length; i++) {
                            result[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_in_image
                            result[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_out_image
                            result[i].jobdate = moment(result[i].jobdate).format("DD MMMM - YYYY")
                        }



                        let workbook = new excel.Workbook();
                        let worksheet = workbook.addWorksheet('Report');
                        worksheet.columns = [
                            { header: 'Date', key: 'jobdate', width: 20 },
                            { header: 'Name', key: 'full_name', width: 30 },
                            { header: 'check In', key: 'editedcheckin', width: 20 },
                            { header: 'check In lat,long', key: 'check_in_lat_long', width: 60 },
                            { header: 'check In Image', key: 'check_in_image', width: 100 },
                            { header: 'check Out', key: 'editedcheckout', width: 20 },
                            { header: 'check Out lat,long', key: 'check_out_lat_long', width: 60 },
                            { header: 'check out Image', key: 'check_out_image', width: 100 },
                            { header: 'Achieved Hours', key: 'achievedHours', width: 60 }
                        ];
                        worksheet.addRows(result);
                        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                        return workbook.xlsx.write(res)
                            .then(function () {
                                res.status(200).end();
                            })



                    }
                })
            } else if (req.body.track == 0 && req.body.user_id !== 'all') {
                connection.query('SELECT *, fmp_user.full_name from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE  job.src_id=? AND tracking.user_id=? AND tracking.jobdate= CURRENT_DATE ', [id, user_id], function (error, customize) {
                    if (error) {
                        console.log(error);
                    } else {
                        var result = JSON.parse(JSON.stringify(customize));

                        for (var k = 0; k < result.length; k++) {

                            var startTime = moment(result[k].editedcheckin, "HH:mm:ss");
                            var endTime = moment(result[k].editedcheckout, "HH:mm:ss");


                            if (endTime.isBefore(startTime)) {
                                endTime.add(1, 'day');
                            }

                            var duration = moment.duration(endTime.diff(startTime));
                            var hours = parseInt(duration.asHours());
                            var minutes = parseInt(duration.asMinutes()) % 60;
                            console.log(hours + ' hour and ' + minutes + ' minutes.');
                            if (result[k].editedcheckout == null) {
                                result[k].achievedHours = "0 hours and 0 minutes"
                            } else {
                                result[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                            }
                        }

                        for (var j = 0; j < result.length; j++) {
                            result[j].check_in_lat_long = result[j].check_in_latitude + ' , ' + result[j].check_in_longitude
                            result[j].check_out_lat_long = result[j].check_out_latitude + ' , ' + result[j].check_out_longitude
                        }


                        for (var i = 0; i < result.length; i++) {
                            result[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_in_image
                            result[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_out_image
                            result[i].jobdate = moment(result[i].jobdate).format("DD MMMM - YYYY")
                        }



                        let workbook = new excel.Workbook();
                        let worksheet = workbook.addWorksheet('Report');
                        worksheet.columns = [
                            { header: 'Date', key: 'jobdate', width: 20 },
                            { header: 'Name', key: 'full_name', width: 30 },
                            { header: 'check In', key: 'editedcheckin', width: 20 },
                            { header: 'check In lat,long', key: 'check_in_lat_long', width: 60 },
                            { header: 'check In Image', key: 'check_in_image', width: 100 },
                            { header: 'check Out', key: 'editedcheckout', width: 20 },
                            { header: 'check Out lat,long', key: 'check_out_lat_long', width: 60 },
                            { header: 'check out Image', key: 'check_out_image', width: 100 },
                            { header: 'Achieved Hours', key: 'achievedHours', width: 60 }
                        ];
                        worksheet.addRows(result);
                        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                        return workbook.xlsx.write(res)
                            .then(function () {
                                res.status(200).end();
                            })



                    }
                })
            }



            if (req.body.track == 1 && req.body.user_id == "all") {
                connection.query('SELECT *, fmp_user.full_name from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE  job.src_id=? AND tracking.jobdate BETWEEN ? AND ? ', [id, from, to], function (error, all) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log(all);
                        var result = JSON.parse(JSON.stringify(all));

                        for (var k = 0; k < result.length; k++) {

                            var startTime = moment(result[k].editedcheckin, "HH:mm:ss");
                            var endTime = moment(result[k].editedcheckout, "HH:mm:ss");


                            if (endTime.isBefore(startTime)) {
                                endTime.add(1, 'day');
                            }

                            var duration = moment.duration(endTime.diff(startTime));
                            var hours = parseInt(duration.asHours());
                            var minutes = parseInt(duration.asMinutes()) % 60;
                            console.log(hours + ' hour and ' + minutes + ' minutes.');
                            if (result[k].editedcheckout == null) {
                                result[k].achievedHours = "0 hours and 0 minutes"
                            } else {
                                result[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                            }
                        }

                        for (var j = 0; j < result.length; j++) {
                            result[j].check_in_lat_long = result[j].check_in_latitude + ' , ' + result[j].check_in_longitude
                            result[j].check_out_lat_long = result[j].check_out_latitude + ' , ' + result[j].check_out_longitude
                        }


                        for (var i = 0; i < result.length; i++) {
                            result[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_in_image
                            result[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_out_image
                            result[i].jobdate = moment(result[i].jobdate).format("DD MMMM - YYYY")
                        }



                        let workbook = new excel.Workbook();
                        let worksheet = workbook.addWorksheet('Report');
                        worksheet.columns = [
                            { header: 'Date', key: 'jobdate', width: 20 },
                            { header: 'Name', key: 'full_name', width: 30 },
                            { header: 'check In', key: 'editedcheckin', width: 20 },
                            { header: 'check In lat,long', key: 'check_in_lat_long', width: 60 },
                            { header: 'check In Image', key: 'check_in_image', width: 100 },
                            { header: 'check Out', key: 'editedcheckout', width: 20 },
                            { header: 'check Out lat,long', key: 'check_out_lat_long', width: 60 },
                            { header: 'check out Image', key: 'check_out_image', width: 100 },
                            { header: 'Achieved Hours', key: 'achievedHours', width: 60 }
                        ];
                        worksheet.addRows(result);
                        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                        return workbook.xlsx.write(res)
                            .then(function () {
                                res.status(200).end();
                            })


                    }
                })
            } else if (req.body.track == 1 && req.body.user_id !== 'all') {
                console.log('Unique user');
                connection.query('SELECT *, fmp_user.full_name from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE tracking.user_id=? AND job.src_id=? AND tracking.jobdate BETWEEN ? AND ?', [user_id, id, from, to], function (error, user) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log(user);
                        var resultUser = JSON.parse(JSON.stringify(user));


                        for (var k = 0; k < resultUser.length; k++) {

                            var startTime = moment(resultUser[k].editedcheckin, "HH:mm:ss");
                            var endTime = moment(resultUser[k].editedcheckout, "HH:mm:ss");


                            if (endTime.isBefore(startTime)) {
                                endTime.add(1, 'day');
                            }

                            var duration = moment.duration(endTime.diff(startTime));
                            var hours = parseInt(duration.asHours());
                            var minutes = parseInt(duration.asMinutes()) % 60;
                            console.log(hours + ' hour and ' + minutes + ' minutes.');
                            if (resultUser[k].editedcheckout == null) {
                                resultUser[k].achievedHours = "0 hours and 0 minutes"
                            } else {
                                resultUser[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                            }
                        }

                        for (var j = 0; j < resultUser.length; j++) {
                            resultUser[j].check_in_lat_long = resultUser[j].check_in_latitude + ' , ' + resultUser[j].check_in_longitude
                            resultUser[j].check_out_lat_long = resultUser[j].check_out_latitude + ' , ' + resultUser[j].check_out_longitude
                        }


                        for (var i = 0; i < resultUser.length; i++) {
                            resultUser[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + resultUser[i].check_in_image
                            resultUser[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + resultUser[i].check_out_image
                            resultUser[i].jobdate = moment(resultUser[i].jobdate).format("DD MMMM - YYYY")
                        }

                        let workbook = new excel.Workbook();
                        let worksheet = workbook.addWorksheet('UserReport');
                        worksheet.columns = [
                            { header: 'Date', key: 'jobdate', width: 20 },
                            { header: 'Name', key: 'full_name', width: 30 },
                            { header: 'check In', key: 'editedcheckin', width: 20 },
                            { header: 'check In lat,long', key: 'check_in_lat_long', width: 60 },
                            { header: 'check In Image', key: 'check_in_image', width: 100 },
                            { header: 'check Out', key: 'editedcheckout', width: 20 },
                            { header: 'check Out lat,long', key: 'check_out_lat_long', width: 60 },
                            { header: 'check out Image', key: 'check_out_image', width: 100 },
                            { header: 'Achieved Hours', key: 'achievedHours', width: 60 }
                        ];
                        worksheet.addRows(resultUser);
                        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');
                        var toCsv = require('to-csv');

                        return workbook.xlsx.write(res)
                            .then(function () {


                                var readHTMLFile = function (path, callback) {
                                    fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                                        if (err) {
                                            throw err;
                                            callback(err);
                                        }
                                        else {
                                            callback(null, html);
                                        }
                                    });
                                }
                                var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
                                readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                                    var template = handlebars.compile(html);
                                    var replacements = {
                                        name: "abhijit"


                                    };

                                    var htmlToSend = template(replacements);
                                    var mailOptions = {
                                        from: 'FeedMyPockets <business@feedmypockets.com>',
                                        to: 'abhijit.mohanty@feedmypockets.com',
                                        subject: 'Job Request Received on',
                                        text: 'Hello',
                                        html: htmlToSend,
                                        attachments: [{ filename: 'report.csv', content: toCsv(resultUser) }]

                                    }

                                    console.log(mailOptions)

                                    transporter.sendMail(mailOptions, function (err, dt) {
                                        console.log('mail error', err)
                                        console.log('mail success', dt)
                                        if (err) {
                                            res.json(500, {
                                                error: true,
                                                error: err
                                            })
                                        } else {

                                            res.redirect('/beta/dashboard');
                                        }


                                    })



                                });
                            })
                    }
                })
            }
        }
    }
    downloadAttendance();
})




router.post('/:id/', function (req, res, next) {
    var id = req.params.id;
    var date = moment().format('YYYY-MM-DD')
    var from = req.body.from;
    var to = req.body.to;
    var emailTO = req.body.email;
    var user_id = req.body.user_id;
    function downloadReport(error, data) {
        if (error, data) {
            console.log(error);
        } else {
            if (req.body.report == 0 && req.body.user_id == 'all') {
                connection.query('SELECT * FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND DATE(job_answers.answered_at)=?', [id, date], function (error, today) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log(today);
                        var result = JSON.parse(JSON.stringify(today));
                        for (var i = 0; i < today.length; i++) {
                            result[i].answered_at = moment(result[i].answered_at).format('DD MMMM -YYYY')
                        }

                        let workbook = new excel.Workbook();
                        let worksheet = workbook.addWorksheet('Report');
                        worksheet.columns = [
                            { header: 'Date', key: 'answered_at', width: 20 },
                            { header: 'Name', key: 'full_name', width: 30 },
                            { header: 'Question', key: 'question', width: 100 },
                            { header: 'Answer', key: 'answer', width: 60 },
                        ];
                        worksheet.addRows(result);
                        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                        return workbook.xlsx.write(res)
                            .then(function () {
                                res.status(200).end();
                            })
                    }

                })
            } else if (req.body.report == 0 && req.body.user_id !== 'all') {
                connection.query('SELECT * FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND job_answers.user_id=? AND DATE(job_answers.answered_at)=?', [id, user_id, date], function (error, today) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log(today);
                        var result = JSON.parse(JSON.stringify(today));
                        for (var i = 0; i < today.length; i++) {
                            result[i].answered_at = moment(result[i].answered_at).format('DD MMMM -YYYY')
                        }

                        let workbook = new excel.Workbook();
                        let worksheet = workbook.addWorksheet('Report');
                        worksheet.columns = [
                            { header: 'Date', key: 'answered_at', width: 20 },
                            { header: 'Name', key: 'full_name', width: 30 },
                            { header: 'Question', key: 'question', width: 100 },
                            { header: 'Answer', key: 'answer', width: 60 },
                        ];
                        worksheet.addRows(result);
                        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                        return workbook.xlsx.write(res)
                            .then(function () {
                                res.status(200).end();
                            })
                    }

                })
            }


            if (req.body.report == 1 && req.body.user_id == 'all') {
                connection.query('SELECT * FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND DATE(job_answers.answered_at) BETWEEN  DATE(?) AND DATE(?) ', [id, from, to], function (error, today) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log(today);
                        var result = JSON.parse(JSON.stringify(today));
                        for (var i = 0; i < today.length; i++) {
                            result[i].answered_at = moment(result[i].answered_at).format('DD MMMM -YYYY')
                        }

                        let workbook = new excel.Workbook();
                        let worksheet = workbook.addWorksheet('Report');
                        worksheet.columns = [
                            { header: 'Date', key: 'answered_at', width: 20 },
                            { header: 'Name', key: 'full_name', width: 30 },
                            { header: 'Question', key: 'question', width: 100 },
                            { header: 'Answer', key: 'answer', width: 60 },
                        ];
                        worksheet.addRows(result);
                        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                        return workbook.xlsx.write(res)
                            .then(function () {
                                res.status(200).end();
                            })
                    }

                })
            } else if (req.body.report == 1 && req.body.user_id !== 'all') {
                connection.query('SELECT * FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_questions.question_for="Report" AND job_answers.user_id=? AND  DATE(job_answers.answered_at) BETWEEN  DATE(?) AND DATE(?)', [id, user_id, from, to], function (error, today) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log(today);
                        var result = JSON.parse(JSON.stringify(today));
                        for (var i = 0; i < today.length; i++) {
                            result[i].answered_at = moment(result[i].answered_at).format('DD MMMM -YYYY')
                        }

                        let workbook = new excel.Workbook();
                        let worksheet = workbook.addWorksheet('Report');
                        worksheet.columns = [
                            { header: 'Date', key: 'answered_at', width: 20 },
                            { header: 'Name', key: 'full_name', width: 30 },
                            { header: 'Question', key: 'question', width: 100 },
                            { header: 'Answer', key: 'answer', width: 60 },
                        ];
                        worksheet.addRows(result);
                        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                        return workbook.xlsx.write(res)
                            .then(function () {

                                var readHTMLFile = function (path, callback) {
                                    fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                                        if (err) {
                                            throw err;
                                            callback(err);
                                        }
                                        else {
                                            callback(null, html);
                                        }
                                    });
                                }
                                var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'business@feedmypockets.com', pass: 'FMPbusiness@123' } });
                                readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                                    var template = handlebars.compile(html);
                                    var replacements = {
                                        name: "abhijit"


                                    };

                                    var htmlToSend = template(replacements);
                                    var mailOptions = {
                                        from: 'FeedMyPockets <business@feedmypockets.com>',
                                        to: 'abhijit.mohanty@feedmypockets.com',
                                        subject: 'Job Request Received on',
                                        text: 'Hello',
                                        html: htmlToSend,
                                        attachments: [{ filename: 'report.csv', content: toCsv(result) }]


                                    }

                                    console.log(mailOptions)

                                    transporter.sendMail(mailOptions, function (err, dt) {
                                        console.log('mail error', err)
                                        console.log('mail success', dt)
                                        if (err) {
                                            res.json(500, {
                                                error: true,
                                                error: err
                                            })
                                        } else {


                                        }


                                    })



                                });
                            })
                    }

                })
            }
        }
    }
    downloadReport();
})

router.post('/:id/reports/new', function (req, res, next) {
    var id = req.params.id;
    var async = require('async');
    var from = req.body.from;
    var to = req.body.to;
    var ques = new Array();
    function getAnswer(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('SELECT DISTINCT(question), question_id FROM job_questions JOIN job ON job_questions.job_id=job.job_id WHERE job.src_id=?', [id], function (error, question) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(question);
                    // for(var i=0; i< question.length; i++) {
                    //     ques.push(question[i].question);
                    // }
                    // console.log('ques', ques);
                    // let workbook = new excel.Workbook();
                    // let worksheet = workbook.addWorksheet('Report');

                    // var headerValue = new Array();
                    // headerValue.push("Name")
                    // for (var i = 0; i < ques.length; i++) {
                    //     headerValue.push(ques[i])
                    // }

                    // worksheet.getRow(1).values = headerValue;

                    async.eachSeries(question, function (data, callback) {
                        connection.query('SELECT fmp_user.full_name, job_answers.answer FROM job_answers JOIN fmp_user ON job_answers.user_id=fmp_user.user_id JOIN job_questions ON job_questions.question_id=job_answers.question_id WHERE job_answers.question_id=? ', [data.question_id], function (error, answer) {
                            if (error) {
                                console.log(error);
                            } else {
                                //    

                            }
                            callback();
                        })
                    }, function (error, results) {
                        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                        return workbook.xlsx.write(res)
                            .then(function () {
                                res.status(200).end();
                            })
                    })
                }
            })

        }
    }
    getAnswer();
})

router.post('/:id/reportsnew', function (req, res, next) {
    var id = req.params.id;
    var output = new Array()
    var ques = new Array()
    var async = require('async');
    function getQuestions(error, data) {
        if (error) {
            console.log(error);
        } else {
            connection.query('SELECT DISTINCT(question), question_id FROM job_questions JOIN job ON job_questions.job_id=job.job_id WHERE job.src_id=? AND job_questions.question_for="Report" ', [id], function (error, question) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(question);

                    for (var i = 0; i < question.length; i++) {
                        ques.push(question[i].question)
                    }

                    console.log('ques', ques)
                    let workbook = new excel.Workbook();
                    let worksheet = workbook.addWorksheet('Report');

                    var headerValue = new Array();
                    headerValue.push("Name")
                    for (var i = 0; i < ques.length; i++) {
                        headerValue.push(ques[i])
                    }

                    worksheet.getRow(1).values = headerValue

                    async.eachSeries(question, function (data, callback) {


                        connection.query('SELECT * FROM job_applications JOIN job ON job_applications.job_id=job.job_id JOIN fmp_user ON fmp_user.user_id=job_applications.user_id WHERE job.src_id=? AND job_applications.status="Selected" ', [id], function (error, user) {
                            if (error) {
                                console.log(error);
                                res.json(404, {
                                    error: true,
                                    message: 'Not Found'
                                })
                            } else {
                                console.log(user)
                                for (var i = 0; i < user.length; i++) {
                                    var cellValue = new Array();
                                    var ansVal = new Array();
                                    cellValue.push(user[i].full_name);

                                    console.log('cellval', cellValue)
                                    worksheet.getRow(i + 2).values = cellValue
                                }
                                async.eachSeries(user, function (one, callbackOne) {


                                    console.log('question count', question.length);
                                    // for (var j = 0; j < question.length; j++) {

                                    connection.query('SELECT answer FROM job_answers  WHERE job_answers.question_id=? AND job_answers.user_id=?', [data.question_id, one.user_id], function (error, answer) {
                                        if (error) {

                                        } else {
                                            // for (var k = 0; k < answer.length; k++) {
                                            //     console.log('ans', answer[k])
                                            //     ansVal.push(answer[k])
                                            // }

                                            for (var i = 0; i < answer.length; i++) {

                                                // var ansVal = new Array();
                                                cellValue.push(answer[i].answer);

                                                console.log('cellval', cellValue)
                                                worksheet.getRow(i + 3).values = cellValue
                                            }

                                        }
                                        callbackOne()
                                    })
                                    // cellValue.push(ansVal)


                                }, function (error, result) {
                                    if (error) {
                                        console.log(error);
                                    } else {
                                        callback();
                                    }
                                })


                            }

                        });

                    }, function (error, results) {
                        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                        // results = workbook.xlsx.write(res)


                        return workbook.xlsx.write(res)
                            .then(function () {
                                res.status(200).end();
                            })


                    })
                }
            })
        }
    }
    getQuestions();
})


router.post('/:id/reports', function (req, res, next) {
    var id = req.params.id;
    var output = new Array()
    var ques = new Array()
    var async = require('async');
    function getQuestions(error, data) {
        if (error) {
            console.log(error);
        } else {
            connection.query('SELECT DISTINCT(question), question_id FROM job_questions JOIN job ON job_questions.job_id=job.job_id WHERE job.src_id=? AND job_questions.question_for="Report" ', [id], function (error, question) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(question);

                    for (var i = 0; i < question.length; i++) {
                        ques.push(question[i].question)
                    }

                    console.log('ques', ques)
                    let workbook = new excel.Workbook();
                    let worksheet = workbook.addWorksheet('Report');

                    var headerValue = new Array();
                    headerValue.push("Name")
                    for (var i = 0; i < ques.length; i++) {
                        headerValue.push(ques[i])
                    }

                    worksheet.getRow(1).values = headerValue

                    async.eachSeries(question, function (data, callback) {


                        connection.query('SELECT full_name, answer FROM job_answers JOIN job ON job_answers.job_id=job.job_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE job.src_id=? AND job_answers.question_id', [id, question.question_id], function (error, user) {
                            if (error) {
                                console.log(error);
                                res.json(404, {
                                    error: true,
                                    message: 'Not Found'
                                })
                            } else {
                                console.log(user)

                                for (var i = 0; i < user.length; i++) {
                                    var cellValue = new Array();
                                    var ansVal = new Array();
                                    cellValue.push(user[i]);
                                    // cellValue.push(user[i].answer);
                                    console.log('question count', question.length);
                                    // for (var j = 0; j < question.length; j++) {

                                    //     connection.query('SELECT answer FROM job_answers  WHERE job_answers.question_id=? AND job_answers.user_id=?', [question.question_id, user[i].user_id], function (error, answer) {
                                    //         if (error) {

                                    //         } else {
                                    //             for (var k = 0; k < answer.length; k++) {
                                    //                 console.log('ans', answer[j])
                                    //                 ansVal.push(answer[j])
                                    //             }

                                    //         }
                                    //     })
                                    //     cellValue.push(ansVal)
                                    //  }

                                    console.log('cellval', cellValue)
                                    worksheet.getRow(i + 2).values = cellValue

                                }


                            }
                            callback();
                        });

                    }, function (error, results) {
                        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                        return workbook.xlsx.write(res)
                            .then(function () {
                                res.status(200).end();
                            })

                    })
                }
            })
        }
    }
    getQuestions();
})







router.get('/wallet', function (req, res, next) {
    res.render('admin/wallet', {
        layout: 'layout',
        title: 'wallet'
    })
})

router.post('/generatecashfreetoken', function (req, res, next) {
    function generateCashfreeToken(error, url) {
        if (error) {
            console.log(error);
        } else {
            console.log(url);
            var tokenData = JSON.parse(url).data.token;
            const token = tokenData
            console.log('token', tokenData)
            var amount = req.body.amount;
            var user_id = req.body.user_id;
            var phone = req.body.phoneno;
            var name = req.body.fullname;
            var linkExpiry = req.body.linkExpiry;
            var val = Math.floor(1000 + Math.random() * 9000);
            var cashgramId = req.body.fullname.substring(0, 4) + req.body.user_id + val;
            var inputData = req.body;
            inputData.amount = amount;
            inputData.user_id = user_id;
            inputData.phone = phone;
            inputData.name = name;
            inputData.token = token;
            inputData.linkExpiry = linkExpiry;
            inputData.cashgramId = cashgramId
            function generateCashgramClient(error, result) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(result);

                }
            }
            projectService.generateCashgramClient(inputData, generateCashgramClient)

        }
    }
    projectService.generateCashfreeToken(generateCashfreeToken);
})










// router.get('/files/:id/download', function(req, res, next) {
//     var id = req.params.id;
//     var url = "/projects/public/files/"+
// })

// router.get('/details/:id', function (req, res, next) {
//     var id = req.params.id;
//     function callback(error, data) {
//         if (error) {
//             console.log(error);
//         } else {
//             projectService.getProjectDetails(id, getProjectDetails);

//         }
//     }
//     function trackProject(error, data) {
//         if (error) {
//             console.log(error);
//         } else {
//             console.log('track', data)

//             res.render('admin/project-detail', {
//                 title: 'Track Project',
//                 layout: 'layout',
//                 track: JSON.parse(data).track,
//                 id: id
//             })
//         }

//     }
//     function getProjectDetails(error, data) {
//         if (error) {
//             console.log(error);
//         } else {
//             console.log(data);
//             projectService.trackProject(id, trackProject);
//             res.render('admin/project-detail', {
//                 layout: 'layout',
//                 title: 'Project Details',
//                 project: JSON.parse(data).project,
//                 id: id

//             })

//         }

//     }
//     callback();
// })


// router.get('/details/:id#solid-rounded-justified-tab3', function(req, res, next) {
//     var id = req.params.id;
//     function trackProject(error, data) {
//         if(error){
//             console.log(error);
//         } else {
//             console.log(data);
//             res.render('admin/project-details',{
//                 layout: 'layout',
//                 track: data
//             })
//         }
//     }
//     projectService.trackProject(id, trackProject)
// })


// router.get('/details/:id', (req, res) => {
//     var id = req.params.id;
//     Promise.all([
//         ('http://localhost:3000/projects/details?src_id=' + id),
//         ('http://localhost:3000/projects/track/' + id)
//     ]).then(([project, { track }]) =>
//         res.render('admin/project-detail', {
//             layout: 'layout',
//             project,
//             track
//         })
//     )
//         .catch(err => res.send('Ops, something has gone wrong'))
// })

router.get('/track/:id', function (req, res, next) {
    var id = req.params.id;
    function trackProject(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log('track', data);
            res.render('admin/project-detail', {
                title: 'Track Project',
                layout: 'layout-detail',
                track: JSON.parse(data).track,
                id: id
            })
        }
    }
    projectService.trackProject(id, trackProject);

})

router.post('/track/:id', function (req, res, next) {
    var id = req.params.id;
    // var user_id = req.body.user_id;
    var from = req.body.from;
    var to = req.body.to;

    function trackByDate(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);

            for (var j = 0; j < data.length; j++) {
                var startTime = moment(data[j].start_time, "HH:mm:ss");
                var endTime = moment(data[j].end_time, "HH:mm:ss");
                // var duration = moment.duration(endTime.diff(startTime));''

                if (endTime.isBefore(startTime)) {
                    endTime.add(1, 'day');
                }
                var duration = moment.duration(endTime.diff(startTime));

                // if(startTime > endTime) {
                //     var duration = moment.duration(startTime.diff(endTime));
                // } else {
                //     var duration = moment.duration(endTime.diff(startTime));
                // }
                var hours = parseInt(duration.asHours());
                var minutes = parseInt(duration.asMinutes()) % 60;
                console.log(hours + ' hour and ' + minutes + ' minutes.');
                data[j].scheduledHours = hours + ' hour and ' + minutes + ' minutes.'
            }

            for (var i = 0; i < data.length; i++) {

                var startTime = moment(data[i].editedcheckin, "HH:mm:ss");
                var endTime = moment(data[i].editedcheckout, "HH:mm:ss");
                // if(startTime > endTime) {
                //     var duration = moment.duration(startTime.diff(endTime));
                // } else {
                //     var duration = moment.duration(endTime.diff(startTime));
                // }

                if (endTime.isBefore(startTime)) {
                    endTime.add(1, 'day');
                }

                var duration = moment.duration(endTime.diff(startTime));
                var hours = parseInt(duration.asHours());
                var minutes = parseInt(duration.asMinutes()) % 60;
                console.log(hours + ' hour and ' + minutes + ' minutes.');
                if (data[i].editedcheckout == null) {
                    data[i].achievedHours = "0 hours and 0 minutes"
                } else {
                    data[i].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                }
            }

            res.render('admin/date_track', {
                layout: 'layout-detail',
                datetrack: data,
            });
        }
    }
    projectService.getTrackByDate(id, from, to, trackByDate)
})

router.get('/:id/getalldetails', function (req, res, next) {
    var id = req.params.id;
    function getalldetails(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/project-detail', {
                layout: 'layout-detail',
                title: 'Project details',
                project: JSON.parse(data).project,
                applicants: JSON.parse(data).applicants,
                track: JSON.parse(data).track,
                spoc: JSON.parse(data).spoc

            })
        }
    }
    projectService.getAllDetails(id, getalldetails);
})

router.post('/details/:id/upload', function (req, res, next) {
    var id = req.params.id;

    var dir = path.join(__dirname, '../public/files');
    var finishUpload = function (err, data) {
        if (err) {
            console.log(err);
        } else {

            res.redirect('/beta/projects/details/' + id);
        }
    };

    var callback = function (error, data) {
        var data = req.body
        data.uploadfile = req.file.originalname
        if (error) {
            console.log(error);
        } else {
            projectService.uploadfile(id, data, finishUpload);
        }
    };
    mediaService.uploadMedia(req, res, dir, id, callback);

})

router.post('/:id/addspoc', function (req, res, next) {
    var id = req.params.id;
    var body = req.body;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/beta/projects/details/' + id);
        }
    }
    projectService.createSpoc(id, body, callback);
});

// router.get('/:id/getspoc', function(req, res, next) {
//     var id = req.params.id;
//     function getSpoc(error, data) {
//         if(error) {
//             console.log(error);
//         } else {
//             console.log(data);
//             res.render('admin/')
//         }
//     }
// })

router.get('/download/:id', function (req, res, next) {
    var id = req.params.id;
    var fileLocation = path.join('../../../public_html/HR-Admin/uploadfiles', id);
    console.log(fileLocation);
    res.download(fileLocation, id);
})


router.get('/download/report/id', function (req, res, next) {
    var id = "1570642903910Fwsl8oWHv5llWPPm.pdf"
    var fileLocation = path.join('./public/files', id);
    console.log(fileLocation);
    res.download(fileLocation, id);
})

router.get('/details/:src_id/files/:id/delete', function (req, res, next) {
    var src_id = req.params.src_id;
    var id = req.params.id;
    function deleteFile(error, data) {
        if (error) {
            console.log(error);
        } else {
            res.redirect('/beta/projects/details/' + src_id);
        }
    }
    projectService.deleteFile(id, src_id, deleteFile)
})



// function get(url){
//     return new Promise((resolve, reject) => {
//         fetch(url)
//         .then(res => res.json())
//         .then(data => resolve(data))
//         .catch(err => reject(err))
//     })
// }
// router.get('/:id/details', function(req, res, next) {
//     var id = req.params.id;
//     Promise.all([
//         get('http://localhost:3000/projects/details?src_id='+id),
//         get('http://localhost:3000/projects/track'+id)
//     ]).then(([project, track])=>
//         res.render('admin/project-detail', {
//             layout: 'layout',
//             project: project,
//             track: track
//         })

//     ).catch(err => res.send('Ops, something has gone wrong'))

// })

router.post('/:id/update?:srcid', function (req, res, next) {
    var srcid = req.query.srcid;
    var id = req.params.id;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/beta/projects/' + id + '/selected/' + srcid)
        }
    }
    var inputData = req.body;
    projectService.updateStatus(id, inputData, callback)
})

router.post('/:id/changestatus/:srcid', function (req, res, next) {
    var srcid = req.params.srcid;
    var id = req.params.id;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/beta/projects/details/' + srcid)
        }
    }
    var inputData = req.body;
    projectService.updateStatus(id, inputData, callback)
})

router.post('/:id/details/attendance', function (req, res, next) {
    var id = req.params.id;
    // var inputData = req.body;
    // var user_id = req.body.user_id;
    var from = req.body.from;
    var to = req.body.to;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);

            res.render('admin/attendance', {
                layout: 'layout',
                title: 'Attendance',
                attendance: data
            })
        }
    }
    projectService.getAttendance(id, from, to, callback);
})


router.post('/attendance/:id', function (req, res, next) {
    var id = req.params.id;
    // var user_id = req.body.user_id;
    var inputData = req.body;

    function attendance(error, data) {
        if (error) {
            console.log(error)
        } else {
            console.log(data);

            var users = JSON.parse(data).users;
            var attendance = JSON.parse(data).attendance;
            // for(var i=0; i<users.length; i++) {
            //     if(attendance.length < 1) {
            //             users[i].attendance = "Absent"

            //         }
            //     var found = false;
            //     for(var j=0;j<attendance.length; j++) {

            //         if(attendance[j].user_id == users[i].user_id ) {
            //           found = true;
            //           break;

            //         } 

            //     }
            //     if(found == true) {
            //         users[i].attendance = "present"
            //         users[i].achievedHours = attendance[j].achievedHours;
            //         users[i].checkin = attendance[j].editedcheckin;
            //         users[i].checkout = attendance[j].editedcheckout;
            //     } else {
            //         users[i].attendance = "Absent"
            //         users[i].achievedHours = "N/A"
            //         users[i].checkin = "N/A"
            //         users[i].checkout = "N/A"
            //     }

            // }

            res.render('admin/date_attendance', {
                layout: 'layout',
                dateattendance: users,
                attendance: attendance
            })
        }
    }
    projectService.getAttendanceByDate(id, inputData, attendance);
})

// router.post('/attendance/:id/download', function (req, res, next) {
//     var id = req.params.id;
//     var user_id = req.body.user_id;
//     var from = req.body.from;
//     var to = req.body.to;
//     var callback = function (error, data) {
//         if (error) {
//             console.log(error);
//         } else {
//             var result = JSON.parse(JSON.stringify(data));


//             let workbook = new excel.Workbook(); //creating workbook
//             let worksheet = workbook.addWorksheet('Attendance');

//             worksheet.columns = [
//                 { header: 'jobdate', key: 'jobdate', width: 30 },
//                 { header: 'Id', key: 'user_id', width: 20 },
//                 { header: 'Name', key: 'full_name', width: 30 },
//                 { header: 'Attendance', key: 'attendance', width: 30 }
//             ];
//             worksheet.addRows(result);
//             res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
//             res.setHeader('Content-Disposition', 'attachment; filename=' + 'attendance.xlsx');

//             return workbook.xlsx.write(res)
//                 .then(function () {
//                     res.status(200).end();
//                 });

//         }
//     }
//     projectService.getAttendance(user_id, id, from, to, callback);
// })

router.post('/reports/:id/download', function (req, res, next) {
    var id = req.params.id;
    // var user_id = req.body.user_id;
    var from = req.body.from;
    var to = req.body.to;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            var result = JSON.parse(JSON.stringify(data));
            let workbook = new excel.Workbook();
            let worksheet = workbook.addWorksheet('Report');

            worksheet.columns = [
                { header: 'Date', key: 'created_datetime', width: 30 },
                { header: 'Id', key: 'user_id', width: 30 },
                { header: 'Name', key: 'full_name', width: 30 },
                { header: 'Question For', key: 'question_for', width: 60 },
                { header: 'Question', key: 'question', width: 60 },
                { header: 'Answer', key: 'answer', width: 60 },
                { header: 'Answered At', key: 'answered_at', width: 60 }
            ];

            worksheet.addRows(result);
            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

            return workbook.xlsx.write(res)
                .then(function () {
                    res.status(200).end();
                })
        }
    }
    projectService.getReport(id, from, to, callback);
})

router.post('/:id/reports/download', function (req, res, next) {
    var id = req.params.id;
    var from = req.body.from;
    var to = req.body.to;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            // var result = JSON.parse(JSON.stringify(data));




            // for (var k = 0; k < result.length; k++) {

            //     var startTime = moment(result[k].editedcheckin, "HH:mm:ss");
            //     var endTime = moment(result[k].editedcheckout, "HH:mm:ss");


            //     if( endTime.isBefore(startTime) ){
            //         endTime.add(1, 'day');
            //     }

            //     var duration = moment.duration(endTime.diff(startTime));
            //     var hours = parseInt(duration.asHours());
            //     var minutes = parseInt(duration.asMinutes()) % 60;
            //     console.log(hours + ' hour and ' + minutes + ' minutes.');
            //     if(result[k].editedcheckout == null)
            //     {
            //         result[k].achievedHours = "0 hours and 0 minutes"
            //     } else {
            //         result[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
            //     }
            // }

            // for(var j=0; j<result.length; j++) {
            //     result[j].check_in_lat_long = result[j].check_in_latitude +' , '+result[j].check_in_longitude
            //     result[j].check_out_lat_long = result[j].check_out_latitude +' , '+result[j].check_out_longitude
            // }


            // for(var i=0; i< result.length; i++) {
            //     result[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/'+result[i].check_in_image
            //     result[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/'+result[i].check_out_image
            //     result[i].jobdate = moment(result[i].jobdate).format("DD MMMM - YYYY")
            // }
            // let workbook = new excel.Workbook();
            // let worksheet = workbook.addWorksheet('Report');
            // let work = workbook.addWorksheet('Question');

            // worksheet.columns = [
            //     { header: 'Date', key: 'jobdate', width: 20 },
            //     // { header: 'Id', key: 'application_id', width: 10 },
            //     { header: 'Name', key: 'full_name', width: 30 },
            //     { header: 'Location', key: 'location_name', width: 30 },
            //     { header: 'Location Address', key: 'location_address', width: 100 },
            //     { header: 'check In', key: 'editedcheckin', width: 20 },
            //     {header: 'check In lat,long', key: 'check_in_lat_long', width: 60},
            //     { header: 'check In Image', key: 'check_in_image', width: 100 },
            //     { header: 'check Out', key: 'editedcheckout', width: 20 },
            //     {header: 'check Out lat,long', key: 'check_out_lat_long', width: 60},
            //     { header: 'check out Image', key: 'check_out_image', width: 100 },
            //     // { header: 'Scheduled Hours', key: 'scheduledHours', width: 100 },
            //     { header: 'Achieved Hours', key: 'achievedHours', width: 100 }
            // ];

            //worksheet.getCell('A6').hyperlink

            connection.query('SELECT fmp_user.user_id, question, answer, full_name FROM job JOIN job_questions ON job.job_id=job_questions.job_id JOIN job_answers ON job_questions.question_id=job_answers.question_id JOIN fmp_user ON fmp_user.user_id=job_answers.user_id WHERE  job.src_id=? AND job_answers.answered_at BETWEEN ? AND ?', [id, from, to], function (error, question) {
                if (error) {
                    console.log(error);
                } else {
                    var result = JSON.parse(JSON.stringify(data));
                    for (var k = 0; k < result.length; k++) {

                        var startTime = moment(result[k].editedcheckin, "HH:mm:ss");
                        var endTime = moment(result[k].editedcheckout, "HH:mm:ss");


                        if (endTime.isBefore(startTime)) {
                            endTime.add(1, 'day');
                        }

                        var duration = moment.duration(endTime.diff(startTime));
                        var hours = parseInt(duration.asHours());
                        var minutes = parseInt(duration.asMinutes()) % 60;
                        console.log(hours + ' hour and ' + minutes + ' minutes.');
                        if (result[k].editedcheckout == null) {
                            result[k].achievedHours = "0 hours and 0 minutes"
                        } else {
                            result[k].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                        }
                    }

                    for (var j = 0; j < result.length; j++) {
                        result[j].check_in_lat_long = result[j].check_in_latitude + ' , ' + result[j].check_in_longitude
                        result[j].check_out_lat_long = result[j].check_out_latitude + ' , ' + result[j].check_out_longitude
                    }


                    for (var i = 0; i < result.length; i++) {
                        result[i].check_in_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_in_image
                        result[i].check_out_image = 'https://feedmypockets.com/fmp/resources/checkInImage/' + result[i].check_out_image
                        result[i].jobdate = moment(result[i].jobdate).format("DD MMMM - YYYY")
                    }
                    let workbook = new excel.Workbook();
                    let worksheet = workbook.addWorksheet('Report');
                    let work = workbook.addWorksheet('Question');

                    worksheet.columns = [
                        { header: 'Date', key: 'jobdate', width: 20 },
                        // { header: 'Id', key: 'application_id', width: 10 },
                        { header: 'Name', key: 'full_name', width: 30 },
                        { header: 'Location', key: 'location_name', width: 30 },
                        { header: 'Location Address', key: 'location_address', width: 100 },
                        { header: 'check In', key: 'editedcheckin', width: 20 },
                        { header: 'check In lat,long', key: 'check_in_lat_long', width: 60 },
                        { header: 'check In Image', key: 'check_in_image', width: 100 },
                        { header: 'check Out', key: 'editedcheckout', width: 20 },
                        { header: 'check Out lat,long', key: 'check_out_lat_long', width: 60 },
                        { header: 'check out Image', key: 'check_out_image', width: 100 },
                        // { header: 'Scheduled Hours', key: 'scheduledHours', width: 100 },
                        { header: 'Achieved Hours', key: 'achievedHours', width: 100 }
                    ];

                    console.log(question);
                    var resultanswer = JSON.parse(JSON.stringify(question))


                    work.columns = [

                        { header: 'Id', key: 'user_id', width: 30 },
                        { header: 'Name', key: 'full_name', width: 30 },
                        { header: 'Question', key: 'question', width: 70 },
                        { header: 'Answer', key: 'answer', width: 60 },
                    ];
                    worksheet.addRows(result);
                    // work.addRows(resultanswer[0].question);
                    work.addRows(resultanswer);

                    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                    res.setHeader('Content-Disposition', 'attachment; filename=' + 'report.xlsx');

                    return workbook.xlsx.write(res)
                        .then(function () {
                            res.status(200).end();
                        })
                }
            })



        }
    }
    projectService.getReportByDate(id, from, to, callback);
})


// router.post('/reports/downloadreport', function(req, res, next) {
//     var url = "http://i.imgur.com/G9bDaPH.jpg"

//     var options = {
//         directory: "/files/1571306590393Api Requirement.xlsx",
//         filename: "swiggy.xlsx"
//     }

//     download(url,options, function(err){
//         if (err) throw err
//         console.log("meow")
//     }) 
// })




router.get('/:alias/delete', function (req, res, next) {
    var alias = req.params.alias;
    function deleteProject(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/beta/projects');
        }
    }
    projectService.delete(alias, deleteProject)
});


router.get('/:id/profiles?:src_id', function (req, res, next) {
    var id = req.params.id;
    var src_id = req.query.src_id;
    function selectedProfiles(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/selected-profile', {
                layout: 'layout',
                title: 'Selected Profile',
                selected: JSON.parse(data).profile
            })
        }
    }
    projectService.selectedProfiles(src_id, id, selectedProfiles);
})

router.get('/:id/selected/:src_id', function (req, res, next) {
    var id = req.params.id;
    var src_id = req.params.src_id;
    function selected(error, data) {
        if (error) {
            console.log(error);

        } else {
            console.log(data);
            res.render('admin/selected-profile', {
                layout: 'layout',
                title: 'Selected Profile',
                selected: JSON.parse(data).selected,
                experience: JSON.parse(data).experience,
                language: JSON.parse(data).language,
                jobtag: JSON.parse(data).jobtag,
                src_id: src_id


            })


        }


    }
    projectService.candidateDetails(src_id, id, selected)

})

// router.get('/:id/ping/:src_id', function(req, res, next) {
//     var id = req.params.id;
//     var src_id = req.params.src_id;
//     function pingDetails(error, data) {
//         if(error) {
//             console.log(error);
//         } else {
//             console.log(data);

//             res.render('admin/ping', {
//                 layout: 'layout',
//                 title: 'Track',
//                 ping: data
//             })

//         }
//     }
//     projectService.pingDetails(src_id, id, pingDetails);
// })

router.get('/:id/ping/:src_id', function (req, res, next) {
    var id = req.params.id;
    var src_id = req.params.src_id;
    function pingDetails(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            var start = new Array();
            start.push(data[0])
            console.log('start', start)
            connection.query("SELECT * FROM tracking JOIN job ON tracking.job_id=job.job_id WHERE job.src_id=? AND tracking.user_id=? AND jobdate= CURRENT_DATE", [src_id, id], function (error, tracking) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(tracking);
                    connection.query('SELECT *, TIME(updated_at) as time FROM location_ping JOIN job ON job.job_id=location_ping.job_id  WHERE location_ping.user_id=? AND job.src_id=?  ORDER BY id DESC LIMIT 1', [id, src_id], function (error, latest) {
                        if (error) {
                            console.log(error);
                        } else {


                            for (var i = 0; i < latest.length; i++) {
                                latest[i].time = moment(latest[i].time, "HH:mm:ss").format("hh:mm A");
                            }


                            var newArr = new Array();
                            if (data.length == 1) {
                                newArr.push(data[0]);

                            } else {
                                newArr.push(data[1]);
                            }

                            var newArrIndex = 0;
                            var descArrIndex = 0;
                            var descArr = new Array();
                            if (data.length == 1) {
                                descArr.push(data[0]);

                            } else {
                                descArr.push(data[1]);
                            }





                            for (var i = 1; i < data.length; i++) {
                                console.log('lat', data[i].latitude)
                                var point1 = new GeoPoint(JSON.parse(data[i].latitude), JSON.parse(data[i].longitude));
                                console.log('point1', point1)
                                var point2 = new GeoPoint(JSON.parse(newArr[newArrIndex].latitude), JSON.parse(newArr[newArrIndex].longitude));
                                console.log('point2', data[i - 1].latitude)
                                var distance = (point1.distanceTo(point2, true) * 1000)

                                console.log('distance', distance)

                                console.log('meter', parseInt(distance))
                                if (data[0].jobtype == "Type 1") {
                                    if (distance > 50) {
                                        data[i].id = newArrIndex
                                        data[i].id = newArrIndex + 1;
                                        data[i].id = descArrIndex + 1
                                        newArr.push(data[i]);
                                        descArr.push(data[i]);
                                        newArrIndex++;
                                        descArrIndex++;
                                    } else {
                                        console.log(distance);
                                    }
                                } else {
                                    if (distance > 2000) {
                                        data[i].id = newArrIndex
                                        data[i].id = newArrIndex + 1
                                        data[i].id = descArrIndex + 1
                                        newArr.push(data[i]);
                                        descArr.push(data[i])
                                        newArrIndex++;
                                        descArrIndex++
                                    } else {
                                        console.log(distance);
                                    }
                                }


                            }

                            console.log('new', newArr)

                            res.render('admin/ping', {
                                layout: 'layout',
                                title: 'Track',
                                ping: newArr,
                                tracking: tracking,
                                latest: latest,
                                start: start,
                                desc: descArr.reverse()

                            })
                            // res.send({
                            //     ping: newArr,
                            //     tracking: tracking,
                            //     latest: latest,
                            //     start: start,
                            //     desc: descArr.reverse()
                            // })
                        }
                    })
                }
            })
        }
    }
    projectService.pingDetails(src_id, id, pingDetails);
})


//Employee

router.get('/:jobId/employee', function (req, res, next) {
    var jobId = req.params.jobId;
    function listEmployees(error, data) {
        if (error) {
            console.log(error);
            res.json(404, {
                error: true,
                message: 'Not found'
            })
        } else {
            console.log(data);
            res.render('admin/project-detail', {
                layout: 'layout-admin',
                title: 'Employee List',
                employees: data
            })
        }
    }
    employeeService.listEmployees(jobId, listEmployees)

})

router.get('/employee/:jobId', function (req, res, next) {
    var jobId = req.params.jobId;
    function getEmployeeById(error, data) {
        if (error) {
            console.log(error);
            res.json(404, {
                error: true,
                message: 'Not found'
            })
        } else {
            res.render('admin/employee-detail', {
                layout: 'layout-admin',
                title: 'Update Employee'
            })
        }
    }

    employeeService.getEmployeeById(jobId, getEmployeeById);
})

router.get('/employee/:id/update?:jobId', function (req, res, next) {
    var id = req.params.id;
    var jobId = req.query.jobId;
    res.render('/admin/employee-update', {
        layout: 'layout-admin',
        title: 'Update Employee'
    })
})

router.post('/employee/:id/update?:jobId', function (req, res, next) {
    var id = req.params.id;
    var jobId = req.query.jobId;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
            res.json(404, {
                error: true,
                message: 'Not Updated'
            })
        } else {
            console.log(data);
            res.redirect('/beta/projects/employee/' + id)
        }
    }
    var inputData = req.body;
    employeeService.update(id, jobId, inputData, callback);
});

router.get('/employee/:id/delete?:jobId', function (req, res, next) {
    var id = req.params.id;
    var jobId = req.query.jobId;
    function deleteEmployee(error, data) {
        if (error) {
            console.log(error);
            res.json(404, {
                error: true,
                message: 'Not Deleted'
            })
        } else {
            console.log(data);
            res.redirect('/beta/projects/employee/' + jobId)
        }
    }
    employeeService.delete(id, deleteEmployee);
});


router.get('/post', function (req, res, next) {
    res.render('admin/postproject', {
        title: 'Post',
        layout: 'layout-new'
    })

    // res.sendFile(path.resolve('./views/admin/new.html'), )
})

router.get('/:id/projectdetails', function (req, res, next) {
    var id = req.params.id;

    // const start = new Date(2012, 0, 15);
    // const end   = new Date(2012, 4, 23);
    // var range = new Array()
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('SELECT * FROM client_requirements WHERE id=?', [id], function (error, project) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(project);
                    var start_date = moment(project[0].start_date).format("YYYY-MM-DD");
                    var end_date = moment(project[0].end_date).format("YYYY-MM-DD");
                    var newDaylist = [];
                    var getDaysArray = function (start, end) {
                        for (var arr = [], dt = start; dt <= end; dt.setDate(dt.getDate() + 1)) {
                            arr.push(new Date(dt));


                        }
                        return arr;

                    };
                    var daylist = []
                    daylist = getDaysArray(new Date(start_date), new Date(end_date));
                    console.log(daylist.length)

                    var optionVal = new Array();
                    for (var i = 0; i < daylist.length; i++) {
                        optionVal.push({ id: i, dates: moment(daylist[i]).format("YYYY-MM-DD"), start_time: moment(project[0].start_time, "HH:mm:ss").format("hh:mm A"), end_time: moment(project[0].end_time, "HH:mm:ss").format("hh:mm A"), male_count: project[0].male_count, female_count: project[0].female_count })
                    }


                    res.render('admin/postproject', {
                        layout: 'layout-new',
                        project: optionVal
                    })


                }
            })
        }
    }
    callback();
})

router.post('/jobrole/post', function (req, res, next) {
    var job_role = req.body.role_title;
    console.log('role', job_role)
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            console.log(job_role)
            connection.query('INSERT INTO job_roles SET role_title=?', [job_role], function (error, role) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(role);
                    res.redirect('/beta/projects/post')
                }
            })
        }
    }
    callback();
})

router.post('/:id/finalreport', function (req, res, next) {
    var id = req.params.id;
    var job_id = req.body.job_id;
    var report_id = req.body.report_id;

    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/beta/projects/details/' + id);
        }
    }
    projectService.finalReport(job_id, report_id, callback);
})

router.post('/post/date', function (req, res, next) {
    var inputData = [];
    var temp = {};

    var len = req.body.start_date.length;
    console.log('len', len);
    for (var i = 0; i < len; i++) {
        temp[i] = req.body.start_time[i]
        inputData.push(temp[i]);
    }
    console.log('in', inputData);
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('INSERT INTO project_date (start_time, end_time) VALUES ?', [inputData.map(inputData => [inputData, inputData])], function (error, instered) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(instered);
                    res.redirect('/beta/projects/post');
                }
            })
        }
    }
    callback();
})

router.get('/search', function (req, res, next) {
    res.render('admin/ex', {
        layout: 'layout-new',

    })
})

router.get('/postproject', function (req, res, next) {
    // var id = res.locals.user[0].user_id;
    res.render('admin/post1.hbs', {
        layout: 'layout-post',
        title: 'post project'
    })
})

router.get('/postproject/step2?:id', function (req, res, next) {
    var id = req.query.id;
    function getCategory(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('SELECT * FROM job_category', function (error, category) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(category);
                    for (var i = 0; i < category.length; i++) {
                        if (category[i].id == 1) {
                            category[i].alphabet = "A"
                        } else if (category[i].id == 2) {
                            category[i].alphabet = "B"
                        } else if (category[i].id == 3) {
                            category[i].alphabet = "C"
                        } else if (category[i].id == 4) {
                            category[i].alphabet = "D"
                        } else if (category[i].id == 5) {
                            category[i].alphabet = "E"
                        } else if (category[i].id == 6) {
                            category[i].alphabet = "F"
                        } else if (category[i].id == 7) {
                            category[i].alphabet = "G"
                        } else if (category[i].id == 8) {
                            category[i].alphabet = "H"
                        } else if (category[i].id == 9) {
                            category[i].alphabet = "I"
                        } else if (category[i].id == 10) {
                            category[i].alphabet = "J"
                        }
                    }
                    res.render('admin/post2.hbs', {
                        layout: 'layout-post',
                        title: 'Choose Category',
                        category: category,
                        id: id
                    })
                }
            })
        }
    }
    getCategory();
})

router.get('/postproject/step/3?:id', function (req, res, next) {
    var id = req.query.id;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            connection.query('SELECT * FROM client_requirements JOIN job_roles ON client_requirements.project_category = job_roles.category_id WHERE client_requirements.id=?', [id], function (error, roles) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(roles);
                    for(var i=0; i< roles.length; i++) {
                        roles[i].name_id = roles[i].role_title.charAt(0)
                        console.log('rol', roles[i].name_id)
                    }
                    res.render('admin/post3', {
                        layout: 'layout-post',
                        title: "Choose Job Role",
                        roles: roles,
                        id: id
                    })
                }
            })

        }
    }
    callback();
})


router.get('/step/4?:id', function (req, res, next) {
    var id = req.query.id;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            res.render('admin/post4', {
                layout: 'layout-post',
                title: 'Choose Role Type',
                id: id
            })
        }
    }
    callback();
})

router.post('/post/4/create?:id', function(req, res, next) {
    var id = req.query.id;
    var role_type = req.body.role_type;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET role_type=? WHERE id=?', [role_type, id], function(error, roleType) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(roleType);
                    res.redirect('/beta/projects/step5?id='+id);
                }
            })
        }
    }
    callback();
})

router.get('/step5?:id', function(req, res, next) {
    var id = req.query.id;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/post5', {
                layout: 'layout-post',
                title: 'Choose Project Date',
                id: id
            })
        }
    }
    callback();
})

router.post('/post/5/create?:id', function(req, res, next) {
    var id = req.query.id;
    var start_date = req.body.start_date
    var end_date = req.body.end_date
    console.log('st', start_date)
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            console.log('sat', start_date)
            console.log('end', end_date)
            connection.query('UPDATE client_requirements SET start_date=?, end_date=? WHERE id=?', [start_date, end_date, id], function(error, updated) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(updated);
                    res.redirect('/beta/projects/step/6?id='+id);
                }
            })
        }
    }
    callback();
})

router.get('/post/step/6?:id', function(req, res, next) {
    var id = req.query.id;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/post6', {
                layout: 'layout-post',
                title: 'Choose Time',
                id: id
            })

        }
    }
    callback();
})

router.get('/7?:id', function(req, res, next) {
    var id = req.query.id;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/post7', {
                layout: 'layout-post',
                title: 'Choose Time',
                id: id
            })

        }
    }
    callback();
})


router.get('/choose/city?:id', function(req, res, next) {
    var id = req.query.id;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/post8', {
                layout: 'layout-post',
                title: 'Choose Time',
                id: id
            })

        }
    }
    callback();
})


router.post('/post/7/create?:id', function(req, res, next) {
    var id = req.query.id;
    var male_count = req.body.male_count;
    var female_count = req.body.female_count;
    var any_count = req.body.any_count;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET male_count=?, female_count=?, any_count=? WHERE id=?', [male_count, female_count, any_count, id], function(error, updated) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(updated);
                    res.redirect('/beta/projects/choose/city?id='+id);
                }
            })
        }
    }
    callback();
})

router.post('/post/8/create?:id', function(req, res, next) {
    var id = req.query.id;
    var city = req.body.city;
    console.log('city', city)
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET city=? WHERE id=?', [city, id], function(error, updated) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(updated);
                    connection.query('SELECT * FROM client_requirements WHERE id=?', [id], function(error, project) {
                        if(error) {
                            console.log(error);
                        } else {
                            console.log(project);
                            console.log(project);
                            var start_date = moment(project[0].start_date).format("YYYY-MM-DD");
                            var end_date = moment(project[0].end_date).format("YYYY-MM-DD");
                            var newDaylist = [];
                            var getDaysArray = function (start, end) {
                                for (var arr = [], dt = start; dt <= end; dt.setDate(dt.getDate() + 1)) {
                                    arr.push(new Date(dt));
        
        
                                }
                                return arr;
        
                            };
                            var daylist = []
                            daylist = getDaysArray(new Date(start_date), new Date(end_date));
                            console.log(daylist.length)
        
                            var optionVal = new Array();
                            for (var i = 0; i < daylist.length; i++) {
                               // optionVal.push({dates: moment(daylist[i]).format("YYYY-MM-DD"), start_time: moment(project[0].start_time, "HH:mm:ss").format("hh:mm A"), end_time: moment(project[0].end_time, "HH:mm:ss").format("hh:mm A"), male_count: project[0].male_count, female_count: project[0].female_count })
                                optionVal.push({dates: moment(daylist[i]).format("YYYY-MM-DD"), start_time: project[0].start_time, end_time: project[0].end_time, male_count: project[0].male_count, female_count: project[0].female_count })

                            }
                            let values=optionVal.reduce((o,a)=>{
                                let ini=[];
                                ini.push(a.dates);
                                ini.push(a.start_time);
                                ini.push(a.end_time);
                                ini.push(a.male_count);
                                ini.push(a.female_count);
                                o.push(ini);
                                return o
                          },[])
                          console.log(values);
                            console.log('op', optionVal)
                            connection.query('INSERT INTO project_date (date, start_time, end_time, male_count, female_count) VALUES ?', [values], function(error, inserted) {
                                if(error) {
                                    console.log(error);
                                } else {
                                    console.log(inserted);
                                    res.render('admin/postproject', {
                                        layout: 'layout-new',
                                        project: optionVal
                                    })
                                }
                            })
                        }
                    })
                    
                }
            })
        }
    }
    callback();
})


router.post('/post/3/create?:id', function (req, res, next) {
    var id = req.query.id;
    var job_role = req.body.job_role;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET job_role=? WHERE id=?', [job_role, id], function (error, updated) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(updated);
                    res.redirect('/beta/projects/step/4?id=' + id)
                }
            })
        }
    }
    callback();
})

router.post('/post1/create', function (req, res, next) {
    var title = req.body.project_title;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('INSERT INTO client_requirements SET project_title=?', [title], function (error, inserted) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(inserted.insertId);
                    connection.query('SELECT * FROM client_requirements WHERE id=?', [inserted.insertId], function (error, project) {
                        if (error) {
                            console.log(error);
                        } else {
                            res.redirect('/beta/projects/postproject/step2?id=' + project[0].id);
                        }
                    })

                }
            })
        }
    }
    callback();
})

router.post('/post2/create?:id', function (req, res, next) {
    var id = req.query.id;
    var category = req.body.project_category;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            connection.query('UPDATE client_requirements SET project_category=? WHERE id=?', [category, id], function (error, category) {
                if (error) {
                    console.log(error);
                } else {
                    console.log(category);
                    res.redirect('/beta/projects/postproject/step/3?id=' + id)
                }
            })
        }
    }
    callback();
})


router.post('/post', function (req, res, next) {
    var inputData = req.body;
    var callback = function (error, data) {
        if (error) {
            console.log(error);

        } else {
            console.log(data);
            var json = JSON.parse(data).project;
            connection.query('SELECT * FROM fmphire WHERE emailid=?', [json[0].emailid], function (error, data) {
                if (error) {
                    console.log(error);
                } else if (data.length < 1) {
                    var readHTMLFile = function (path, callback) {
                        fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                            if (err) {
                                throw err;
                                callback(err);
                            }
                            else {
                                callback(null, html);
                            }
                        });
                    }
                    var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'abhijit.mohanty@feedmypockets.com', pass: 'FMPabhijit@123' } });
                    readHTMLFile(__dirname + '/../views/admin/success.html', function (err, html) {
                        var template = handlebars.compile(html);
                        var replacements = {

                            email: json[0].emailid,
                            name: json[0].name,
                            contact: json[0].contact,
                            requirement: json[0].requirement,
                            category: json[0].category,
                            city: json[0].city,
                            description: json[0].jobdetails,
                            start_date: json[0].startdate,
                            end_date: json[0].enddate,
                            appointment_date: json[0].appointment_date,
                            appointment_time: json[0].appointment_time


                        };

                        var htmlToSend = template(replacements);
                        var mailOptions = {
                            from: 'stellarslog@gmail.com',
                            to: json[0].emailid,
                            subject: 'Account verification',
                            text: 'Hello',
                            html: htmlToSend



                        }

                        console.log(mailOptions)
                        transporter.sendMail(mailOptions, function (err, dt) {
                            console.log('mail error', err)
                            console.log('mail success', dt)
                            if (err) {
                                res.json(500, {
                                    error: true,
                                    error: err
                                })
                            } else {
                                res.redirect('/beta/users/signin');

                            }


                        })
                    });
                } else {

                    var readHTMLFile = function (path, callback) {
                        fs.readFile(path, { encoding: 'utf-8' }, function (err, html) {
                            if (err) {
                                throw err;
                                callback(err);
                            }
                            else {
                                callback(null, html);
                            }
                        });
                    }
                    var transporter = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 587, secure: false, auth: { user: 'abhijit.mohanty@feedmypockets.com', pass: 'FMPabhijit@123' } });
                    readHTMLFile(__dirname + '/../views/admin/email.html', function (err, html) {
                        var template = handlebars.compile(html);
                        var replacements = {

                            email: json[0].emailid,
                            name: json[0].name,
                            contact: json[0].contact,
                            requirement: json[0].requirement,
                            category: json[0].category,
                            city: json[0].city,
                            description: json[0].jobdetails,
                            start_date: json[0].startdate,
                            end_date: json[0].enddate,
                            appointment_date: json[0].appointment_date,
                            appointment_time: json[0].appointment_time


                        };

                        var htmlToSend = template(replacements);
                        var mailOptions = {
                            from: 'stellarslog@gmail.com',
                            to: json[0].emailid,
                            subject: 'Account verification',
                            text: 'Hello',
                            html: htmlToSend



                        }

                        console.log(mailOptions)
                        transporter.sendMail(mailOptions, function (err, dt) {
                            console.log('mail error', err)
                            console.log('mail success', dt)
                            if (err) {
                                res.json(500, {
                                    error: true,
                                    error: err
                                })
                            } else {
                                res.redirect('/beta/users/signin');
                            }


                        })



                    });

                }
            })
            console.log(json);

        }
    }
    projectService.create(inputData, callback);
})

router.post('/signup', function (req, res, next) {
    var data = req.body

    // var dir = path.join(__dirname, '../public/images');
    // var finishUpload = function (err, data) {
    //     if (err) {
    //         console.log(err);
    //     } else {

    //     }
    // };
    var callback = function (error, data) {
        // data.profilephoto = req.file.originalname
        if (error) {
            console.log(error);
        } else {
            res.redirect('/beta/users/signin');

        }
    };
    // mediaService.uploadMedia(req, res, dir, callback);
    projectService.signup(data, callback);

})



router.post('/:id/editspoc', function (req, res, next) {
    var id = req.params.id;
    var spoc_name = req.body.spoc_name;
    var spoc_desi = req.body.spoc_desi;
    var spoc_contact = req.body.spoc_contact;
    var spoc_email = req.body.spoc_email;
    var spoc_status = req.body.spoc_status;

    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/beta/projects/details/' + id)
        }
    }
    projectService.editSpoc(id, spoc_name, spoc_desi, spoc_contact, spoc_status, spoc_email, callback)
})

router.get('/:id/trackdetails?:userId', function (req, res, next) {
    var id = req.params.id;
    var userId = req.query.userId;
    function track(error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.render('admin/track', {
                layout: 'layout',
                title: 'Track Details',
                user: JSON.parse(data).user
            })
        }
    }
    projectService.track(id, userId, track)
})

router.post('/:src_id/timesheet/update', function (req, res, next) {
    var src_id = req.params.src_id;
    var jobdate = req.body.jobdate;
    var job_id = req.body.job_id;
    var callback = function (error, data) {
        if (error) {
            console.log(error);
        } else {
            console.log(data);
            res.redirect('/beta/projects/details/' + src_id)
        }
    }
    projectService.updateTimesheet(jobdate, job_id, callback);
})



module.exports = router;
