var express = require('express');
var router = express.Router();
var timesheetService = require('../services/timesheetService');
var moment = require('moment')

var mysql = require('mysql');
var connection = mysql.createConnection({
    host: '103.212.121.23',
    user: 'fmp',
    password: 'FMP@#123123',
    database: 'feedmypockets'
})

router.get('/:id/approval?:job_date', function(req, res, next) {
    var id = req.params.id;
    var job_date = req.query.job_date;
    var timesheetcount;
    function getTimesheet(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            if(data.length == 0) {
                timesheetcount = 0;
            } else {
                for (var j = 0; j < data.length; j++) {
                    var startTime = moment(data[j].start_time, "HH:mm:ss");
                    var endTime = moment(data[j].end_time, "HH:mm:ss");
                   
    
                    if (endTime.isBefore(startTime)) {
                        endTime.add(1, 'day');
                    }
                    var duration = moment.duration(endTime.diff(startTime));
    
                    var hours = parseInt(duration.asHours());
                    var minutes = parseInt(duration.asMinutes()) % 60;
                    console.log(hours + ' hour and ' + minutes + ' minutes.');
                    data[j].scheduledHours = hours + ' hour and ' + minutes + ' minutes.'
                }
    
                for (var i = 0; i < data.length; i++) {
    
                    var startTime = moment(data[i].editedcheckin, "HH:mm:ss");
                    var endTime = moment(data[i].editedcheckout, "HH:mm:ss");
                    data[i].editedcheckin = moment(data[i].editedcheckin, "HH:mm:ss").format("hh:mm A");
                    data[i].editedcheckout = moment(data[i].editedcheckout, "HH:mm:ss").format("hh:mm A");
                    if (endTime.isBefore(startTime)) {
                        endTime.add(1, 'day');
                    }
    
                    var duration = moment.duration(endTime.diff(startTime));
                    var hours = parseInt(duration.asHours());
                    var minutes = parseInt(duration.asMinutes()) % 60;
                    console.log(hours + ' hour and ' + minutes + ' minutes.');
                    if (data[i].editedcheckout == null) {
                        data[i].achievedHours = "0 hours and 0 minutes"
                    } else {
                        data[i].achievedHours = hours + ' hour and ' + minutes + ' minutes.'
                    }
                }
                timesheetcount = data.length;
            }
            
            res.render('admin/timesheet', {
                layout: 'layout-timesheet',
                title: 'Timesheet',
                timesheet: data,
                timesheetcount: timesheetcount
            })
        }
    }
    timesheetService.getTimesheet(id, job_date, getTimesheet)
})


router.post('/:id/update?:job_date', function (req, res, next) {
    var id = req.params.id;
    var date = req.query.job_date;
    var user_id = req.body.user_id;
    var status = req.body.clientapproval;
    var checked = []

    checked = req.body.checked

    for (var i = 0; i <= checked.length; i++) {

        console.log('checked', checked[i]);
        
        connection.query('UPDATE tracking SET clientapproval="Yes" WHERE tracking.job_id=? AND tracking.jobdate=? AND tracking.user_id=?', [id, date, checked[i]], function (error, user) {
            
            if (error) {
                console.log(error);
            } else {
                console.log(user);
            }
        })
    }
    res.redirect('/timesheet/' + id + '/approval?job_date=' + date)

});


module.exports = router;