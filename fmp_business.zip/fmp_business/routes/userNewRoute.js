var express = require('express');
var app = express();
var router = express.Router();
var md5 = require('js-md5');
var userService = require('../services/userService');
var profileMediaService = require('../services/profileMediaService');
var http = require('http');
var multer = require('multer');
var path = require('path');
var cookieParser = require('cookie-parser');
var mysql = require('mysql');
var session = require('express-session');
var passport = require('passport');
var GoogleStrategy = require('passport-google-oauth20').Strategy;
var request = require('request');
var nodemailer = require('nodemailer');



app.use(session({
    secret: 'top secret',
    saveUninitialized: false,
    resave: false,
    cookie: { maxAge: 30 * 24 * 60 * 1000 }
}));

app.use(cookieParser());

router.use(passport.initialize());
router.use(passport.session());


passport.serializeUser((user, done) => {
    done(null, user);
});

passport.deserializeUser((userDaataFromCookie, done) => {
    done(null, userDaataFromCookie);
});

var accessProtectionMiddleware = (req, res, next) => {
    if (req.isAuthenticated()) {
        next();
    } else {
        res.status(403).json({
            message: 'must be logged in to continue'
        });
    }
};

passport.use(new GoogleStrategy(
    {
        clientID: "800470593510-prtdi35pa0dt0ifeggo7evo705usnl55.apps.googleusercontent.com",
        clientSecret: "LSLzq_5fLEAMSCVYYZuk_tEB",
        callbackURL: "http://localhost:4200/beta/users/auth/google/callback",
        scope: ['email'],
    },
    (accessToken, refreshToken, profile, cb) => {
        console.log('Authenticated with google', profile);
        return cb(null, profile);
    },
));

var connection = mysql.createConnection({
    host: '103.212.121.23',
    user: 'fmp',
    password: 'FMP@#123123',
    database: 'feedmypockets',
    

});

connection.connect(function (error) {
    if (error) {
        console.error('Error connectiong to database' + error.stack);
    } else {
        console.log("mysql connection successfull");
    }
});


router.get('/auth/google/callback', passport.authenticate('google', { failureRedirect: '/', session: true }), (req, res) => {
    console.log('User Object', req.user._json.email);
    connection.query('SELECT * from fmphire  WHERE emailid=?', [req.user._json.email], function (error, data) {
        // if(email) {
        //     connection.query('SELECT *, src.user_id from service_request_contract1 src JOIN (lead1 ld JOIN companydetails1 com ON com.company_name=ld.companyname) ON src.lead_id=ld.lead_id', function (error, data) {
        //         if (error) {
        //             console.log(error);
        //         } else {
        if (data) {
            
            var result = JSON.stringify(data);
            var parsedResult = JSON.parse(result);
            req.session.isAuthenticated = true;
            req.session.user = result;
            res.locals.user = parsedResult[0]
            if (res.locals.user) {
                connection.query('SELECT * FROM client_transaction WHERE client_id=? AND payment_mode="fmp" AND open_status="closed" ', [parsedResult[0].user_id], function(error, reward) {
                    if(error) {
                        console.log(error);
                    } else {
                        console.log(reward);
                        res.redirect('/beta/dashboard1');
                    }
                })
            } else {
                res.render('admin/invalid', {
                    layout: 'layout-signin',
                    title: 'Invalid user'
                })
            }
           
        }
    })    
});

router.get('/signout', function (req, res, next) {
    req.session.isAuthenticated = false;
    req.logout();
    req.session.user = null;
    
    res.redirect('/beta/users/signin');
})

// router.get('/protected', accessProtectionMiddleware, (req, res) => {
//     res.json({
//         message: 'You have accessed the protected endpoint',
//         yourUserInfo: req.user
//     });
// })



router.get('/signin', function (req, res, next) {
    res.render('admin/signin', {
        layout: 'layout-signin',
        title: 'LogIn'
    })
})


router.post('/signin', function (req, res, next) {
    res.redirect('/beta/dashboard');
})

router.post('/login', function (req, res, next) {
    console.log('----------in signin');
    var email = req.body.email;
    var password = req.body.password;

    var errors = req.validationErrors();
    if (errors) {
        var messages = [];
        errors.forEach(function (error) {
            messages.push(error.msg);
        });
        res.render('admin/signin', {
            layout: 'layout-signin',
            error: messages.length > 0,
            messages: messages
        })
    } else {
        var args = {
            body: JSON.stringify(req.body),
            headers: {
                "Content-Type": 'application/json',
                "Accepts": 'application/json',
                "x-access-token": req.headers.token
            },
            url: ''
        };
        request.post(args, function (error, response, body) {
            console.log('error', error);
            console.log('res obj', response.statusCode);
            console.log('body', body);
            if (response.statusCode != 200) {
                console.log('error', error);
                res.redirect('/users/signin');
            } else {
                res.session.isAuthenticated = true;
                req.session.user = body;
                console.log('user data', req.session.user);
                req.session.token = body.token;
                res.locals.user = JSON.parse(body);
                console.log('token ui', JSON.parse(body).token);
                console.log('user body', body);
                console.log('locals', res.locals.user.name);
                res.redirect('/dashboard1');
            }
        })
    }
})

router.get('/signup?:emailid', function (req, res, next) {
    var emailid = req.query.emailid;
    res.render('admin/signup', {
        layout: 'layout-signin',
        title: 'Signup',
        emailid: emailid
    })
})


router.post('/signup', function(req, res, next) {
    var inputData = req.body;
    function newUser(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            // res.redirect('/users/signin');
        }
    }
    userService.newUser(inputData, newUser);
})



module.exports = router;
