var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var walletService = require('../services/walletService');

var connection = mysql.createConnection({
    host: '103.212.121.23',
    user: 'fmp',
    password: 'FMP@#123123',
    database: 'feedmypockets',
})


router.get('/', function(req, res, next) {
    var id = (res.locals.user[0]).user_id;
    function wallet(error, data) {
        if(error) {
            console.log(error);
        } else {
            console.log(data);
            var creditedLength = JSON.parse(data).creditedLength;
            var debitedLength = JSON.parse(data).debitedLength;
            
            if(creditedLength == 0 && debitedLength == 0) {
                var transactionLength = 0
            }
            res.render('admin/wallet', {
                wallet: JSON.parse(data).finalAmount,
                credited: JSON.parse(data).finalCredited,
                debited: JSON.parse(data).finalDebited,
                transaction: JSON.parse(data).transaction,
                credited: JSON.parse(data).credited,
                debited: JSON.parse(data).debited,
                transactionLength: transactionLength,
                layout: 'layout',
                title: 'wallet'
            })
        }
    }
    walletService.wallet(id, wallet);
})

router.post('/generatecashfreetoken', function(req, res, next) {
    function generateCashfreeToken(error, url) {
        if(error) {
            console.log(error);
        } else {
            console.log(url);
            var tokenData = JSON.parse(url).data.token;
            const token = tokenData
            console.log('token', tokenData)
            var amount = req.body.amount;
            var user_id = req.body.user_id;
            var phone = req.body.phoneno;
            var name = req.body.fullname;
            var linkExpiry = req.body.linkExpiry;
            var notifyCustomer = 1;
            var val = Math.floor(1000 + Math.random() * 9000);
            var cashgramId = req.body.fullname.substring(0, 4)+req.body.user_id+val;
            var inputData = req.body;
            inputData.amount = amount;
            inputData.user_id = user_id;
            inputData.phone = phone;
            inputData.name = name;
            inputData.token = token;
            inputData.linkExpiry = linkExpiry;
            inputData.cashgramId = cashgramId;
            inputData.notifyCustomer = notifyCustomer;
            function generateCashgramClient(error, link) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(link);
                    var reference_id = JSON.parse(link).result
                    var reference_idData = JSON.parse(reference_id).data.referenceId
                    console.log('ref', reference_idData);
                    var payment_link = JSON.parse(link).result;
                    var payment_linkData = JSON.parse(payment_link).data.cashgramLink;
                    connection.query('INSERT INTO client_transaction SET client_id=?, cashgram_id=?, reference_id=?, amount=?, status="pending", payment_link=?, payment_link_expire=?, phone=?, payment_mode="cashgram" ', [user_id, cashgramId, reference_idData, amount, payment_linkData, linkExpiry, phone], function(error, trans) {
                        if(error) {
                            console.log(error);
                        } else {
                            console.log(trans);
                            res.redirect(payment_linkData);
                        }
                    })
                }
            }
            walletService.generateCashgramClient(inputData, generateCashgramClient)

        }
    }
    walletService.generateCashfreeToken(generateCashfreeToken);
})


router.post('/generateautocollecttoken', function(req, res, next) {
    var callback = function(error, data) {
        if(error) {
            console.log(error);
            res.json(404, {
                error: true,
                message: 'Not Found'
            })
        } else {
            console.log(data);
            res.json(200, {
                error: false,
                message: 'Found',
                token: data
            })
        }
    }
    walletService.generateAutocollectToken(callback)
})

router.post('/createvpa', function(req, res, next) {
    function generateAutocollectToken(error, url) {
        if(error) {
            console.log(error);
            res.json(404, {
                error: true,
                message: 'Not Found'
            })
        } else {
            console.log(url);
            var tokenData = JSON.parse(url).data.token;
            console.log('token', tokenData)
            var vAccountId = req.body.vAccountId;
            var name = req.body.name;
            var phone = req.body.phone;
            var email = req.body.email;
            var inputData = req.body;
            inputData.vAccountId = vAccountId;
            inputData.name = name;
            inputData.phone = phone;
            inputData.email = email;
            function craeteAccount(error, link) {
                if(error) {
                    console.log(error);
                } else {
                    
                    res.json(200, {
                        error: false,
                        message: 'Found',
                        account: link
                    })
                }
            }
            
            walletService.createVpa(inputData, tokenData, craeteAccount)
        }
    }
    walletService.generateAutocollectToken(generateAutocollectToken)
})


router.get('/insertcredit', function(req, res, next) {
    var callback = function(error, url) {
        if(error) {
            console.log(error);
            res.json(404, {
                error: true,
                message: 'Not Found'
            })
        } else {
            console.log(url);
            console.log(url);
            var tokenData = JSON.parse(url).data.token;
            console.log('token', tokenData)
            function alltransactions(error, transaction) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(transaction);
                    var vaAccount = [];
                    
                    var vAccountId = JSON.parse(transaction).data.payments;
                    console.log('Account id', vAccountId.vAccountId);
                    vaAccount.push(vAccountId)
                    
                    // for(var i=0; i<vAccountId.length; i++) {
                    console.log(vAccountId[i].vAccountId)
                    async.eachSeries(vAccountId, function (data, callbackOne) {
                        connection.query('SELECT * FROM client_wallet_transaction WHERE accountId=?', [vAccountId[i].vAccountId], function(error, account) {
                            console.log('test', data.vAccountId)
                            if(error) {
                                console.log(error);
                            } else {
                                console.log(account);

                                if(account < 1) {
                                    connection.query('INSERT INTO client_wallet_transaction SET accountId=?', [account[0].accountId], function(error, inserted) {
                                        if(error) {
                                            console.log(error);
                                        } else {
                                            console.log(inserted);
                                        }
                                    })
                                }

                            }
                            callbackOne();
                        })
                    },function (error, results) {
                        res.json(200, {
                            error: false,
                            message: 'Found',
                            payments: vAccountId
                        })
                    })
                   

                }
            }
            autocollectService.allTransactions(tokenData, alltransactions)
        }
    }
    autocollectService.generateAutocollectToken(callback)
})


router.post('/createqr/:virtualVPA?:amount', function(req, res, next) {
    var virtualVPA = req.params.virtualVPA;
    var amount = req.query.amount;
    var callback = function(error, url) {
        if(error) {
            console.log(error);
            res.json(200, {
                error: true,
                message: 'not Found'
            })
        } else {
            console.log(url);
            var tokenData = JSON.parse(url).data.token;
            console.log('token', tokenData);
            function createQr(error, link) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(link);
                    res.json(200, {
                        error: false,
                        message: 'Found',
                        qr: link
                    })
                }
            }
            walletService.generateQr(tokenData, virtualVPA, amount, createQr)
        }
    }
    walletService.generateAutocollectToken(callback);
})

router.post('/alltransactions', function(req, res, next) {
    var vAccountId = req.body.vAccountId;
    var callback = function(error, url) {
        if(error) {
            console.log(error);
            res.json(200, {
                error: true,
                message: 'not Found'
            })
        } else {
            console.log(url);
            var tokenData = JSON.parse(url).data.token;
            console.log('token', tokenData);
            function getTransaction(error, link) {
                if(error) {
                    console.log(error);
                } else {
                    console.log(link);
                    res.json(200, {
                        error: false,
                        message: 'Found',
                        transaction: link
                    })
                }
            }
            walletService.getTransactions(tokenData, vAccountId, getTransaction)
        }
    }
    walletService.generateAutocollectToken(callback);
})



router.post('/:id/update', function(req, res, next) {
    var id = req.params.id;
    var callback = function(error, data) {
        if(error) {
            console.log(error);
        } else {
            res.redirect('/beta/wallet');
        }
    }
    walletService.updateBox(id, callback);
})



module.exports = router;