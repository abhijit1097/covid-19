var request = require('request');

module.exports.getList = function(callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'https://api.covid19india.org/data.json'
    }
    request.get(args, function(error, data, body) {
        var json = JSON.parse(body);
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(json);
            callback(null, json);
        }
    })
}


module.exports.getStatewise = function(callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'https://api.covid19india.org/state_district_wise.json'
    }
    request.get(args, function(error, data, body) {
        var json = JSON.parse(body);
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(json);
            callback(null, json);
        }
    })
}