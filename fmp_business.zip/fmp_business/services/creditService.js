var request = require('request');
var mysql = require('mysql');
var connection = mysql.createConnection({
    host: '103.212.121.23',
    user: 'fmp',
    password: 'FMP@#123123',
    database: 'feedmypockets'
})


module.exports.getWalletBalance = function(id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/credit/'+id+'/walletbalance'
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
           
            callback(null, body);
        }
    })
} 


module.exports.rechargeWallet = function(wallet, callback) {
    var args = {
        body: JSON.stringify(wallet),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/credit/recharge'
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body)
        }
    })
}

module.exports.jobRecharge = function(wallet, callback) {
    var args = {
        body: JSON.stringify(wallet),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/credit/jobrecharge'
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null)
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports