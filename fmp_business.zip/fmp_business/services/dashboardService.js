var request = require('request');

module.exports.categories = function(id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/'+id+'/categories'
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body)
        }
    })
}