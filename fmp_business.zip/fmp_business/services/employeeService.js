var request = require('request');

module.exports.listEmployees = function(jobId, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.get(args, function(error, response, data) {
        var json = JSON.parse(data);
        if(response.statusCode != 200) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, json.employees);
        }
    })
}

module.exports.getEmployeeById = function(id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.getEmployeeByAlias = function(alias, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.create = function(jobId, employee, callback) {
    var args = {
        body: JSON.stringify(employee),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
} 

module.exports.update = function(id, jobId, employee, callback) {
    var args = {
        body: JSON.stringify(employee),
        headers: {
            "Content-Type": "application/json",
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.put(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.delete = function(id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.delete(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            callback(null, body);
        }
    });
}
