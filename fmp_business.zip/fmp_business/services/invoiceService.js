var request = require('request');

module.exports.listInvoices = function(callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.get(args, function(invoice, response, data) {
        var json = JSON.parse(data).invoices
        if(response.statusCode != 200) {
            callback(invoice, null)
        } else {
            callback(null, json)
        }
    })
}

module.exports.getInvoiceById = function(id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.get(args, function(error, data, body) {
        if(error) {
            callback(error, null);
        } else {
            callback(null, body);
        }
    })
}

module.exports.create = function(invoice, callback) {
    var args = {
        body: JSON.stringify(invoice),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/create'
    }
    request.post(args, function(error, data, body) {
        if(error) {
            callback(error, null);
        } else {
            callback(null, body);
        }
    })
}

module.exports.update = function(id, invoice, callback) {
    var args = {
        body: JSON.stringify(invoice),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.put(args, function(error, data, body) {
        if(error) {
            callback(error, null);
        } else {
            callback(null, body);
        }
    })
}

module.exports.delete = function(id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.delete(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}





module.exports.update = function(id, invoice, callback) {
    var args = {
        body: JSON.stringify(invoice),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.put(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.create = function(invoice, callback) {
    var args = {
        body: JSON.stringify(invoice),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.getInvoiceById = function(id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}