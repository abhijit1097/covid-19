var request = require('request');
var mysql = require('mysql');
var moment = require('moment');
var connection = mysql.createConnection({
    host: '103.212.121.23',
    user: 'fmp',
    password: 'FMP@#123123',
    database: 'feedmypockets'
})

module.exports.listProjects = function (clientid, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/list?id=' + clientid
    }
    request.get(args, function (error, response, data) {

        var json = JSON.parse(data).projects;

        if (response.statusCode != 200) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, json);
        }
    })
}

module.exports.listClientProjects = function(clientid, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/list/'+clientid
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}


module.exports.listPendingProjects = function (clientid, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/pending/list?id=' + clientid
    }
    request.get(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body)
        }
    })
}

module.exports.getProjectById = function (id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.get(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.getProjectByAlias = function (alias, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.get(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.getProjectDetails = function (id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/details?src_id=' + id,

    }
    request.get(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.getAttendanceByDate = function(id, inputData, callback) {
    var args = {
        body: JSON.stringify(inputData),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/' + id+'/date/attendance'
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}



module.exports.getAttendance = function (src_id, from, to, callback) {
    connection.query('SELECT  fmp_user.full_name, tracking.user_id, tracking.attendance, tracking.jobdate from fmp_user JOIN(tracking JOIN job ON job.job_id=tracking.job_id) ON fmp_user.user_id=tracking.user_id WHERE  job.src_id=? AND tracking.jobdate BETWEEN ? AND ?', [src_id, from, to], function (error, data) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}

module.exports.getTrackByDate = function (src_id, from, to, callback) {
    connection.query('SELECT src.src_id, full_name, track_id, tracking.job_id,tracking.check_in_image, tracking.check_out_image, tracking.user_id, project_name, jobdate, attendance, checkin, checkout, editedcheckin, editedcheckout, breakin, breakout, editedbreakin, editedbreakout,src.start_time, src.end_time, profile_image from service_request_contract src JOIN(job JOIN(tracking join fmp_user fmp on tracking.user_id=fmp.user_id)ON job.job_id=tracking.job_id)ON src.src_id=job.src_id WHERE tracking.jobdate BETWEEN ? AND ? and job.src_id=?',[from, to, src_id], function (error, data) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}

module.exports.getReport = function (src_id, from, to, callback) {
    connection.query('SELECT fmp_user.full_name,ja.question_id, ja.user_id, ja.job_id,job.src_id, jq.question, jq.question_for, answer FROM job JOIN(job_questions jq JOIN(job_answers ja JOIN  fmp_user ON ja.user_id=fmp_user.user_id) ON jq.question_id=ja.question_id)ON job.job_id=ja.job_id WHERE job.src_id=? AND answered_at BETWEEN ? AND ?', [id, src_id, from, to], function (error, data) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}


module.exports.create = function (project, callback) {
    var args = {
        body: JSON.stringify(project),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/create'
    }
    request.post(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.createSpoc = function (id, spoc, callback) {
    var args = {
        body: JSON.stringify(spoc),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/' + id + '/addspoc'
    }
    request.post(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.getSpoc = function (id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/' + id + '/getspoc'
    }
    request.get(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.update = function (alias, project, callback) {
    var args = {
        body: JSON.stringify(project),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.put(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.updateStatus = function (id, status, callback) {
    var args = {
        body: JSON.stringify(status),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/' + id + '/update'
    }
    request.put(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.trackProject = function (id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/track/' + id
    }
    request.get(args, function (error, data, body) {
        // var json = JSON.parse(body).track;
        // console.log('tracked json', json);
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            callback(null, body);
        }
    })
}

// module.exports.getAttendance = function(id, filter, callback) {
//     var args = {
//         body: JSON.stringify(filter),
//         headers: {
//             "Content-Type": 'application/json',
//             "Accepts": 'application/json'
//         },
//         url: 'http://localhost:3000/projects/'+id+'/details/attendance'
//     }
//     request.post(args, function(error, data, body) {
//         if(error) {
//             console.log(error);
//             callback(error, null);
//         } else {
//             console.log(body);
//             callback(null, body);
//         }
//     })
// }


module.exports.getAllDetails = function (id,  user_id, callback) {
    var args = {
        
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/' + id + '/alldetails?user_id='+user_id
    }
    request.get(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.finalReport = function(job_id, report_id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            'Accepts': 'application/json'
        },
        url: 'https://feedmypockets.com/HR-Admin/report_list_export.php?questionType=Report&job_id='+job_id+'&jobReportType='+report_id
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body)
        }
    })
}

module.exports.uploadfile = function (id, data, callback) {
    var args = {
        // body: JSON.stringify(data),
        body: JSON.stringify(data),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/' + id + '/upload'
    }
    request.post(args, function (error, data, body) {
        // var json = JSON.parse(data);
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.getfile = function (id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/details/' + id + '/files'
    }
    request.get(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.downloadfile = function (id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/details/' + id + '/files/download'
    }
    request.get(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.deleteFile = function(id, src_id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/details/'+src_id+'/files/'+id
    }
    request.delete(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}





module.exports.delete = function (id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.delete(args, function (error, data, body) {
        if (error) {
            console.log(error);
            callback(error, null);
        } else {
            callback(null, body);
        }
    })
}


module.exports.selectedProfiles = function(id, userId, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/'+userId+'/selectedprofile/'+id
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}


module.exports.candidateDetails = function(id, userId, callback) {
     var args  ={
	     headers: {
	     	"Content-Type": 'application/json',
		"Accepts": 'application/json'
	     
	     },
	     url: 'http://localhost:3000/projects/'+userId+'/profileDetails/'+id
     }
     request.get(args, function(error, data, body) {
     	if(error) {
	    console.log(error);
	    callback(error, null);
	
	} else {
	   console.log(body);
	   callback(null, body);
	
	}
     
     
     })
}

module.exports.pingDetails = function(id, userId, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/ping/'+userId+'/details/'+id
    }
    request.get(args, function(error, data, body) {
        var json = JSON.parse(body).ping
	if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, json);
        }
    })
}

module.exports.signup = function(user, callback) {
    var args = {
        body: JSON.stringify(user),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/signup'
    }
    request.post(args, function(error, data, body) {
        var json = JSON.parse(body).user;
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.attendance = function(id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/'+id+'/attendance'
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.track = function(id, userId, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/projects/'+id+'/trackdetails?userId='+userId
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}


module.exports.getReportByDate = function(src_id, from, to, callback) {
    connection.query('SELECT DISTINCT fmp_user.user_id, full_name, editedcheckin, editedcheckout, location_name, check_in_image, check_out_image,job_locations.check_in_latitude,job_locations.check_in_longitude,job_locations.check_out_latitude, job_locations.check_out_longitude, jobdate, location_address FROM job JOIN tracking ON job.job_id=tracking.job_id JOIN fmp_user ON tracking.user_id=fmp_user.user_id JOIN job_locations ON job_locations.user_id=fmp_user.user_id WHERE job.src_id=? AND  tracking.jobdate BETWEEN ? AND ? ORDER BY jobdate', [src_id, from, to], function(error, data) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}


module.exports.updateTimesheet = function(jobdate, job_id, callback) {
    connection.query('UPDATE tracking JOIN job ON tracking.job_id=job.job_id SET clientapproval="YES" WHERE tracking.jobdate=? AND tracking.job_id=?', [jobdate, job_id], function(error, data) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}



module.exports.editSpoc = function(id, spoc_name, spoc_desi, spoc_contact, spoc_status, spoc_email, callback) {
    connection.query('UPDATE spoc_table SET spoc_name=?, spoc_desi=?, spoc_contact=?, spoc_status=?, spoc_email=? WHERE spoc_id=?', [spoc_name, spoc_desi, spoc_contact, spoc_status, spoc_email, id], function(error, data) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}

module.exports.generateCashfreeToken = function(callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'https://feedmypockets.com/fmp/RestAPI/v1/generateCashfreeToken'
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            
            
            callback(null, body);
        }
    })
}


module.exports.generateCashgramClient = function(inputData,callback) {
    var args = {
        body:JSON.stringify(inputData),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'https://feedmypockets.com/fmp/RestAPI/v1/generateCashgramClient'
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}



module.exports.sendMessage = function(message, number, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'https://api-alerts.kaleyra.com/v4/?api_key=A280639f20b4384c9913a6f227712eea0&method=sms&message='+message+'&to='+number+'&sender=FMPJOB'
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}