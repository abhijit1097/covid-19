var mysql = require('mysql');
var connection = mysql.createConnection({
    host: '103.212.121.23',
    user: 'fmp',
    password: 'FMP@#123123',
    database: 'feedmypockets'
})


module.exports.getTimesheet = function(id, date, callback) {
    connection.query('SELECT *, tracking.user_id FROM tracking JOIN fmp_user ON fmp_user.user_id=tracking.user_id JOIN job ON job.job_id=tracking.job_id JOIN service_request_contract src ON src.src_id=job.src_id WHERE tracking.job_id=? AND jobdate=? AND clientapproval="No" ', [id, date], function(error, data) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}


module.exports.updateTimeshet = function(id, date, user_id,   callback) {
    connection.query('UPDATE tracking SET clientapproval="Yes" WHERE tracking.job_id=? AND tracking.jobdate=? AND tracking.user_id=?',[ id, date, user_id], function(error, data) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}