var request = require('request');
var mysql = require('mysql');
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'fmp',
    password: 'FMP@#123123',
    database: 'feedmypockets'
})


module.exports.listUsers = function(callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.get(args, function(user, response, data) {
        if(response.statusCode != 200) {
            callback(user, null);
        } else {
            callback(null, data);
        }
    })
}


module.exports.socialLogin = function(user, callback) {
    var args = {
        body: JSON.stringify(user),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/auth/google/callback'
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.getUserById = function(user_id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/profile/'+user_id
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.getUserByAlias = function(alias, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.get(args, function(error, data, body) {
        var json = JSON.parse(body);
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(json);
            callback(null, json.project);
        }
    })
}

module.exports.updateBilling = function(user_id, billingName,  billing_add, callback) {
    connection.query('Update fmphire SET billing_name=?, billing_add=? WHERE user_id=?', [billingName, billing_add, user_id], function(error, data) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}

module.exports.newUser = function(user, callback) {
    connection.query('INSERT INTO lead SET?', [user], function(error, data) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}

module.exports.create = function(user, callback) {
    var args = {
        body: JSON.stringify(user),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.post(args, function(error, data, body) {
        if(error) {
            callback(error, null);
        } else {
            callback(null, body);
        }
    })
}

module.exports.update = function(id, user, callback) {
    var args = {
        body: JSON.stringify(user),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.put(args, function(error, data, body) {
        if(error) {
            callback(error, null);
        } else {
            callback(null, body);
        }
    })
}

module.exports.delete = function(id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: ''
    }
    request.delete(args, function(error, data, body) {
        if(error) {
            callback(error, null);
        } else {
            callback(null, body);
        }
    })
}

module.exports.updateCompanyDetails = function(gstno, company, callback) {
    connection.query('UPDATE companydetails SET about_company=? WHERE gstno=?', [company, gstno], function(error, data) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}

module.exports.updateProfilePic = function(user_id, photo, callback) {
    connection.query('UPDATE fmphire SET profilephoto=? WHERE user_id=?', [photo, user_id], function(error, data) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}
