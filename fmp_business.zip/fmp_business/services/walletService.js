var request = require('request');
var mysql = require('mysql');
var connection = mysql.createConnection({
    host: '103.212.121.23',
    user: 'fmp',
    password: 'FMP@#123123',
    database: 'feedmypockets'
})

module.exports.generateCashfreeToken = function(callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'https://feedmypockets.com/fmp/RestAPI/v1/generateCashfreeToken'
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            
            
            callback(null, body);
        }
    })
}

module.exports.generateAutocollectToken = function(callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'https://feedmypockets.com/fmp/RestAPI/v1/generateAutocollectToken'
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.createVpa = function(inputData, token, callback) {
    console.log('tokendata', token)
    var args = {
        body: JSON.stringify(inputData),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json',
            "Authorization": 'Bearer '+token
        },
        url: 'https://cac-api.cashfree.com/cac/v1/createVA'
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.generateQr = function(token, virtualVPA, amount, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json',
            "Authorization": "Bearer "+token
        },
        url: 'https://cac-api.cashfree.com//cac/v1/createDynamicQRCode/virtualVPA='+virtualVPA+'&amount='+amount
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body)
        }
    })
}

module.exports.getTransactions = function(token, vAccountId, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json',
            "Authorization": "Bearer "+token
        },
        url: 'https://cac-api.cashfree.com/cac/v1/payments/'+vAccountId
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.allTransactions = function(token, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json',
            "Authorization": "Bearer "+token
        },
        url: 'https://cac-api.cashfree.com/cac/v1/payments/'
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}


module.exports.generateCashgramClient = function(inputData,callback) {
    var args = {
        body:JSON.stringify(inputData),
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'https://feedmypockets.com/fmp/RestAPI/v1/generateCashgramClient'
    }
    request.post(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.availableAmount = function(id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/wallet/'+id+'/available'
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.wallet = function(id, callback) {
    var args = {
        headers: {
            "Content-Type": 'application/json',
            "Accepts": 'application/json'
        },
        url: 'http://localhost:3000/wallet/'+id+'/alldetails'
    }
    request.get(args, function(error, data, body) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(body);
            callback(null, body);
        }
    })
}

module.exports.updateBox = function(id, callback) {
    connection.query('UPDATE client_transaction SET open_status="opened" WHERE id=?', [id], function(error, data) {
        if(error) {
            console.log(error);
            callback(error, null);
        } else {
            console.log(data);
            callback(null, data);
        }
    })
}